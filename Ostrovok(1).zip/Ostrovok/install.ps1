﻿# Установка «Островка»: копирует файлы, делает ярлык на рабочем столе и в автозагрузке.
$ErrorActionPreference = "Stop"
$src = $PSScriptRoot
$dest = Join-Path $env:LOCALAPPDATA "Programs\Ostrovok"

Write-Host ""
Write-Host "  Установка Островка" -ForegroundColor Cyan
Write-Host ""

# Python уже лежит внутри островка (папка python), ставить его отдельно не нужно
$bundled = Test-Path (Join-Path $src "python\pythonw.exe")
$pythonw = $null
if (-not $bundled) {
    # старый вариант архива без встроенного Python: ищем установленный
    foreach ($cmd in @("py", "python")) {
        try {
            $exe = & $cmd -c "import sys; print(sys.executable)" 2>$null
            if ($LASTEXITCODE -eq 0 -and $exe) {
                $candidate = Join-Path (Split-Path $exe.Trim()) "pythonw.exe"
                if (Test-Path $candidate) { $pythonw = $candidate; break }
            }
        } catch { }
    }
    if (-not $pythonw) {
        Write-Host "  Не нашёл Python. Скачай архив Островка заново - в новом Python уже внутри." -ForegroundColor Yellow
        Read-Host "  Нажми Enter, чтобы закрыть"
        exit 1
    }
}

# закрываем старый островок, если он запущен
Get-CimInstance Win32_Process -Filter "Name='pythonw.exe' OR Name='python.exe'" |
    Where-Object { $_.CommandLine -like "*Ostrovok*island.py*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
Start-Sleep -Milliseconds 500

New-Item -ItemType Directory -Force -Path $dest | Out-Null
foreach ($f in @("island.py", "isl_core.py", "isl_calls.py", "isl_extra.py", "isl_fps.py", "isl_more.py", "isl_update.py", "isl_battery.py", "isl_qr.py", "media.ps1", "notif.ps1", "README.md", "THIRD_PARTY.txt", "uninstall.bat", "uninstall.ps1")) {
    Copy-Item (Join-Path $src $f) $dest -Force
}
if ($bundled) {
    Copy-Item (Join-Path $src "python") $dest -Recurse -Force
    $pythonw = Join-Path $dest "python\pythonw.exe"
}
Write-Host "  Файлы скопированы в $dest"

$ws = New-Object -ComObject WScript.Shell
$places = @([Environment]::GetFolderPath("Desktop"), [Environment]::GetFolderPath("Startup"))
foreach ($dir in $places) {
    $s = $ws.CreateShortcut((Join-Path $dir "Островок.lnk"))
    $s.TargetPath = $pythonw
    $s.Arguments = "`"$dest\island.py`""
    $s.WorkingDirectory = $dest
    $s.Description = "Островок сверху экрана"
    $s.IconLocation = "$env:SystemRoot\System32\shell32.dll,43"
    $s.Save()
}
Write-Host "  Ярлык на рабочем столе и автозапуск с Windows - готово"

Start-Process $pythonw -ArgumentList "`"$dest\island.py`"" -WorkingDirectory $dest
Write-Host ""
Write-Host "  Готово! Островок появился сверху экрана." -ForegroundColor Green
Write-Host "  Наведи мышку - иконки, клик - раскрыть, правый клик - меню."
Write-Host ""
Read-Host "  Нажми Enter, чтобы закрыть"
