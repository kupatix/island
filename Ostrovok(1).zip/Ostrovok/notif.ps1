﻿# Помощник островка: уведомления Windows, звонки и микрофон.
#  * Новые уведомления (Telegram, Discord, WhatsApp ...) печатает строчкой JSON.
#  * Раз в секунду сообщает, какая программа для звонков сейчас пользуется микрофоном (= идёт разговор).
#  * Умеет нажать кнопку «Принять» / «Отклонить» в окне звонка и показать окно программы.
#    Команды приходят через файл: accept:<процесс>, decline:<процесс>, focus:<процесс>
# Уведомления никуда не отправляются - только показываются в островке на этом компьютере.
param([string]$CommandFile = "", [int]$ParentPid = 0)
$ErrorActionPreference = "SilentlyContinue"
$ProgressPreference = "SilentlyContinue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes, Microsoft.VisualBasic
$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($op, [Type]$type) {
    $task = $asTaskGeneric.MakeGenericMethod($type).Invoke($null, @($op))
    $task.Wait(4000) | Out-Null
    $task.Result
}
function Say($obj) { [Console]::Out.WriteLine(($obj | ConvertTo-Json -Compress)); [Console]::Out.Flush() }

$null = [Windows.UI.Notifications.Management.UserNotificationListener, Windows.UI.Notifications, ContentType = WindowsRuntime]
$null = [Windows.UI.Notifications.UserNotification, Windows.UI.Notifications, ContentType = WindowsRuntime]
$null = [Windows.UI.Notifications.KnownNotificationBindings, Windows.UI.Notifications, ContentType = WindowsRuntime]
$listener = [Windows.UI.Notifications.Management.UserNotificationListener]::Current
$access = Await ($listener.RequestAccessAsync()) ([Windows.UI.Notifications.Management.UserNotificationListenerAccessStatus])
Say @{ type = "access"; status = [string]$access }
$listType = [System.Collections.Generic.IReadOnlyList[Windows.UI.Notifications.UserNotification]]

# программы для звонков: процесс -> красивое имя
$CallApps = @{ "telegram" = "Telegram"; "discord" = "Discord"; "whatsapp" = "WhatsApp"; "zoom" = "Zoom";
               "skype" = "Skype"; "teams" = "Teams"; "ms-teams" = "Teams"; "viber" = "Viber"; "vk" = "VK";
               "vk messenger" = "VK"; "signal" = "Signal"; "element" = "Element"; "steam" = "Steam" }
$micRoot = "HKCU:\Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore\microphone"

function Get-MicApps {
    $found = @{}
    foreach ($key in @(Get-ChildItem $micRoot) + @(Get-ChildItem "$micRoot\NonPackaged")) {
        $p = Get-ItemProperty $key.PSPath
        if (-not $p.LastUsedTimeStart -or $p.LastUsedTimeStop -ne 0) { continue }
        $name = $key.PSChildName
        if ($name -like "*#*") { $proc = [IO.Path]::GetFileNameWithoutExtension($name.Replace('#', '\')) }
        elseif ($name -match 'Telegram') { $proc = "Telegram" }
        elseif ($name -match 'WhatsApp') { $proc = "WhatsApp" }
        elseif ($name -match 'Discord') { $proc = "Discord" }
        else { continue }
        $low = $proc.ToLower()
        if (-not $CallApps.ContainsKey($low)) { continue }
        # Windows иногда «забывает» выключить отметку: проверяем, что программа правда запущена
        if (-not (Get-Process -Name $proc -ErrorAction SilentlyContinue)) { continue }
        $found[$low] = $CallApps[$low]
    }
    return $found
}

function Get-Windows($proc) {
    $root = [System.Windows.Automation.AutomationElement]::RootElement
    $res = @()
    foreach ($pr in Get-Process -Name $proc -ErrorAction SilentlyContinue) {
        $cond = New-Object System.Windows.Automation.PropertyCondition ([System.Windows.Automation.AutomationElement]::ProcessIdProperty), $pr.Id
        $res += @($root.FindAll([System.Windows.Automation.TreeScope]::Children, $cond))
    }
    return $res
}

function Press-Button($proc, $pattern) {
    $btnCond = New-Object System.Windows.Automation.PropertyCondition ([System.Windows.Automation.AutomationElement]::ControlTypeProperty), ([System.Windows.Automation.ControlType]::Button)
    foreach ($w in Get-Windows $proc) {
        foreach ($b in $w.FindAll([System.Windows.Automation.TreeScope]::Descendants, $btnCond)) {
            $n = $b.Current.Name
            if ($n -and $n -match $pattern) {
                try {
                    $b.GetCurrentPattern([System.Windows.Automation.InvokePattern]::Pattern).Invoke()
                    return $n
                } catch { }
            }
        }
    }
    return $null
}

function Focus-App($proc) {
    foreach ($pr in Get-Process -Name $proc -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 }) {
        try { [Microsoft.VisualBasic.Interaction]::AppActivate($pr.Id); return $true } catch { }
    }
    return $false
}

function Window-Titles($proc) {
    @(Get-Process -Name $proc -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle } | ForEach-Object { $_.MainWindowTitle })
}

$seen = @{}
$first = $true
$lastMic = ""
while ($true) {
    if ($ParentPid -and -not (Get-Process -Id $ParentPid -ErrorAction SilentlyContinue)) { break }

    # --- команды от островка ---
    if ($CommandFile -and (Test-Path $CommandFile)) {
        $cmd = (Get-Content $CommandFile -Raw).Trim()
        Remove-Item $CommandFile -Force
        $parts = $cmd.Split(":", 2)
        $act, $proc = $parts[0], $parts[1]
        $pressed = $null
        if ($act -eq "accept") { $pressed = Press-Button $proc '^(Принять|Ответить|Accept|Answer|Join|Присоединиться)' }
        elseif ($act -eq "decline") { $pressed = Press-Button $proc '^(Отклонить|Сбросить|Decline|Reject|Завершить|Положить|Hang ?up|End call|Leave|Отключиться|Покинуть)' }
        if (-not $pressed) { $focused = Focus-App $proc } else { $focused = $false }
        Say @{ type = "action"; action = $act; app = $proc; pressed = [string]$pressed; focused = $focused }
    }

    # --- уведомления ---
    if ([string]$access -eq "Allowed") {
        $list = Await ($listener.GetNotificationsAsync([Windows.UI.Notifications.NotificationKinds]::Toast)) $listType
        $now = @{}
        foreach ($n in $list) {
            $id = [string]$n.Id
            $now[$id] = $true
            if ($seen.ContainsKey($id)) { continue }
            $seen[$id] = $true
            if ($first) { continue }        # старые уведомления при запуске не показываем
            try {
                $b = $n.Notification.Visual.GetBinding([Windows.UI.Notifications.KnownNotificationBindings]::ToastGeneric)
                $texts = @($b.GetTextElements() | ForEach-Object { $_.Text })
            } catch { $texts = @() }
            Say @{ type = "notif"; id = $id; app = [string]$n.AppInfo.DisplayInfo.DisplayName;
                   aumid = [string]$n.AppInfo.AppUserModelId; title = [string]($texts | Select-Object -First 1);
                   body = [string](($texts | Select-Object -Skip 1) -join " ") }
        }
        foreach ($id in @($seen.Keys)) {
            if (-not $now.ContainsKey($id)) { $seen.Remove($id); Say @{ type = "gone"; id = $id } }
        }
        $first = $false
    }

    # --- кто сейчас разговаривает (микрофон занят программой для звонков) ---
    $mic = Get-MicApps
    $calls = @()
    foreach ($k in $mic.Keys) { $calls += @{ proc = $k; app = $mic[$k]; titles = @(Window-Titles $k) } }
    $sig = ($calls | ConvertTo-Json -Compress)
    if ($sig -ne $lastMic) { $lastMic = $sig; Say @{ type = "calls"; calls = $calls } }

    Start-Sleep -Milliseconds 800
}
