# -*- coding: utf-8 -*-
"""
Островок (как Dynamic Island) сверху экрана Windows.

  * Время, раскладка (RU/EN), погода, дата, батарея, таймер.
  * Играет музыка - показывает строчки песни в такт с подсветкой как в караоке.
  * Навёл мышку - выезжают мини-иконки разделов.
  * Клик - раскрывается: Музыка, Погода, Таймер, Календарь, Заметки, Система, Настройки.
  * В настройках: темы, цвет текста песни, размер, прозрачность, положение и т.д.
  * Правый клик - меню.

Нужен только Python 3 для Windows, без дополнительных библиотек.
"""
import calendar
import collections
import ctypes
import ctypes.wintypes as wt
import datetime as dt
import math
import os
import random
import re
import sys
import threading
import time
import traceback
import urllib.parse

# встроенный Python не ищет файлы рядом со скриптом сам, поэтому подсказываем ему
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import isl_core as core  # noqa: E402
import isl_calls  # noqa: E402
import isl_extra as extra  # noqa: E402
import isl_fps  # noqa: E402
import isl_more as more  # noqa: E402
import isl_update as upd  # noqa: E402
import isl_battery  # noqa: E402
import isl_qr  # noqa: E402

# откуда брать обновления: version.json рядом с Ostrovok.zip на сайте (можно поменять в настройках)
DEFAULT_UPDATE_URL = ""
from isl_core import (Canvas, MediaWatcher, argb, rgb, with_alpha, hsv, user32, kernel32, gdi32,
                      cursor_pos, press_key, load_json, save_json, http_json, fetch_lyrics, weather_kind,
                      foreground_app, idle_seconds, foreground_game, ping_ms, Cover, set_clipboard_text,
                      WNDPROC, WNDCLASSEXW, BLENDFUNCTION, MONITORINFO, POWERSTATUS, MEMORYSTATUSEX, VP, H)

# ───────────────────────── настройки ─────────────────────────
TOP_OFFSET = 6                     # отступ от верхнего края экрана
FPS = 30
TIMER_PRESETS = [1, 5, 10, 25]     # кнопки таймера, минуты
APP_DIR = core.APP_DIR
SETTINGS_FILE = os.path.join(APP_DIR, "settings.json")
NOTES_FILE = os.path.join(APP_DIR, "notes.json")
LYRICS_DIR = os.path.join(APP_DIR, "lyrics")

THEMES = {   # фон, карточки, акцент, второй акцент
    "dark":   ("Тёмная",   (14, 14, 20),  (30, 30, 42),  (168, 120, 255), (255, 95, 162)),
    "neon":   ("Неон",     (8, 6, 18),    (28, 22, 50),  (0, 229, 255),   (255, 0, 170)),
    "ocean":  ("Океан",    (6, 20, 32),   (16, 40, 60),  (56, 189, 248),  (45, 212, 191)),
    "sunset": ("Закат",    (28, 12, 16),  (54, 26, 32),  (251, 146, 60),  (244, 63, 94)),
    "forest": ("Лес",      (10, 22, 14),  (24, 46, 32),  (74, 222, 128),  (250, 204, 21)),
    "candy":  ("Розовая",  (36, 14, 40),  (62, 28, 68),  (244, 114, 182), (167, 139, 250)),
}
LYRIC_COLORS = {"green": ("Зелёный", (74, 222, 128)), "white": ("Белый", (245, 245, 250)),
                "yellow": ("Жёлтый", (255, 214, 10)), "cyan": ("Голубой", (103, 232, 249)),
                "accent": ("Как тема", None), "rainbow": ("Радуга", None)}
SIZES = {"S": 0.72, "M": 0.85, "L": 1.0}
DEFAULT_UI = {"theme": "dark", "lyric": "green", "size": "M", "opacity": 100, "pos": "center",
              "anim": True, "karaoke": True, "hide_fullscreen": False,
              "wall": "cover", "gamemode": True, "break_min": 60,
              "border": "rgb", "fx": "sparks", "pet": True,
              "notifs": True, "notif_hide": False, "calls": True, "dnd": False,
              "clip_save": False, "net_toast": True, "copy_island": True, "two_drops": True, "pet_kind": "ginger", "fps_mode": "normal",
              "show": {"weather": True, "date": True, "lang": True, "battery": True, "seconds": False}}
TABS = [("music", "Музыка"), ("summary", "Итоги дня"), ("game", "Игры"), ("weather", "Погода"), ("timer", "Таймер"), ("calendar", "Календарь"),
        ("notes", "Заметки"), ("clip", "Буфер обмена"), ("notifs", "Уведомления"), ("shelf", "Полка"), ("todo", "Задачи"), ("system", "Система"),
        ("settings", "Настройки")]
ALL_TITLES = dict(TABS, more="Все разделы")
SHORT_TITLES = {"music": "Музыка", "summary": "Итоги", "game": "Игры", "weather": "Погода", "timer": "Таймер",
                "calendar": "Календарь", "notes": "Заметки", "clip": "Буфер", "notifs": "Уведомл.", "system": "Система",
                "settings": "Настройки", "more": "Ещё", "shelf": "Полка", "todo": "Задачи"}
DEFAULT_PINNED = ["music", "timer", "weather", "notifs"]
MAX_PINNED = 5
CALL_WORDS = re.compile(r"(входящ|звонит|звонок|вызов|calling|incoming|is calling|ringing)", re.I)
TG_PROCS = ["telegram", "ayugram", "kotatogram", "64gram", "materialgram"]
CALL_PROCS = {"telegram": "Telegram", "discord": "Discord", "whatsapp": "WhatsApp", "viber": "Viber",
              "skype": "Skype", "zoom": "Zoom", "teams": "ms-teams", "vk": "vk"}
TOMATO = argb(255, 255, 99, 71)

WHITE = argb(255, 245, 245, 250)
MUTED = argb(255, 150, 150, 170)
DIM = argb(255, 95, 95, 115)
GREEN = argb(255, 74, 222, 128)
RED = argb(255, 255, 90, 106)
YELLOW = argb(255, 255, 204, 77)
BLUE = argb(255, 125, 211, 252)
DARK_TEXT = argb(255, 15, 15, 22)

WEEKDAYS = ["пн", "вт", "ср", "чт", "пт", "сб", "вс"]
MONTHS_SHORT = ["янв", "фев", "мар", "апр", "мая", "июн", "июл", "авг", "сен", "окт", "нояб", "дек"]
MONTHS = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август",
          "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"]

WM_DESTROY, WM_ACTIVATE, WM_MOUSEACTIVATE = 0x2, 0x6, 0x21
WM_CHAR, WM_LBUTTONDOWN, WM_RBUTTONUP, WM_MOUSEWHEEL, WM_QUIT = 0x102, 0x201, 0x205, 0x20A, 0x12
HWND_TOPMOST = wt.HWND(-1)


def plural(n, one, few, many):
    if n % 10 == 1 and n % 100 != 11:
        return one
    if n % 10 in (2, 3, 4) and n % 100 not in (12, 13, 14):
        return few
    return many


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


# ───────────────────────── островок ─────────────────────────
class Island:
    def __init__(self, run_seconds=None):
        self.settings = load_json(SETTINGS_FILE, {})
        ui = dict(DEFAULT_UI)
        ui.update(self.settings.get("ui", {}))
        ui["show"] = {**DEFAULT_UI["show"], **ui.get("show", {})}
        self.ui = ui
        self.notes = load_json(NOTES_FILE, [])
        self.run_seconds = run_seconds

        self.expanded = False
        self.tab = "music"
        self.tab_anim = 1.0
        self.tab_dir = 1
        self.tab_x = None
        self.typing = None
        self.input_text = ""
        self.cal_offset = 0
        self.hits = []
        self.island = (0, 0, 0, 0)
        self.hidden = False
        self.running = True
        self.prev_lbutton = False
        self.errors = 0
        self.last_frame = time.time()
        self.hover_k = 0.0
        self.hover_last_in = 0.0
        self.toast = None              # (текст, значок, до, начало)
        self.timer_end = None
        self.timer_total = 0
        self.sw_running, self.sw_start, self.sw_acc = False, 0.0, 0.0
        self.clip_seq = user32.GetClipboardSequenceNumber()
        self.last_ac = None
        self.cpu = self.ram = 0
        self._cpu_prev = None
        self.last_lang = None
        self.lang_flash = 0.0
        self.stats = self.load_stats()
        self.stats_tick_at = time.time()
        self.stats_saved_at = time.time()
        self.reset_armed = 0.0
        self.cover, self.cover_path = None, None
        self.click_xy = (0, 0)
        self.ripples = []               # волны от кликов: (x, y, время)
        self.particles = []             # искры/снег внутри островка
        self.clips = []                 # история буфера обмена (только в памяти)
        self.pomo = None                # помодоро: {"phase", "end", "total", "cycles"}
        self.week = (0.0, [])           # кэш графика за неделю
        self.game = None                # {"name", "start", "seen", "reminded"}
        self.pings = []
        threading.Thread(target=self.ping_loop, daemon=True).start()
        try:
            self.audio = core.Audio()
        except Exception:
            self.audio = None
        self.track_key_seen = False
        self.last_dt = 0.03
        self.pet_xy = (0, 0)
        self.level = 0.0                # громкость звука прямо сейчас (0..1), плавно
        self.bands = [0.0] * 28         # «полосы» визуализатора
        self.vol_seen = None            # последняя громкость Windows
        self.vol_show = 0.0             # до какого времени показывать полоску громкости
        self.hearts = []                # сердечки, когда гладишь котика
        self.runner = None              # мини-игра «Кот-бегун»
        self.rain = []                  # капли дождя / снежинки для эффекта «Погода»

        self.media = MediaWatcher(APP_DIR)
        self.notifw = core.NotifWatcher(APP_DIR)
        self.notifs = []                # история уведомлений (только в памяти)
        self.side_notifs = []           # уведомления, которые сейчас видны (в островке или в окошке справа)
        self.incoming_seen = None
        self.side_hits = []
        self.native_at = {}             # когда программа последний раз прислала уведомление Windows
        self.unread = {}                # непрочитанные в Telegram (из заголовка окна)
        self.scan_q = collections.deque(maxlen=4)   # результаты осмотра окон Telegram (из фонового потока)
        self.tg_known = {}
        self.tg_sig = {}
        self.dbg_saved = set()
        # новое из Atoll: микрофон/камера, загрузки, Caps Lock, командная строка, пункт управления
        self.privacy = ([], [])
        self.privacy_at = 0
        self.caps = None
        self.dlw = extra.DownloadWatcher()
        self.apps = extra.AppIndex()
        threading.Thread(target=self.apps.load, daemon=True).start()
        self.cmd_sel = 0
        self.user_hidden = False
        self.icons_hidden_by_us = False
        # ещё из Atoll: громкость программ, долгие задачи, файлы на островок, календарь по ссылке
        self.mixer = more.AppMixer()
        self.mix_apps = []
        self.jobs = more.ProgressWatcher()
        self.drop = None                # {"files": [...], "start": время}
        self.cal_events = []
        self.cal_at = 0
        self.cal_err = None
        self.cal_notified = set()
        self.last_fg = None             # (имя exe, название) последней программы на переднем плане
        # заряд беспроводных наушников, мышек, геймпадов
        self.batteries = []
        self.batt_at = 0
        self.batt_seen = None           # какие устройства были в прошлый раз (чтобы сказать «подключены»)
        self.batt_low = set()
        # автообновление
        self.upd_info = None            # что нашли на сайте
        self.upd_state = ""             # текст для настроек
        self.upd_busy = False
        self.upd_checked = time.time() - 6 * 3600 + 25     # первая проверка через 25 секунд после запуска
        # FPS и нагрузка видеокарты в играх
        self.fpsm = isl_fps.FpsMeter()
        self.fps_started = False
        self.fps_hist = []
        self.fps = None
        self.gpu = isl_fps.GpuLoad()
        self.gpu_pct = None
        self.gpu_title = isl_fps.gpu_name()
        self.outputs = []               # колонки / наушники
        self.notifs_seen = time.time()  # когда последний раз открывали «Уведомления» (для красной точки)
        self.vpn_now = None
        self.clip_pill = None           # плашка «скопирована ссылка»
        if self.ui.get("clip_save"):    # буфер, который не забывается после перезапуска
            saved = load_json(os.path.join(APP_DIR, "clips.json"), [])
            if isinstance(saved, list):
                self.clips = [str(t)[:500] for t in saved[:10]]
        self.qr_show = None             # показанный QR-код
        self.net = isl_fps.NetSpeed()
        self.net_speed = None
        self.gesture = None             # жест на карточке трека (свайп / двойной клик)
        self.drag = None                # перетаскивание островка правой кнопкой
        self.sw_anim = {}               # положение кружков у переключателей (для плавной анимации)
        self.confirm = {}               # кнопки «точно?» (перезагрузка/выключение): ключ -> до какого времени
        self.call_dismissed = set()     # окна звонков, на которые уже нажали «принять»/«отклонить»
        self.incoming = None            # входящий звонок {id, app, proc, who, start}
        self.calls = {}                 # идущие разговоры: proc -> {app, who, start}
        self.track_key = None
        self.lyrics, self.lyrics_state = [], "none"
        self.lyric_idx, self.lyric_prev, self.lyric_anim = -1, "", 1.0
        self.weather, self.weather_info, self.weather_at = None, None, 0

        self.cv = None
        self.hwnd = None
        self.setup_geometry()
        self.cur_w, self.cur_h, self.vel_w, self.vel_h = 200 * self.S, 34 * self.S, 0.0, 0.0
        self.expanded_h = 400 * self.S
        self.apply_theme()
        self._create_window()
        if self.settings.get("city"):
            threading.Thread(target=self.update_weather, daemon=True).start()

    # ---------- размеры, тема, окно ----------
    def setup_geometry(self):
        try:
            dpi = user32.GetDpiForSystem()
        except Exception:
            dpi = 96
        self.S = S = dpi / 96 * SIZES.get(self.ui["size"], 0.85)
        mi = MONITORINFO()
        mi.cbSize = ctypes.sizeof(MONITORINFO)
        user32.GetMonitorInfoW(user32.MonitorFromPoint(wt.POINT(0, 0), 1), ctypes.byref(mi))
        m = mi.rcMonitor
        self.monitor = (m.left, m.top, m.right, m.bottom)
        self.W, self.H = int(560 * S), int(900 * S)
        pos = self.ui["pos"]
        if pos == "left":
            self.wx = m.left
        elif pos == "right":
            self.wx = m.right - self.W
        else:
            self.wx = (m.left + m.right) // 2 - self.W // 2
        self.wy = mi.rcWork.top + int(TOP_OFFSET * S)
        cp = self.ui.get("custom_pos")
        if isinstance(cp, list) and len(cp) == 2:        # островок перетащили в своё место (правой кнопкой)
            self.wx = int(clamp(cp[0], m.left - self.W // 3, m.right - self.W * 2 // 3))
            self.wy = int(clamp(cp[1], m.top, m.bottom - 60 * S))
        if self.cv:
            self.cv.close()
        self.cv = Canvas(self.W, self.H, S)
        # отдельное окошко справа для звонков и уведомлений
        self.SW, self.SH = int(390 * S), int(480 * S)
        self.sx, self.sy = mi.rcWork.right - self.SW, mi.rcWork.top + int(6 * S)
        if getattr(self, "side_cv", None):
            self.side_cv.close()
        self.side_cv = Canvas(self.SW, self.SH, S)

    def apply_theme(self):
        _, bg, card, acc, acc2 = THEMES.get(self.ui["theme"], THEMES["dark"])
        self.BG = rgb(bg, int(255 * self.ui["opacity"] / 100))
        self.BG_SOLID = rgb(bg)
        self.CARD = rgb(card)
        self.ACC = rgb(acc)
        self.ACC2 = rgb(acc2)

    def lyric_color(self):
        key = self.ui["lyric"]
        if key == "rainbow":
            return hsv((time.time() * 0.12) % 1.0, 0.6, 1.0)
        if key == "accent":
            return self.ACC
        return rgb(LYRIC_COLORS.get(key, LYRIC_COLORS["green"])[1])

    def set_ui(self, key, value):
        if key == "pos":
            self.ui.pop("custom_pos", None)     # выбрали место кнопкой - забываем, куда перетаскивали
        self.ui[key] = value
        self.settings["ui"] = self.ui
        save_json(SETTINGS_FILE, self.settings)
        if key in ("size", "pos"):
            old_s = self.S
            self.setup_geometry()
            k = self.S / old_s
            self.cur_w, self.cur_h, self.expanded_h = self.cur_w * k, self.cur_h * k, self.expanded_h * k
        self.apply_theme()

    def toggle_show(self, key):
        self.ui["show"][key] = not self.ui["show"][key]
        self.set_ui("show", self.ui["show"])

    def _create_window(self):
        hinst = kernel32.GetModuleHandleW(None)
        self._wndproc = WNDPROC(self._proc)
        wc = WNDCLASSEXW()
        wc.cbSize = ctypes.sizeof(WNDCLASSEXW)
        wc.lpfnWndProc = self._wndproc
        wc.hInstance = hinst
        wc.hCursor = user32.LoadCursorW(None, VP(32649))
        wc.lpszClassName = "DesktopIslandWindow"
        user32.RegisterClassExW(ctypes.byref(wc))
        self.hwnd = user32.CreateWindowExW(0x8 | 0x80 | 0x80000, "DesktopIslandWindow", "Островок", 0x80000000,
                                           self.wx, self.wy, self.W, self.H, None, None, hinst, None)
        if not self.hwnd:
            raise ctypes.WinError(ctypes.get_last_error())
        self.cv.clear()
        self.blit()
        user32.ShowWindow(self.hwnd, 4)
        # окно справа: не забирает фокус (WS_EX_NOACTIVATE), показывается только когда есть что показать
        self.side_hwnd = user32.CreateWindowExW(0x8 | 0x80 | 0x80000 | 0x08000000, "DesktopIslandWindow",
                                                "Островок · звонки", 0x80000000,
                                                self.sx, self.sy, self.SW, self.SH, None, None, hinst, None)
        self.side_shown = False
        ctypes.windll.shell32.DragAcceptFiles(self.hwnd, True)     # можно бросать файлы на островок
        # горячие клавиши: Ctrl+Alt+I - спрятать/показать, Ctrl+Alt+S - скриншот, Ctrl+Alt+Пробел - командная строка
        self.hotkeys_ok = []
        for hid, vk, name in ((1, 0x49, "Ctrl+Alt+I"), (2, 0x53, "Ctrl+Alt+S")):
            if user32.RegisterHotKey(self.hwnd, hid, 0x4003, vk):
                self.hotkeys_ok.append(name)
        # командная строка: если Ctrl+Alt+Пробел занят другой программой - пробуем другие сочетания
        self.cmd_keys = None
        for mods, name in ((0x4003, "Ctrl+Alt+Пробел"), (0x4001, "Alt+Пробел"), (0x4006, "Ctrl+Shift+Пробел")):
            if user32.RegisterHotKey(self.hwnd, 3, mods, 0x20):
                self.cmd_keys = name
                self.hotkeys_ok.append("cmd")
                break

    def on_hotkey(self, hid):
        if hid == 1:
            self.user_hidden = not self.user_hidden
            self.hidden = self.user_hidden
            user32.ShowWindow(self.hwnd, 0 if self.user_hidden else 4)
            if not self.user_hidden:
                self.show_toast("Островок снова тут", "settings", 1.5)
        elif hid == 2:
            self.take_screenshot()
        elif hid == 3:
            self.open_command()

    def side_blit(self):
        pos, size, src = wt.POINT(self.sx, self.sy), wt.SIZE(self.SW, self.SH), wt.POINT(0, 0)
        blend = BLENDFUNCTION(0, 0, 255, 1)
        user32.UpdateLayeredWindow(self.side_hwnd, None, ctypes.byref(pos), ctypes.byref(size), self.side_cv.dc,
                                   ctypes.byref(src), 0, ctypes.byref(blend), 2)

    def blit(self):
        pos, size, src = wt.POINT(self.wx, self.wy), wt.SIZE(self.W, self.H), wt.POINT(0, 0)
        blend = BLENDFUNCTION(0, 0, 255, 1)
        user32.UpdateLayeredWindow(self.hwnd, None, ctypes.byref(pos), ctypes.byref(size), self.cv.dc,
                                   ctypes.byref(src), 0, ctypes.byref(blend), 2)

    def _proc(self, hwnd, msg, wparam, lparam):
        try:
            if hwnd and hwnd == getattr(self, "side_hwnd", None):
                if msg == WM_LBUTTONDOWN:
                    self.side_click(ctypes.c_short(lparam & 0xFFFF).value, ctypes.c_short((lparam >> 16) & 0xFFFF).value)
                    return 0
                if msg == WM_MOUSEACTIVATE:
                    return 3
                if msg in (WM_RBUTTONUP, WM_CHAR):
                    return 0
                return user32.DefWindowProcW(hwnd, msg, wparam, lparam)
            if msg == WM_LBUTTONDOWN:
                self.gesture = None
                self.on_click(ctypes.c_short(lparam & 0xFFFF).value, ctypes.c_short((lparam >> 16) & 0xFFFF).value)
                if self.gesture:
                    user32.SetCapture(hwnd)
                return 0
            if msg == 0x202:                      # WM_LBUTTONUP - конец жеста на обложке
                if self.gesture:
                    user32.ReleaseCapture()
                    self.end_cover_gesture(ctypes.c_short(lparam & 0xFFFF).value)
                return 0
            if msg == 0x204:                      # WM_RBUTTONDOWN - можно потащить островок
                self.drag = {"start": cursor_pos(), "win": (self.wx, self.wy), "moved": False}
                user32.SetCapture(hwnd)
                return 0
            if msg == 0x200 and getattr(self, "drag", None):    # WM_MOUSEMOVE при перетаскивании
                mx, my = cursor_pos()
                sx, sy = self.drag["start"]
                if self.drag["moved"] or abs(mx - sx) + abs(my - sy) > 8:
                    self.drag["moved"] = True
                    self.wx = self.drag["win"][0] + mx - sx
                    self.wy = self.drag["win"][1] + my - sy
                return 0
            if msg == WM_RBUTTONUP:
                d = getattr(self, "drag", None)
                self.drag = None
                user32.ReleaseCapture()
                if d and d["moved"]:
                    self.set_ui("custom_pos", [self.wx, self.wy])
                    self.show_toast("Островок переехал. Вернуть: Настройки → Островок", "settings", 2.5)
                else:
                    self.on_menu()
                return 0
            if msg == WM_MOUSEACTIVATE:
                return 1 if self.typing else 3
            if msg == WM_ACTIVATE and (wparam & 0xFFFF) == 0:
                self.typing = None
            if msg == 0x233:                      # WM_DROPFILES - файл бросили на островок
                files = more.dropped_files(wparam)
                if files:
                    self.drop = {"files": files, "start": time.time()}
                    self.expanded = False
                return 0
            if msg == 0x312:                      # WM_HOTKEY
                self.on_hotkey(wparam)
                return 0
            if msg == 0x100 and self.typing == "cmd" and wparam in (0x26, 0x28):   # стрелки в командной строке
                self.cmd_sel += -1 if wparam == 0x26 else 1
                return 0
            if msg == WM_CHAR:
                self.on_char(wparam)
                return 0
            if msg == WM_MOUSEWHEEL and self.expanded and self.tab == "calendar":
                delta = ctypes.c_short((wparam >> 16) & 0xFFFF).value
                self.cal_offset += -1 if delta > 0 else 1
                return 0
            if msg == WM_MOUSEWHEEL and (not self.expanded or self.tab == "music"):
                # колёсико над островком - громкость (как в Dyland)
                self.wheel_volume(ctypes.c_short((wparam >> 16) & 0xFFFF).value)
                return 0
            if msg == WM_DESTROY:
                self.running = False
                return 0
        except Exception:
            traceback.print_exc()
        return user32.DefWindowProcW(hwnd, msg, wparam, lparam)

    # ---------- клики и ввод ----------
    def hit(self, x0, y0, x1, y1, action, group="exp"):
        self.hits.append((x0, y0, x1, y1, action, group))

    def on_click(self, x, y):
        self.click_xy = (x, y)
        if self.ui["anim"]:
            self.ripples.append((x, y, time.time()))
        for x0, y0, x1, y1, action, group in reversed(self.hits):
            if group == "exp" and not self.expanded:
                continue
            if group == "hover" and self.expanded:
                continue
            if x0 <= x <= x1 and y0 <= y <= y1:   # группа "any" работает всегда (котик)
                action()
                return
        self.expanded = not self.expanded
        if not self.expanded:
            self.typing = None
            self.cal_offset = 0

    def open_tab(self, tab):
        if tab == "screenshot":
            self.take_screenshot()
            return
        if tab == "command":
            self.open_command()
            return
        if tab != self.tab:
            names = self.bar_tabs()
            old = names.index(self.tab) if self.tab in names else names.index("more")
            new = names.index(tab) if tab in names else names.index("more")
            self.tab_dir = 1 if new > old else -1
            self.tab = tab
            self.tab_anim = 0.0 if self.ui["anim"] else 1.0
        self.expanded = True
        if self.typing:
            self.typing = None

    def take_screenshot(self):
        self.count("shots")
        self.expanded = False
        try:
            os.startfile("ms-screenclip:")
        except OSError:
            press_key(0x2C)

    def focus_input(self, what):
        if self.typing != what:
            self.input_text = ""
        self.typing = what
        user32.SetForegroundWindow(self.hwnd)

    # ---------- командная строка (как в Atoll) ----------
    def open_command(self):
        if self.user_hidden:
            self.on_hotkey(1)
        if self.tab != "command":
            self.cmd_prev_tab = self.tab
        self.tab = "command"
        self.tab_anim = 0.0 if self.ui["anim"] else 1.0
        self.expanded = True
        self.cmd_sel = 0
        self.input_text = ""
        self.typing = "cmd"
        user32.SetForegroundWindow(self.hwnd)

    def close_command(self):
        self.typing = None
        self.expanded = False
        self.tab = getattr(self, "cmd_prev_tab", "music") or "music"

    def cmd_actions(self):
        return [("screenshot", "Скриншот", lambda: self.take_screenshot()),
                ("timer", "Таймер на 5 минут", lambda: self.start_timer(5)),
                ("desktop", "Чистый рабочий стол", self.toggle_clean_desktop),
                ("vpn", "VPN", self.open_vpn),
                ("notes", "Новая заметка", lambda: (self.open_tab("notes"), self.focus_input("note"))),
                ("weather", "Погода", lambda: self.open_tab("weather")),
                ("notifs", "Уведомления", lambda: self.open_tab("notifs")),
                ("settings", "Настройки островка", lambda: self.open_tab("settings")),
                ("lock", "Заблокировать компьютер", lambda: user32.LockWorkStation())]

    def cmd_results(self):
        q = self.input_text.strip()
        acts = self.cmd_actions()
        if not q:
            return [(i, t, "действие", f) for i, t, f in acts[:6]]
        res = []
        m = re.match(r"^(?:таймер\s*)?(\d{1,3})\s*(м|мин\w*|m|min\w*)?$", q, re.I)
        if m and (m.group(2) or q.lower().startswith("таймер")):
            n = int(m.group(1))
            res.append(("timer", f"Таймер на {n} {plural(n, 'минуту', 'минуты', 'минут')}", "запустить",
                        lambda n=n: self.start_timer(n)))
        for name, path in self.apps.search(q, 5):
            res.append(("app", name, "программа", lambda p=path: os.startfile(p)))
        if " " not in q and re.match(r"^(https?://)?[\w-]+(\.[\w-]+)+(/\S*)?$", q, re.I):
            url = q if q.lower().startswith(("http://", "https://")) else "https://" + q
            res.append(("web", q, "открыть сайт", lambda u=url: os.startfile(u)))
        ql = q.lower()
        res += [(i, t, "действие", f) for i, t, f in acts if ql in t.lower()]
        res.append(("search", f"Искать «{q}» в интернете", "Google",
                    lambda: os.startfile("https://www.google.com/search?q=" + urllib.parse.quote(q))))
        return res[:7]

    def run_cmd(self, item):
        self.close_command()
        try:
            item[3]()
        except Exception:
            self.show_toast("Не получилось открыть", "search", 2)

    def page_command(self, x, y, w, a):
        c, S = self.cv, self.S
        c.rrect(x, y, w, 38 * S, 12 * S, with_alpha(self.CARD, a))
        c.rrect_outline(x, y, w, 38 * S, 12 * S, with_alpha(self.ACC, a * 0.7), 1.2 * S)
        self.draw_icon("search", x + 20 * S, y + 19 * S, 8 * S, with_alpha(MUTED, a))
        text = self.input_text
        if text:
            c.text(text, x + 38 * S, y, w - 50 * S, 38 * S, c.font(14), with_alpha(WHITE, a))
        else:
            c.text("Программа, сайт, таймер «10 мин»…", x + 38 * S, y, w - 50 * S, 38 * S, c.font(13), with_alpha(DIM, a))
        if self.typing == "cmd" and int(time.time() * 2) % 2 == 0:
            cx = x + 38 * S + c.measure(text, c.font(14)) + 1 * S
            c.line(cx, y + 11 * S, cx, y + 27 * S, with_alpha(self.ACC, a), 1.5 * S)
        self.hit(x, y, x + w, y + 38 * S, lambda: (setattr(self, "typing", "cmd"), user32.SetForegroundWindow(self.hwnd)))
        y += 46 * S
        res = self.cmd_results()
        self.cmd_sel = clamp(self.cmd_sel, 0, max(0, len(res) - 1))
        self.cmd_list = res
        for i, item in enumerate(res):
            icon, title, sub, _ = item
            hot = self.mouse_over_rect(x, y, x + w, y + 32 * S)
            if i == self.cmd_sel or hot:
                c.rrect(x, y, w, 32 * S, 9 * S, with_alpha(self.CARD if not hot or i == self.cmd_sel else argb(30, 255, 255, 255), a))
            c.rrect(x + 6 * S, y + 5 * S, 22 * S, 22 * S, 6 * S, with_alpha(argb(255, 52, 52, 66), a))
            self.draw_icon(icon, x + 17 * S, y + 16 * S, 6.5 * S, with_alpha(self.ACC if i == self.cmd_sel else WHITE, a))
            sw_ = c.measure(sub, c.font(10.5))
            c.text(title, x + 36 * S, y, w - 50 * S - sw_, 32 * S, c.font(12.5, i == self.cmd_sel), with_alpha(WHITE, a))
            c.text(sub, x + w - 10 * S - sw_, y, sw_ + 2 * S, 32 * S, c.font(10.5), with_alpha(DIM, a), align=2)
            self.hit(x, y, x + w, y + 32 * S, lambda it=item: self.run_cmd(it))
            y += 34 * S
        c.text("Enter — открыть · ↑↓ — выбрать · Esc — закрыть", x, y + 4 * S, w, 18 * S, c.font(10.5), with_alpha(DIM, a), align=1)
        return y + 26 * S

    # ---------- закреплённые разделы и «Все разделы» ----------
    def pinned(self):
        p = self.ui.get("pinned")
        if not isinstance(p, list):
            p = list(DEFAULT_PINNED)
        names = [t for t, _ in TABS if t != "settings"]
        return [t for t in p if t in names][:MAX_PINNED]

    def bar_tabs(self):
        return self.pinned() + ["more", "settings"]

    def toggle_pin(self, tab):
        p = self.pinned()
        if tab in p:
            p.remove(tab)
            self.show_toast(f"«{ALL_TITLES[tab]}» убран из верхней полоски", "star", 1.8)
        elif len(p) >= MAX_PINNED:
            self.show_toast(f"Сверху можно закрепить до {MAX_PINNED} разделов", "star", 2)
            return
        else:
            p.append(tab)
            self.show_toast(f"«{ALL_TITLES[tab]}» закреплён сверху", "star", 1.8)
        self.set_ui("pinned", p)

    def page_more(self, x, y, w, a):
        """Все разделы плитками; звёздочка - закрепить раздел в верхней полоске."""
        c, S = self.cv, self.S
        tabs = [(t, title) for t, title in TABS if t != "settings"]
        cols = 3
        gap = 8 * S
        tw_ = (w - gap * (cols - 1)) / cols
        th_ = 66 * S
        pinned = self.pinned()
        for i, (t, title) in enumerate(tabs):
            tx = x + (i % cols) * (tw_ + gap)
            ty = y + (i // cols) * (th_ + gap)
            hot = self.mouse_over_rect(tx, ty, tx + tw_, ty + th_)
            self.card(tx, ty, tw_, th_, 14 * S, a)
            if hot:
                c.rrect(tx, ty, tw_, th_, 14 * S, with_alpha(argb(20, 255, 255, 255), a))
            c.circle(tx + tw_ / 2, ty + 25 * S, 15 * S, with_alpha(self.ACC, a * 0.18))
            self.draw_icon(t, tx + tw_ / 2, ty + 25 * S, 8.5 * S, with_alpha(self.ACC, a))
            c.text(title, tx, ty + 44 * S, tw_, 18 * S, c.font(11, True), with_alpha(WHITE, a), align=1)
            self.hit(tx, ty, tx + tw_, ty + th_, lambda t=t: self.open_tab(t))
            # звёздочка в углу
            sx, sy = tx + tw_ - 13 * S, ty + 13 * S
            on = t in pinned
            star_hot = self.mouse_over_rect(sx - 10 * S, sy - 10 * S, sx + 10 * S, sy + 10 * S)
            if on or hot:
                self.draw_icon("star", sx, sy, 6.5 * S,
                               with_alpha(YELLOW if on else (WHITE if star_hot else DIM), a))
            self.hit(sx - 11 * S, sy - 11 * S, sx + 11 * S, sy + 11 * S, lambda t=t: self.toggle_pin(t))
        rows = (len(tabs) + cols - 1) // cols
        y += rows * (th_ + gap) + 2 * S
        c.text(f"Звёздочка — закрепить раздел сверху (до {MAX_PINNED})", x, y, w, 18 * S, c.font(10.5), with_alpha(DIM, a), align=1)
        return y + 24 * S

    # ---------- пункт управления и чистый стол ----------
    def toggle_clean_desktop(self):
        vis = extra.desktop_icons_visible()
        extra.set_desktop_icons(not vis)
        self.icons_hidden_by_us = vis
        self.set_ui("icons_hidden", vis)       # запоминаем, даже если островок закроют принудительно
        self.show_toast("Значки на рабочем столе спрятаны" if vis else "Значки вернулись", "desktop", 2)

    def open_vpn(self):
        app = extra.find_vpn_app(self.apps) if self.apps.loaded else None
        if app:
            os.startfile(app[1])
            self.show_toast(f"Открываю {app[0]}", "vpn", 2)
        else:
            os.startfile("ms-settings:network-vpn")

    def power(self, what):
        """Сон сразу, а перезагрузка и выключение - только после второго нажатия («Точно?»)."""
        now = time.time()
        if what != "sleep" and self.confirm.get(what, 0) < now:
            self.confirm[what] = now + 3
            return
        self.confirm.pop(what, None)
        if what == "sleep":
            extra.run_hidden(["rundll32.exe", "powrprof.dll,SetSuspendState", "0,1,0"])
        elif what == "restart":
            extra.run_hidden(["shutdown.exe", "/r", "/t", "0"])
        elif what == "off":
            extra.run_hidden(["shutdown.exe", "/s", "/t", "0"])

    def apply_text_tool(self, fn, name):
        if not self.clips:
            self.show_toast("Сначала скопируй текст", "clip", 2)
            return
        new = fn(self.clips[0])
        if set_clipboard_text(self.hwnd, new):
            self.clip_seq = user32.GetClipboardSequenceNumber()
            self.remember_clip(new)
            self.show_toast(f"{name}: готово, вставляй Ctrl+V", "clip", 2)

    def on_char(self, code):
        if self.typing == "cmd":
            if code == 13:
                res = getattr(self, "cmd_list", None) or self.cmd_results()
                if res:
                    self.run_cmd(res[clamp(self.cmd_sel, 0, len(res) - 1)])
                return
            if code == 27:
                self.close_command()
                return
            self.cmd_sel = 0
        if not self.typing:
            return
        if code == 8:
            self.input_text = self.input_text[:-1]
        elif code == 13:
            text = self.input_text.strip()
            if self.typing == "note" and text:
                self.notes.insert(0, {"text": text, "time": time.time()})
                save_json(NOTES_FILE, self.notes)
                self.count("notes")
            elif self.typing == "todo" and text:
                if text.lower().startswith("https://"):
                    self.settings["update_url"] = text
                    save_json(SETTINGS_FILE, self.settings)
                    self.check_update(manual=True)
                else:
                    self.show_toast("Нужна ссылка https://…/version.json", "download", 2.5)
                self.typing = None
                self.input_text = ""
                return
            elif self.typing == "ics" and text:
                if text.lower().startswith(("https://", "http://", "webcal://")):
                    self.settings["ics_url"] = text
                    save_json(SETTINGS_FILE, self.settings)
                    self.cal_at = 0
                    self.cal_events = []
                    self.show_toast("Календарь подключён", "calendar", 2)
                else:
                    self.show_toast("Нужна ссылка, которая начинается с https://", "calendar", 2.5)
                self.typing = None
                self.input_text = ""
                return
            elif self.typing == "city" and text:
                self.settings["city"] = text
                self.settings.pop("lat", None)
                save_json(SETTINGS_FILE, self.settings)
                self.weather = self.weather_info = None
                threading.Thread(target=self.update_weather, daemon=True).start()
            self.input_text = ""
            if self.typing == "city":
                self.typing = None
        elif code == 27:
            self.typing = None
            self.input_text = ""
        elif code == 22:
            self.input_text = (self.input_text + self.clipboard())[:600 if self.typing in ("ics", "updurl") else 200]
        elif code >= 32:
            self.input_text = (self.input_text + chr(code))[:600 if self.typing in ("ics", "updurl") else 200]

    def clipboard(self):
        text = ""
        if user32.OpenClipboard(self.hwnd):
            try:
                h = user32.GetClipboardData(13)
                if h:
                    p = kernel32.GlobalLock(h)
                    if p:
                        text = ctypes.wstring_at(p)
                        kernel32.GlobalUnlock(h)
            finally:
                user32.CloseClipboard()
        return text.replace("\r", " ").replace("\n", " ")

    def on_menu(self):
        menu = user32.CreatePopupMenu()
        user32.AppendMenuW(menu, 0, 1, "Настройки")
        user32.AppendMenuW(menu, 0, 2, "Сменить город для погоды")
        user32.AppendMenuW(menu, 0, 3, "Удалить все заметки")
        user32.AppendMenuW(menu, 0x800, 0, None)
        user32.AppendMenuW(menu, 0, 9, "Выход")
        user32.SetForegroundWindow(self.hwnd)
        x, y = cursor_pos()
        cmd = user32.TrackPopupMenu(menu, 0x100 | 0x2, x, y, 0, self.hwnd, None)
        user32.PostMessageW(self.hwnd, 0, 0, 0)
        user32.DestroyMenu(menu)
        if cmd == 1:
            self.open_tab("settings")
        elif cmd == 2:
            self.open_tab("weather")
            self.focus_input("city")
        elif cmd == 3:
            self.notes = []
            save_json(NOTES_FILE, self.notes)
        elif cmd == 9:
            self.running = False

    # ---------- данные ----------
    def update_weather(self):
        s = self.settings
        try:
            if "lat" not in s:
                q = urllib.parse.urlencode({"name": s["city"], "count": 1, "language": "ru"})
                res = http_json("https://geocoding-api.open-meteo.com/v1/search?" + q).get("results")
                if not res:
                    self.weather, self.weather_info = ("?", "cloud"), {"error": "Город не найден"}
                    return
                s["lat"], s["lon"] = res[0]["latitude"], res[0]["longitude"]
                s["city_name"] = res[0].get("name", s["city"])
                save_json(SETTINGS_FILE, s)
            q = urllib.parse.urlencode({
                "latitude": s["lat"], "longitude": s["lon"], "timezone": "auto", "forecast_days": 2,
                "wind_speed_unit": "ms",
                "current": "temperature_2m,weather_code,is_day,apparent_temperature,wind_speed_10m,"
                           "relative_humidity_2m,surface_pressure,wind_direction_10m,precipitation",
                "hourly": "temperature_2m,weather_code,is_day",
                "daily": "temperature_2m_max,temperature_2m_min,sunrise,sunset,uv_index_max,precipitation_probability_max"})
            d = http_json("https://api.open-meteo.com/v1/forecast?" + q)
            cur = d["current"]
            self.weather = (f"{round(cur['temperature_2m'])}°", weather_kind(cur["weather_code"], cur.get("is_day", 1)))
            hours = []
            now_hour = cur["time"][:13]
            hr = d["hourly"]
            for i, tstr in enumerate(hr["time"]):
                if tstr[:13] > now_hour and len(hours) < 8:
                    hours.append((tstr[11:16], round(hr["temperature_2m"][i]),
                                  weather_kind(hr["weather_code"][i], hr["is_day"][i])))
            self.weather_info = {"feels": round(cur["apparent_temperature"]), "wind": round(cur["wind_speed_10m"]),
                                 "max": round(d["daily"]["temperature_2m_max"][0]),
                                 "min": round(d["daily"]["temperature_2m_min"][0]), "hours": hours}
            dd = d["daily"]
            try:     # подробности, как в Atoll: влажность, давление, ветер, УФ, восход и закат
                self.weather_info.update({
                    "humidity": cur.get("relative_humidity_2m"), "wind_dir": cur.get("wind_direction_10m"),
                    "pressure": round(cur["surface_pressure"] * 0.750062) if cur.get("surface_pressure") else None,
                    "uv": dd.get("uv_index_max", [None])[0], "rain": dd.get("precipitation_probability_max", [None])[0],
                    "sunrise": dd.get("sunrise", [""])[0][11:16], "sunset": dd.get("sunset", [""])[0][11:16]})
            except Exception:
                pass
        except Exception:
            pass
        self.weather_at = time.time()

    def keyboard_lang(self):
        fg = user32.GetForegroundWindow()
        tid = user32.GetWindowThreadProcessId(fg, None) if fg else 0
        lang = (user32.GetKeyboardLayout(tid) or 0) & 0xFFFF
        known = {0x0419: "RU", 0x0409: "EN", 0x0809: "EN", 0x0422: "UA", 0x0423: "BY", 0x043F: "KZ"}
        if lang in known:
            return known[lang]
        buf = ctypes.create_unicode_buffer(85)
        if kernel32.LCIDToLocaleName(lang, buf, 85, 0):
            return buf.value[:2].upper()
        return ""

    def battery(self):
        ps = POWERSTATUS()
        if kernel32.GetSystemPowerStatus(ctypes.byref(ps)) and ps.BatteryFlag != 128 and ps.BatteryLifePercent <= 100:
            return ps.BatteryLifePercent, ps.ACLineStatus == 1
        return None

    def show_toast(self, text, icon, seconds=3.0):
        self.toast = (text, icon, time.time() + seconds, time.time())

    def start_timer(self, minutes):
        self.timer_total = minutes * 60
        self.timer_end = time.time() + self.timer_total
        self.show_toast(f"Таймер на {minutes} {plural(minutes, 'минуту', 'минуты', 'минут')}", "timer", 2)

    def add_minute(self):
        if self.timer_end:
            self.timer_end += 60
            self.timer_total += 60
        else:
            self.start_timer(1)

    def timer_left(self):
        return max(0.0, self.timer_end - time.time()) if self.timer_end else None

    def stopwatch(self):
        return self.sw_acc + (time.time() - self.sw_start if self.sw_running else 0)

    def sw_toggle(self):
        if self.sw_running:
            self.sw_acc += time.time() - self.sw_start
        else:
            self.sw_start = time.time()
        self.sw_running = not self.sw_running

    def sw_reset(self):
        self.sw_running, self.sw_acc = False, 0.0

    # ---------- итоги дня ----------
    @staticmethod
    def stats_path(day):
        return os.path.join(APP_DIR, "stats", day + ".json")

    def empty_stats(self):
        return {"date": dt.date.today().isoformat(), "total": 0.0, "apps": {}, "shots": 0, "tracks": 0,
                "artists": {}, "music": 0.0, "timers": 0, "notes": 0, "games": {}}

    def load_stats(self):
        today = dt.date.today().isoformat()
        s = load_json(self.stats_path(today), None)
        if not isinstance(s, dict) or s.get("date") != today:
            s = self.empty_stats()
        for k, v in self.empty_stats().items():
            s.setdefault(k, v)
        return s

    def save_stats(self):
        save_json(self.stats_path(self.stats["date"]), self.stats)
        self.stats_saved_at = time.time()

    def count(self, key, n=1):
        self.stats[key] = self.stats.get(key, 0) + n

    def track_stats(self):
        """Раз в секунду: за какой программой сидим. Если отошёл от компьютера больше 2 минут - не считаем."""
        now = time.time()
        step = min(5.0, now - self.stats_tick_at)
        self.stats_tick_at = now
        if self.stats["date"] != dt.date.today().isoformat():   # наступил новый день
            self.save_stats()
            self.stats = self.empty_stats()
        if self.media.state.get("status") == "Playing":
            self.stats["music"] += step
        if idle_seconds() < 120:
            app = foreground_app()
            if app:
                self.stats["total"] += step
                self.stats["apps"][app] = self.stats["apps"].get(app, 0.0) + step
        self.track_game(now, step)
        if now - self.stats_saved_at > 60:
            self.save_stats()

    # ---------- игровой режим ----------
    def track_game(self, now, step):
        if not self.ui["gamemode"]:
            self.game = None
            return
        name = foreground_game()
        if name:
            if not self.game or self.game["name"] != name:
                self.game = {"name": name, "start": now, "seen": now, "reminded": 0}
                self.pings = []
                self.fps_hist = []
                self.show_toast(f"Игровой режим · {name}", "game", 2.5)
            pid = wt.DWORD()
            user32.GetWindowThreadProcessId(user32.GetForegroundWindow(), ctypes.byref(pid))
            if pid.value:
                self.game["pid"] = pid.value
            self.game["seen"] = now
            games = self.stats.setdefault("games", {})
            games[name] = games.get(name, 0.0) + step
            minutes = self.ui["break_min"]
            played = now - self.game["start"]
            if minutes and played >= (self.game["reminded"] + 1) * minutes * 60:
                self.game["reminded"] += 1
                self.show_toast(f"Ты играешь уже {self.hm(played)}. Пора отдохнуть!", "alarm", 7)
                try:
                    import winsound
                    winsound.PlaySound("SystemExclamation", winsound.SND_ALIAS | winsound.SND_ASYNC)
                except Exception:
                    pass
        elif self.game and now - self.game["seen"] > 15:   # вышел из игры больше чем на 15 секунд
            self.game = None

    def ping_loop(self):
        while self.running:
            if self.game or (self.expanded and self.tab == "game"):
                self.pings.append(ping_ms())
                del self.pings[:-40]
                time.sleep(2)
            else:
                time.sleep(1)

    def update_fps(self):
        """Раз в секунду: FPS игры (если Windows разрешает) и нагрузка видеокарты."""
        watching = self.game or (self.expanded and self.tab in ("game", "system"))
        if not watching:
            self.fps = None
            return
        if self.game and not self.fps_started and not self.fpsm.denied and self.ui.get("fps", True):
            self.fps_started = self.fpsm.start()
        try:
            self.gpu_pct = self.gpu.sample()
        except Exception:
            self.gpu_pct = None
        fps = None
        pid = (self.game or {}).get("pid")
        if pid:
            fps = self.fpsm.fps_of(pid) if self.fps_started else None
            if fps is None:
                fps = isl_fps.fps_from_helper(pid)
        self.fps = fps
        if self.game:
            self.fps_hist.append(fps)
            del self.fps_hist[:-60]

    @staticmethod
    def fps_color(f):
        return DIM if f is None else (GREEN if f >= 60 else (YELLOW if f >= 30 else RED))

    def ping_now(self):
        vals = [p for p in self.pings[-3:] if p is not None]
        return round(sum(vals) / len(vals)) if vals else None

    @staticmethod
    def ping_color(p):
        return RED if p is None or p >= 120 else (YELLOW if p >= 60 else GREEN)

    # ---------- обложка ----------
    def update_cover(self, st):
        path = (st or {}).get("cover") or None
        if path == self.cover_path:
            return
        self.cover_path = path
        old, self.cover = self.cover, None
        if old:
            old.close()
        if path and os.path.exists(path):
            try:
                self.cover = Cover(path)
            except Exception:
                self.cover = None

    def reset_stats(self):
        if time.time() - self.reset_armed < 3:
            self.stats = self.empty_stats()
            self.save_stats()
            self.reset_armed = 0.0
            self.show_toast("Итоги дня начаты заново", "summary", 2)
        else:
            self.reset_armed = time.time()   # второй клик в течение 3 секунд - сброс

    # ---------- помодоро, напоминания, буфер обмена ----------
    @staticmethod
    def beep():
        try:
            import winsound
            winsound.PlaySound("SystemExclamation", winsound.SND_ALIAS | winsound.SND_ASYNC)
        except Exception:
            pass

    def pomo_toggle(self):
        if self.pomo:
            self.pomo = None
        else:
            self.pomo = {"phase": "work", "end": time.time() + 25 * 60, "total": 25 * 60, "cycles": 0}
            self.show_toast("Помодоро: 25 минут учёбы", "pomo", 2.5)

    def check_pomo(self):
        p = self.pomo
        if not p or time.time() < p["end"]:
            return
        if p["phase"] == "work":
            p["cycles"] += 1
            self.count("pomos")
            p.update(phase="rest", end=time.time() + 5 * 60, total=5 * 60)
            self.show_toast("Перерыв 5 минут! Отдохни", "alarm", 7)
        else:
            p.update(phase="work", end=time.time() + 25 * 60, total=25 * 60)
            self.show_toast("Перерыв закончился. За работу!", "alarm", 7)
        self.beep()

    @staticmethod
    def reminder_time(text):
        """«18:00 сделать уроки» -> (18, 0, «сделать уроки») или None."""
        m = re.match(r"^\s*(\d{1,2})[:.](\d{2})\s+(.+)$", text or "")
        if m and int(m.group(1)) < 24 and int(m.group(2)) < 60:
            return int(m.group(1)), int(m.group(2)), m.group(3)
        return None

    def check_reminders(self):
        now = dt.datetime.now()
        today = now.date().isoformat()
        for note in self.notes:
            r = self.reminder_time(note.get("text"))
            if r and note.get("fired") != today and (r[0], r[1]) == (now.hour, now.minute):
                note["fired"] = today
                save_json(NOTES_FILE, self.notes)
                self.show_toast("Напоминание: " + r[2], "bell", 12)
                self.beep()

    def remember_clip(self, text):
        text = text[:500]
        self.clips = [text] + [t for t in self.clips if t != text][:9]
        if self.ui.get("clip_save"):
            save_json(os.path.join(APP_DIR, "clips.json"), self.clips)

    # ---------- полка, задачи, ссылка из буфера ----------
    def shelf_add(self, kind, value):
        shelf = [s for s in self.settings.get("shelf", []) if s.get("value") != value]
        name = os.path.basename(value.rstrip("\\/")) if kind == "file" else re.sub(r"^https?://(www\.)?", "", value)[:60]
        shelf.insert(0, {"type": kind, "value": value, "name": name or value, "time": time.time()})
        self.settings["shelf"] = shelf[:40]
        save_json(SETTINGS_FILE, self.settings)

    def shelf_open(self, item):
        v = item["value"]
        if item["type"] == "file":
            if os.path.exists(v):
                extra.run_hidden(["explorer.exe", "/select," + v])
            else:
                self.show_toast("Файла уже нет на месте", "shelf", 2)
        elif v.lower().startswith(("http://", "https://", "www.")):
            os.startfile(v if not v.lower().startswith("www.") else "https://" + v)

    def shelf_remove(self, item):
        self.settings["shelf"] = [s for s in self.settings.get("shelf", []) if s is not item and s != item]
        save_json(SETTINGS_FILE, self.settings)

    def clip_action(self, what):
        p, self.clip_pill = self.clip_pill, None
        if not p:
            return
        link = p.get("link", True)
        url = p["text"] if p["text"].lower().startswith("http") else "https://" + p["text"]
        if what == "open":
            os.startfile(url)
        elif what == "qr":
            try:
                self.qr_show = {"matrix": isl_qr.encode(url if link else p["text"]), "text": p["text"], "start": time.time()}
            except ValueError:
                self.show_toast("Слишком длинно для QR-кода", "clip", 2)
        elif what in ("layout", "translit"):
            self.apply_text_tool(extra.swap_layout if what == "layout" else extra.translit,
                                 "Раскладка" if what == "layout" else "Транслит")
        elif what == "note":
            self.notes.insert(0, {"text": p["text"], "time": time.time()})
            save_json(NOTES_FILE, self.notes)
            self.show_toast("Ссылка в заметках", "notes", 1.5)
        elif what == "shelf":
            self.shelf_add("link", p["text"])
            self.show_toast("Ссылка на полке", "shelf", 1.5)

    def draw_clip_pill(self, x0, y0, w, h, a):
        c, S = self.cv, self.S
        p = self.clip_pill
        link = p.get("link", True)
        c.circle(x0 + 28 * S, y0 + 26 * S, 15 * S, with_alpha(BLUE, a))
        self.draw_icon("web" if link else "clip", x0 + 28 * S, y0 + 26 * S, 7.5 * S, with_alpha(WHITE, a))
        c.text("Скопирована ссылка" if link else "Скопировано", x0 + 52 * S, y0 + 9 * S, w - 96 * S, 18 * S,
               c.font(12.5, True), with_alpha(WHITE, a))
        preview = re.sub(r"^https?://(www\.)?", "", p["text"]) if link else p["text"].replace("\n", " ")
        c.text(preview, x0 + 52 * S, y0 + 27 * S, w - 96 * S, 16 * S, c.font(10.5), with_alpha(MUTED, a))
        bx = x0 + w - 26 * S
        c.text("✕", bx - 10 * S, y0 + 16 * S, 20 * S, 20 * S, c.font(12, True), with_alpha(MUTED, a), align=1)
        self.hit(bx - 14 * S, y0 + 10 * S, bx + 14 * S, y0 + 40 * S, lambda: setattr(self, "clip_pill", None), "any")
        if link:
            acts = [("Открыть", "open"), ("QR-код", "qr"), ("В заметки", "note"), ("На полку", "shelf")]
        else:
            acts = [("В заметки", "note"), ("Раскладка", "layout"), ("QR-код", "qr"), ("Транслит", "translit")]
        gap = 6 * S
        bw = (w - 28 * S - gap * 3) / 4
        for i, (label, what) in enumerate(acts):
            self.pill_button(label, x0 + 14 * S + i * (bw + gap), y0 + h - 40 * S, bw, 28 * S,
                             WHITE if i == 0 else argb(255, 52, 52, 68), DARK_TEXT if i == 0 else WHITE,
                             lambda w_=what: self.clip_action(w_), a)

    def draw_qr(self, x0, y0, w, h, a):
        """QR-код ссылки - наведи камеру телефона."""
        c, S = self.cv, self.S
        m = self.qr_show["matrix"]
        n = len(m)
        side = h - 46 * S
        cell = side / (n + 8)
        qx, qy = x0 + (w - side) / 2, y0 + 10 * S
        c.rrect(qx, qy, side, side, 10 * S, with_alpha(WHITE, a))
        for yy in range(n):
            for xx in range(n):
                if m[yy][xx]:
                    c.rect(qx + (xx + 4) * cell, qy + (yy + 4) * cell, cell + 0.6, cell + 0.6, with_alpha(argb(255, 10, 10, 14), a))
        c.text("Наведи камеру телефона · клик - закрыть", x0, y0 + h - 32 * S, w, 18 * S, c.font(10.5), with_alpha(MUTED, a), align=1)
        self.hit(x0, y0, x0 + w, y0 + h, lambda: setattr(self, "qr_show", None), "any")

    def page_shelf(self, x, y, w, a):
        c, S = self.cv, self.S
        shelf = self.settings.get("shelf", [])
        if not shelf:
            self.draw_icon("shelf", x + w / 2, y + 24 * S, 14 * S, with_alpha(DIM, a))
            c.text("Полка пустая", x, y + 46 * S, w, 22 * S, c.font(14, True), with_alpha(WHITE, a), align=1)
            c.text("Брось файл на островок → «На полку», или скопируй ссылку", x, y + 68 * S, w, 18 * S, c.font(11),
                   with_alpha(MUTED, a), align=1)
            return y + 96 * S
        for item in shelf[:8]:
            hot = self.mouse_over_rect(x, y, x + w, y + 34 * S)
            self.card(x, y, w, 34 * S, 10 * S, a)
            if hot:
                c.rrect(x, y, w, 34 * S, 10 * S, with_alpha(argb(20, 255, 255, 255), a))
            self.draw_icon("web" if item["type"] == "link" else "notes", x + 18 * S, y + 17 * S, 7 * S, with_alpha(self.ACC, a))
            c.text(item["name"], x + 34 * S, y, w - 70 * S, 34 * S, c.font(12), with_alpha(WHITE, a))
            self.hit(x, y, x + w - 30 * S, y + 34 * S, lambda it=item: self.shelf_open(it))
            dx = x + w - 28 * S
            c.text("✕", dx, y, 24 * S, 34 * S, c.font(12, True), with_alpha(DIM, a), align=1)
            self.hit(dx, y, dx + 24 * S, y + 34 * S, lambda it=item: self.shelf_remove(it))
            y += 38 * S
        c.text("Клик - открыть файл в папке или ссылку в браузере", x, y, w, 16 * S, c.font(10), with_alpha(DIM, a), align=1)
        return y + 22 * S

    def page_todo(self, x, y, w, a):
        c, S = self.cv, self.S
        y = self.draw_input(x, y, w, "todo", "Новая задача (Enter)", a) + 8 * S
        todos = self.settings.get("todos", [])
        if not todos:
            c.text("Задач нет — можно отдыхать", x, y + 4 * S, w, 20 * S, c.font(12), with_alpha(DIM, a), align=1)
            return y + 30 * S
        left = sum(1 for t in todos if not t.get("done"))
        c.text(f"Осталось: {left} из {len(todos)}", x + 2 * S, y, w, 16 * S, c.font(10.5, True), with_alpha(MUTED, a))
        y += 20 * S
        for i, t in enumerate(todos[:10]):
            done = t.get("done")
            self.card(x, y, w, 30 * S, 10 * S, a)
            cx_ = x + 16 * S
            if done:
                c.circle(cx_, y + 15 * S, 7 * S, with_alpha(GREEN, a))
                c.line(cx_ - 3.5 * S, y + 15 * S, cx_ - 1 * S, y + 17.5 * S, with_alpha(DARK_TEXT, a), 1.6 * S)
                c.line(cx_ - 1 * S, y + 17.5 * S, cx_ + 3.5 * S, y + 12 * S, with_alpha(DARK_TEXT, a), 1.6 * S)
            else:
                c.ring(cx_, y + 15 * S, 7 * S, with_alpha(MUTED, a), 1.4 * S)
            c.text(t["text"], x + 32 * S, y, w - 64 * S, 30 * S, c.font(12), with_alpha(DIM if done else WHITE, a))
            self.hit(x, y, x + w - 30 * S, y + 30 * S, lambda i=i: self.todo_toggle(i))
            dx = x + w - 28 * S
            c.text("✕", dx, y, 24 * S, 30 * S, c.font(12, True), with_alpha(DIM, a), align=1)
            self.hit(dx, y, dx + 24 * S, y + 30 * S, lambda i=i: self.todo_delete(i))
            y += 34 * S
        if any(t.get("done") for t in todos):
            self.button("Убрать сделанные", x + w / 2 - 70 * S, y + 2 * S, 140 * S, 24 * S, self.todo_clear_done, a,
                        font=c.font(10.5, True))
            y += 32 * S
        return y

    def todo_toggle(self, i):
        todos = self.settings.get("todos", [])
        if 0 <= i < len(todos):
            todos[i]["done"] = not todos[i].get("done")
            if todos[i]["done"]:
                self.show_toast("Сделано!", "star", 1.2)
            save_json(SETTINGS_FILE, self.settings)

    def todo_delete(self, i):
        todos = self.settings.get("todos", [])
        if 0 <= i < len(todos):
            todos.pop(i)
            save_json(SETTINGS_FILE, self.settings)

    def todo_clear_done(self):
        self.settings["todos"] = [t for t in self.settings.get("todos", []) if not t.get("done")]
        save_json(SETTINGS_FILE, self.settings)

    def copy_again(self, i):
        if 0 <= i < len(self.clips):
            text = self.clips[i]
            if set_clipboard_text(self.hwnd, text):
                self.clip_seq = user32.GetClipboardSequenceNumber()
                self.remember_clip(text)
                self.show_toast("Скопировано снова", "clip", 1.5)

    def week_data(self):
        """Сколько времени за компьютером за последние 7 дней: [(день недели, секунды, сегодня ли)]."""
        if time.time() - self.week[0] > 60:
            today = dt.date.today()
            rows = []
            for back in range(6, 0, -1):
                day = today - dt.timedelta(days=back)
                s = load_json(self.stats_path(day.isoformat()), {})
                rows.append((WEEKDAYS[day.weekday()], float(s.get("total", 0)) if isinstance(s, dict) else 0.0, False))
            self.week = (time.time(), rows)
        return self.week[1] + [(WEEKDAYS[dt.date.today().weekday()], self.stats["total"], True)]

    def update_extras(self):
        now = time.time()
        if now - self.privacy_at > 2:
            self.privacy_at = now
            try:
                self.privacy = extra.privacy_usage()
            except Exception:
                pass
        caps = bool(user32.GetKeyState(0x14) & 1)
        if self.caps is not None and caps != self.caps and self.ui.get("caps_toast", True):
            self.show_toast("Caps Lock включён" if caps else "Caps Lock выключен", "caps", 1.6)
        self.caps = caps
        try:
            for path in self.dlw.poll():
                self.push_notif({"id": None, "app": "Загрузки", "proc": "", "time": now, "icon": "download",
                                 "title": "Загрузка завершена", "body": os.path.basename(path), "path": path,
                                 "color": BLUE}, now)
        except Exception:
            traceback.print_exc()

    def is_dnd(self):
        return bool(self.ui.get("dnd")) or time.time() < float(self.ui.get("dnd_until", 0) or 0)

    def set_dnd_for(self, minutes):
        self.set_ui("dnd_until", time.time() + minutes * 60 if minutes else 0)
        if minutes:
            self.show_toast(f"Не беспокоить: {self.hm(minutes * 60)}", "moon", 2)

    def update_more(self, now):
        # долгие задачи (проценты в заголовках окон)
        try:
            for app in self.jobs.poll(now):
                self.push_notif({"id": None, "app": app, "proc": "", "time": now, "icon": "download", "color": GREEN,
                                 "title": "Готово", "body": f"{app}: задача закончилась"}, now)
        except Exception:
            traceback.print_exc()
        # громкость программ и устройства вывода - пока открыта вкладка «Музыка»
        if self.expanded and self.tab == "music":
            try:
                self.mix_apps = self.mixer.refresh()
            except Exception:
                self.mix_apps = []
            if now - getattr(self, "outs_at", 0) > 4:
                self.outs_at = now
                try:
                    self.outputs = more.output_devices()
                except Exception:
                    self.outputs = []
        # скорость интернета - пока открыта вкладка «Система»
        if self.expanded and self.tab == "system":
            try:
                self.net_speed = self.net.sample()
            except Exception:
                self.net_speed = None
        # программа на переднем плане (для «прятать поверх этой программы»)
        fg = user32.GetForegroundWindow()
        if fg and fg not in (self.hwnd, getattr(self, "side_hwnd", None)):
            pid = wt.DWORD()
            user32.GetWindowThreadProcessId(fg, ctypes.byref(pid))
            exe = isl_calls._exe_of(pid.value) if pid.value else ""
            self.cur_fg = exe
            if exe and exe not in ("explorer", "pythonw", "python", "shellexperiencehost", "searchhost", "startmenuexperiencehost"):
                self.last_fg = exe
        # заряд устройств: раз в 30 секунд (и чаще, пока открыта вкладка «Система»)
        if now - self.batt_at > (5 if self.expanded and self.tab == "system" else 30):
            self.batt_at = now
            self.update_batteries(now)
        # обновления: раз в 6 часов
        if now - self.upd_checked > 6 * 3600:
            self.check_update()
        ju = self.settings.get("just_updated")
        if ju and not self.toast:
            self.settings.pop("just_updated", None)
            save_json(SETTINGS_FILE, self.settings)
            self.push_notif({"id": None, "app": "Островок", "proc": "", "time": now, "icon": "star", "color": self.ACC,
                             "title": f"Обновился до {ju.get('version')}",
                             "body": " · ".join(ju.get("notes") or []) or "Новые функции уже работают"}, now)
        # календарь по ссылке: раз в 15 минут
        url = self.settings.get("ics_url")
        if url and now - self.cal_at > 900:
            self.cal_at = now
            threading.Thread(target=self.load_calendar, args=(url,), daemon=True).start()
        for start, title, allday in self.cal_events:
            if allday:
                continue
            left = (start - dt.datetime.now()).total_seconds()
            key = (start, title)
            if 0 < left <= 600 and key not in self.cal_notified:
                self.cal_notified.add(key)
                self.push_notif({"id": None, "app": "Календарь", "proc": "", "time": now, "icon": "calendar",
                                 "color": self.ACC2, "title": title,
                                 "body": f"через {max(1, round(left / 60))} мин · в {start:%H:%M}"}, now)

    # ---------- заряд устройств ----------
    def update_batteries(self, now):
        try:
            found = isl_battery.all_batteries()
        except Exception:
            found = []
        self.batteries = found
        names = {n for n, _ in found}
        if self.batt_seen is not None:
            # подключили наушники / мышь - как на iPhone: плашка с зарядом
            for name, pct in found:
                if name not in self.batt_seen:
                    self.push_notif({"id": None, "app": "Подключено", "proc": "", "time": now,
                                     "icon": isl_battery.kind_of(name), "color": BLUE,
                                     "title": name, "body": f"Заряд {pct}%"}, now)
        self.batt_seen = names
        for name, pct in found:
            if pct <= 15 and name not in self.batt_low:
                self.batt_low.add(name)
                self.push_notif({"id": None, "app": "Заряд", "proc": "", "time": now, "icon": isl_battery.kind_of(name),
                                 "color": RED, "title": f"{name} разряжается", "body": f"Осталось {pct}% — пора зарядить"}, now)
            elif pct >= 30:
                self.batt_low.discard(name)

    def draw_batteries(self, x, y, w, a):
        """Вкладка «Система»: заряд беспроводных устройств."""
        c, S = self.cv, self.S
        y = self.section_title("Заряд устройств", x, y, w, a)
        if not self.batteries:
            self.card(x, y, w, 40 * S, 14 * S, a)
            c.text("Беспроводные наушники, мышь или геймпад появятся тут", x, y, w, 40 * S, c.font(10.5),
                   with_alpha(DIM, a), align=1)
            return y + 50 * S
        rows = self.batteries[:5]
        self.card(x, y, w, len(rows) * 36 * S, 14 * S, a)
        for i, (name, pct) in enumerate(rows):
            ry = y + i * 36 * S
            col = GREEN if pct > 30 else (YELLOW if pct > 15 else RED)
            self.draw_icon(isl_battery.kind_of(name), x + 20 * S, ry + 18 * S, 7.5 * S, with_alpha(WHITE, a))
            c.text(name, x + 38 * S, ry, w - 150 * S, 36 * S, c.font(12, True), with_alpha(WHITE, a))
            bx = x + w - 104 * S
            c.rrect_outline(bx, ry + 12 * S, 34 * S, 13 * S, 3.5 * S, with_alpha(MUTED, a), 1.3 * S)
            c.rect(bx + 34.5 * S, ry + 16 * S, 2 * S, 5 * S, with_alpha(MUTED, a))
            c.rrect(bx + 2 * S, ry + 14 * S, max(2 * S, 30 * S * pct / 100), 9 * S, 2 * S, with_alpha(col, a))
            c.text(f"{pct}%", x + w - 62 * S, ry, 52 * S, 36 * S, c.font(12, True), with_alpha(col, a), align=2)
            if i < len(rows) - 1:
                c.line(x + 38 * S, ry + 36 * S, x + w - 10 * S, ry + 36 * S, with_alpha(WHITE, a * 0.06), 1 * S)
        return y + len(rows) * 36 * S + 10 * S

    # ---------- автообновление ----------
    def update_url(self):
        return (self.settings.get("update_url") or DEFAULT_UPDATE_URL or "").strip()

    def check_update(self, manual=False):
        url = self.update_url()
        if not url or self.upd_busy:
            if manual and not url:
                self.upd_state = "Адрес обновлений не задан"
            return
        self.upd_busy = True
        self.upd_checked = time.time()
        if manual:
            self.upd_state = "Проверяю…"

        def work():
            try:
                info = upd.check(url)
                self.upd_info = info
                if info:
                    self.upd_state = f"Есть версия {info['version']}"
                    if self.ui.get("auto_update", True) and not manual and not self.game:
                        self.upd_busy = False
                        self.install_update()
                        return
                    self.push_notif({"id": None, "app": "Островок", "proc": "", "time": time.time(), "icon": "download",
                                     "color": self.ACC, "title": f"Доступно обновление {info['version']}",
                                     "body": "Настройки → Ещё → Обновить", "open_tab": "settings"}, time.time())
                else:
                    self.upd_state = "У тебя последняя версия"
            except Exception as e:
                self.upd_state = "Не получилось проверить обновления"
                print("update check:", e)
            self.upd_busy = False
        threading.Thread(target=work, daemon=True).start()

    def install_update(self):
        info = self.upd_info
        if not info or self.upd_busy:
            return
        self.upd_busy = True

        def say(text):
            self.upd_state = text
        def work():
            try:
                upd.install(info, say)
                self.settings["just_updated"] = {"version": info["version"], "notes": info.get("notes", [])[:6]}
                save_json(SETTINGS_FILE, self.settings)
                say("Перезапускаю…")
                self.show_toast(f"Островок обновился до {info['version']} — перезапуск", "download", 3)
                time.sleep(1.5)
                upd.restart()
                self.running = False
            except Exception as e:
                say(f"Обновление не удалось: {e}")
                self.upd_busy = False
        threading.Thread(target=work, daemon=True).start()

    def load_calendar(self, url):
        try:
            self.cal_events = more.fetch_ics(url)
            self.cal_err = None
        except Exception as e:
            self.cal_err = "Не получилось загрузить календарь"
            print("calendar:", e)

    def hidden_by_app(self):
        apps = self.ui.get("hide_apps") or []
        return bool(apps) and getattr(self, "cur_fg", None) in apps

    def toggle_hide_app(self, exe):
        apps = list(self.ui.get("hide_apps") or [])
        if exe in apps:
            apps.remove(exe)
        else:
            apps.append(exe)
        self.set_ui("hide_apps", apps)

    def update_system(self):
        self.track_stats()
        self.update_more(time.time())
        self.check_pomo()
        self.check_reminders()
        self.update_extras()
        self.update_fps()
        idle, kern, usr = wt.FILETIME(), wt.FILETIME(), wt.FILETIME()
        if kernel32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kern), ctypes.byref(usr)):
            vals = [(f.dwHighDateTime << 32) | f.dwLowDateTime for f in (idle, kern, usr)]
            if self._cpu_prev:
                d = [a - b for a, b in zip(vals, self._cpu_prev)]
                if d[1] + d[2] > 0:
                    self.cpu = clamp(round(100 * (1 - d[0] / (d[1] + d[2]))), 0, 100)
            self._cpu_prev = vals
        mem = MEMORYSTATUSEX()
        mem.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        if kernel32.GlobalMemoryStatusEx(ctypes.byref(mem)):
            self.ram = mem.dwMemoryLoad
            self.ram_total = mem.total
        bat = self.battery()
        if bat:
            pct, ac = bat
            if self.last_ac is not None and ac != self.last_ac:
                self.show_toast(f"Зарядка подключена · {pct}%" if ac else f"Работа от батареи · {pct}%", "charge", 3)
            self.last_ac = ac
        seq = user32.GetClipboardSequenceNumber()
        if seq != self.clip_seq:
            self.clip_seq = seq
            if not user32.IsClipboardFormatAvailable(core.CF_PRIVATE):
                text = self.clipboard().strip()
                if text:
                    self.remember_clip(text)
                    link = bool(re.match(r"^(https?://|www\.)\S+$", text, re.I))
                    if self.ui.get("copy_island", True):
                        # скопировали - рядом с островком появляется второй островок-«копия» с кнопками,
                        # а сам островок остаётся как был (музыка, часы и т.д.)
                        now_ = time.time()
                        self.clip_pill = {"text": text, "link": link, "start": now_, "until": now_ + (8 if link else 5)}
                    else:
                        self.show_toast("Скопировано: " + text[:60], "clip", 2.5)
        if self.timer_end and time.time() >= self.timer_end:
            self.timer_end = None
            self.count("timers")
            self.show_toast("Время вышло!", "alarm", 8)
            try:
                import winsound
                winsound.PlaySound("SystemExclamation", winsound.SND_ALIAS | winsound.SND_ASYNC)
            except Exception:
                pass

    def music(self):
        st = self.media.state
        if st.get("status") in (None, "None", "Closed") or not st.get("title"):
            return None
        key = f"{st.get('artist')}|{st.get('title')}"
        if key != self.track_key:
            self.track_key = key
            self.lyrics, self.lyrics_state = [], "loading"
            self.lyric_idx, self.lyric_prev, self.lyric_anim = -1, "", 1.0
            artist, title, dur = st.get("artist", ""), st.get("title", ""), st.get("dur") or 0
            if st.get("status") == "Playing":
                if self.track_key_seen:
                    self.show_toast(f"{artist} — {title}".strip(" —"), "track", 3.5)
                self.count("tracks")
                # история прослушанного - для «Топ песен за неделю»
                hist = self.settings.setdefault("history", [])
                hist.append({"key": f"{artist} — {title}".strip(" —")[:120], "time": time.time()})
                del hist[:-400]
                save_json(SETTINGS_FILE, self.settings)
                if artist:
                    self.stats["artists"][artist] = self.stats["artists"].get(artist, 0) + 1
            self.track_key_seen = True    # первую песню после запуска карточкой не показываем

            def load(k=key):
                # если сервис текстов не ответил - пробуем снова каждые 30 секунд, пока играет эта песня
                while self.running and self.track_key == k:
                    lines, state = fetch_lyrics(LYRICS_DIR, artist, title, dur)
                    if self.track_key != k:
                        return
                    self.lyrics, self.lyrics_state = lines, state
                    if state != "error":
                        return
                    time.sleep(30)
            threading.Thread(target=load, daemon=True).start()
        return st

    def current_lyrics(self):
        """(строчка, следующая строчка, сколько строчки уже спето 0..1) или (None, None, None)"""
        if not self.lyrics or not (self.media.state.get("dur") or 0):
            return None, None, None
        pos = self.media.position() + 0.25
        idx = -1
        for i, (t, _) in enumerate(self.lyrics):
            if t <= pos:
                idx = i
            else:
                break
        if idx != self.lyric_idx:
            old = self.lyrics[self.lyric_idx][1] if self.lyric_idx >= 0 else ""
            self.lyric_prev, self.lyric_idx = old, idx
            self.lyric_anim = 0.0 if self.ui["anim"] else 1.0
        if idx < 0:
            return "♪", self.lyrics[0][1], None
        t0 = self.lyrics[idx][0]
        t1 = self.lyrics[idx + 1][0] if idx + 1 < len(self.lyrics) else t0 + 4
        frac = clamp((pos - t0) / max(0.3, (t1 - t0) * 0.9), 0, 1)
        nxt = self.lyrics[idx + 1][1] if idx + 1 < len(self.lyrics) else ""
        return (self.lyrics[idx][1] or "♪"), nxt, frac

    # ---------- значки ----------
    def draw_icon(self, name, cx, cy, r, col):
        c = self.cv
        lw = max(1.2, r * 0.17)
        if name == "music":
            c.circle(cx - r * 0.28, cy + r * 0.48, r * 0.32, col)
            c.line(cx + r * 0.03, cy + r * 0.48, cx + r * 0.03, cy - r * 0.75, col, lw)
            c.line(cx + r * 0.03, cy - r * 0.75, cx + r * 0.6, cy - r * 0.38, col, lw)
        elif name == "weather":
            c.circle(cx + r * 0.32, cy - r * 0.32, r * 0.3, YELLOW)
            c.circle(cx - r * 0.38, cy + r * 0.2, r * 0.33, col)
            c.circle(cx + r * 0.02, cy - r * 0.02, r * 0.45, col)
            c.circle(cx + r * 0.45, cy + r * 0.25, r * 0.28, col)
            c.rect(cx - r * 0.38, cy + r * 0.2, r * 0.83, r * 0.33, col)
        elif name in ("timer", "alarm"):
            c.ring(cx, cy + r * 0.1, r * 0.66, col, lw)
            c.line(cx, cy + r * 0.1, cx, cy - r * 0.3, col, lw)
            c.line(cx, cy + r * 0.1, cx + r * 0.3, cy + r * 0.28, col, lw)
            c.line(cx - r * 0.25, cy - r * 0.78, cx + r * 0.25, cy - r * 0.78, col, lw)
        elif name == "calendar":
            c.rrect_outline(cx - r * 0.7, cy - r * 0.55, r * 1.4, r * 1.3, r * 0.25, col, lw)
            c.line(cx - r * 0.7, cy - r * 0.18, cx + r * 0.7, cy - r * 0.18, col, lw)
            c.line(cx - r * 0.35, cy - r * 0.8, cx - r * 0.35, cy - r * 0.45, col, lw)
            c.line(cx + r * 0.35, cy - r * 0.8, cx + r * 0.35, cy - r * 0.45, col, lw)
            c.circle(cx - r * 0.25, cy + r * 0.25, r * 0.12, col)
            c.circle(cx + r * 0.25, cy + r * 0.25, r * 0.12, col)
        elif name == "notes":
            c.rrect_outline(cx - r * 0.55, cy - r * 0.75, r * 1.1, r * 1.5, r * 0.2, col, lw)
            for k in (-0.3, 0.05, 0.4):
                c.line(cx - r * 0.28, cy + r * k, cx + r * (0.28 if k < 0.3 else 0.08), cy + r * k, col, lw)
        elif name == "system":
            for k, hh in enumerate((0.55, 1.0, 1.4)):
                bx = cx - r * 0.65 + k * r * 0.48
                c.rrect(bx, cy + r * 0.7 - r * hh, r * 0.34, r * hh, r * 0.08, col)
        elif name == "clip":
            c.rrect_outline(cx - r * 0.6, cy - r * 0.7, r * 1.2, r * 1.55, r * 0.22, col, lw)
            c.rrect(cx - r * 0.3, cy - r * 0.88, r * 0.6, r * 0.32, r * 0.1, col)
            c.line(cx - r * 0.3, cy - r * 0.05, cx + r * 0.3, cy - r * 0.05, col, lw)
            c.line(cx - r * 0.3, cy + r * 0.35, cx + r * 0.15, cy + r * 0.35, col, lw)
        elif name == "pomo":
            c.circle(cx, cy + r * 0.12, r * 0.72, col)
            c.line(cx, cy - r * 0.55, cx + r * 0.3, cy - r * 0.95, GREEN, lw * 1.3)
            c.line(cx, cy - r * 0.55, cx - r * 0.35, cy - r * 0.8, GREEN, lw * 1.3)
        elif name in ("bell", "notifs"):
            c.arc(cx, cy + r * 0.05, r * 0.6, 180, 180, col, lw)
            c.line(cx - r * 0.6, cy + r * 0.05, cx - r * 0.75, cy + r * 0.5, col, lw)
            c.line(cx + r * 0.6, cy + r * 0.05, cx + r * 0.75, cy + r * 0.5, col, lw)
            c.line(cx - r * 0.75, cy + r * 0.5, cx + r * 0.75, cy + r * 0.5, col, lw)
            c.circle(cx, cy + r * 0.8, r * 0.14, col)
        elif name == "heart":
            col = argb((col >> 24) & 255, 255, 90, 140)
            c.circle(cx - r * 0.38, cy - r * 0.15, r * 0.42, col)
            c.circle(cx + r * 0.38, cy - r * 0.15, r * 0.42, col)
            c.polygon([(cx - r * 0.8, cy), (cx + r * 0.8, cy), (cx, cy + r * 0.85)], col)
        elif name == "game":
            c.rrect_outline(cx - r * 0.85, cy - r * 0.45, r * 1.7, r * 0.95, r * 0.42, col, lw)
            c.line(cx - r * 0.52, cy + r * 0.02, cx - r * 0.18, cy + r * 0.02, col, lw)
            c.line(cx - r * 0.35, cy - r * 0.15, cx - r * 0.35, cy + r * 0.19, col, lw)
            c.circle(cx + r * 0.3, cy - r * 0.08, r * 0.11, col)
            c.circle(cx + r * 0.5, cy + r * 0.13, r * 0.11, col)
        elif name == "summary":
            for k, ln in enumerate((1.3, 0.95, 0.6)):
                yy = cy - r * 0.55 + k * r * 0.55
                c.rrect(cx - r * 0.65, yy - r * 0.13, r * ln, r * 0.26, r * 0.13, col)
        elif name == "settings":
            for k in range(8):
                ang = k * math.pi / 4
                c.line(cx + math.cos(ang) * r * 0.5, cy + math.sin(ang) * r * 0.5,
                       cx + math.cos(ang) * r * 0.82, cy + math.sin(ang) * r * 0.82, col, lw * 1.7)
            c.ring(cx, cy, r * 0.48, col, lw * 1.5)
        elif name == "screenshot":
            c.rrect_outline(cx - r * 0.75, cy - r * 0.42, r * 1.5, r * 1.1, r * 0.25, col, lw)
            c.rrect(cx - r * 0.3, cy - r * 0.68, r * 0.6, r * 0.3, r * 0.08, col)
            c.ring(cx, cy + r * 0.12, r * 0.3, col, lw)
        elif name in ("vol_down", "vol_up", "mute"):
            c.rect(cx - r * 0.75, cy - r * 0.25, r * 0.32, r * 0.5, col)
            c.polygon([(cx - r * 0.45, cy - r * 0.25), (cx - r * 0.05, cy - r * 0.62),
                       (cx - r * 0.05, cy + r * 0.62), (cx - r * 0.45, cy + r * 0.25)], col)
            if name == "mute":
                c.line(cx + r * 0.2, cy - r * 0.28, cx + r * 0.75, cy + r * 0.28, col, lw)
                c.line(cx + r * 0.2, cy + r * 0.28, cx + r * 0.75, cy - r * 0.28, col, lw)
            else:
                c.arc(cx, cy, r * 0.38, -45, 90, col, lw)
                if name == "vol_up":
                    c.arc(cx, cy, r * 0.72, -45, 90, col, lw)
        elif name in ("phone", "phone_down"):
            # трубка: две «чашки» и дуга между ними
            if name == "phone_down":
                c.arc(cx, cy + r * 0.35, r * 0.75, 200, 140, col, lw * 2.2)
                c.rrect(cx - r * 0.9, cy - r * 0.05, r * 0.5, r * 0.36, r * 0.12, col)
                c.rrect(cx + r * 0.4, cy - r * 0.05, r * 0.5, r * 0.36, r * 0.12, col)
            else:
                c.arc(cx + r * 0.25, cy - r * 0.25, r * 0.85, 95, 80, col, lw * 2.2)
                c.polygon([(cx - r * 0.75, cy - r * 0.45), (cx - r * 0.45, cy - r * 0.8),
                           (cx - r * 0.2, cy - r * 0.5), (cx - r * 0.45, cy - r * 0.25)], col)
                c.polygon([(cx + r * 0.45, cy + r * 0.75), (cx + r * 0.8, cy + r * 0.45),
                           (cx + r * 0.5, cy + r * 0.2), (cx + r * 0.25, cy + r * 0.45)], col)
        elif name in ("mic", "mic_off"):
            c.rrect(cx - r * 0.25, cy - r * 0.8, r * 0.5, r * 0.95, r * 0.25, col)
            c.arc(cx, cy - r * 0.1, r * 0.48, 0, 180, col, lw)
            c.line(cx, cy + r * 0.38, cx, cy + r * 0.72, col, lw)
            c.line(cx - r * 0.3, cy + r * 0.72, cx + r * 0.3, cy + r * 0.72, col, lw)
            if name == "mic_off":
                c.line(cx - r * 0.7, cy - r * 0.8, cx + r * 0.7, cy + r * 0.8, argb(255, 255, 90, 90), lw * 1.3)
        elif name == "download":
            c.line(cx, cy - r * 0.75, cx, cy + r * 0.3, col, lw * 1.2)
            c.polygon([(cx - r * 0.42, cy + r * 0.0), (cx + r * 0.42, cy + r * 0.0), (cx, cy + r * 0.5)], col)
            c.line(cx - r * 0.7, cy + r * 0.8, cx + r * 0.7, cy + r * 0.8, col, lw * 1.2)
        elif name == "caps":
            c.polygon([(cx, cy - r * 0.8), (cx - r * 0.7, cy + r * 0.05), (cx - r * 0.3, cy + r * 0.05),
                       (cx - r * 0.3, cy + r * 0.45), (cx + r * 0.3, cy + r * 0.45), (cx + r * 0.3, cy + r * 0.05),
                       (cx + r * 0.7, cy + r * 0.05)], col)
            c.line(cx - r * 0.3, cy + r * 0.78, cx + r * 0.3, cy + r * 0.78, col, lw * 1.2)
        elif name in ("search", "command"):
            c.ring(cx - r * 0.15, cy - r * 0.15, r * 0.5, col, lw * 1.2)
            c.line(cx + r * 0.22, cy + r * 0.22, cx + r * 0.75, cy + r * 0.75, col, lw * 1.6)
        elif name == "wifi":
            for k in (0.3, 0.6, 0.9):
                c.arc(cx, cy + r * 0.55, r * k, 225, 90, col, lw * 1.1)
            c.circle(cx, cy + r * 0.5, r * 0.12, col)
        elif name == "bluetooth":
            pts = [(cx - r * 0.45, cy - r * 0.35), (cx + r * 0.4, cy + r * 0.38), (cx, cy + r * 0.8), (cx, cy - r * 0.8),
                   (cx + r * 0.4, cy - r * 0.38), (cx - r * 0.45, cy + r * 0.35)]
            for p0, p1 in zip(pts, pts[1:]):
                c.line(p0[0], p0[1], p1[0], p1[1], col, lw)
        elif name == "vpn":
            c.polygon([(cx, cy - r * 0.85), (cx + r * 0.7, cy - r * 0.5), (cx + r * 0.55, cy + r * 0.35),
                       (cx, cy + r * 0.85), (cx - r * 0.55, cy + r * 0.35), (cx - r * 0.7, cy - r * 0.5)], col)
        elif name == "shelf":
            c.rrect_outline(cx - r * 0.8, cy - r * 0.35, r * 1.6, r * 1.05, r * 0.2, col, lw)
            c.line(cx - r * 0.8, cy - r * 0.35, cx - r * 0.5, cy - r * 0.8, col, lw)
            c.line(cx + r * 0.8, cy - r * 0.35, cx + r * 0.5, cy - r * 0.8, col, lw)
            c.line(cx - r * 0.5, cy - r * 0.8, cx + r * 0.5, cy - r * 0.8, col, lw)
            c.line(cx - r * 0.3, cy + r * 0.1, cx + r * 0.3, cy + r * 0.1, col, lw)
        elif name == "todo":
            c.rrect_outline(cx - r * 0.75, cy - r * 0.75, r * 1.5, r * 1.5, r * 0.3, col, lw)
            c.line(cx - r * 0.38, cy, cx - r * 0.08, cy + r * 0.3, col, lw * 1.3)
            c.line(cx - r * 0.08, cy + r * 0.3, cx + r * 0.42, cy - r * 0.32, col, lw * 1.3)
        elif name == "headphones":
            c.arc(cx, cy + r * 0.1, r * 0.72, 180, 180, col, lw * 1.2)
            c.rrect(cx - r * 0.85, cy + r * 0.05, r * 0.42, r * 0.7, r * 0.15, col)
            c.rrect(cx + r * 0.43, cy + r * 0.05, r * 0.42, r * 0.7, r * 0.15, col)
        elif name == "mouse":
            c.rrect_outline(cx - r * 0.5, cy - r * 0.8, r * 1.0, r * 1.6, r * 0.5, col, lw)
            c.line(cx, cy - r * 0.6, cx, cy - r * 0.25, col, lw)
        elif name == "keyboard":
            c.rrect_outline(cx - r * 0.9, cy - r * 0.5, r * 1.8, r * 1.0, r * 0.2, col, lw)
            for k in (-0.5, 0, 0.5):
                c.circle(cx + r * k, cy - r * 0.15, r * 0.09, col)
            c.line(cx - r * 0.45, cy + r * 0.22, cx + r * 0.45, cy + r * 0.22, col, lw)
        elif name in ("gamepad", "device"):
            if name == "gamepad":
                self.draw_icon("game", cx, cy, r, col)
            else:
                c.rrect_outline(cx - r * 0.45, cy - r * 0.8, r * 0.9, r * 1.6, r * 0.2, col, lw)
                c.circle(cx, cy + r * 0.5, r * 0.1, col)
        elif name == "lock":
            c.rrect(cx - r * 0.6, cy - r * 0.1, r * 1.2, r * 0.9, r * 0.18, col)
            c.arc(cx, cy - r * 0.15, r * 0.38, 180, 180, col, lw * 1.2)
        elif name == "moon":
            c.circle(cx, cy, r * 0.7, col)
            c.circle(cx + r * 0.35, cy - r * 0.3, r * 0.6, self.BG_SOLID)
        elif name in ("power", "restart"):
            c.arc(cx, cy + r * 0.05, r * 0.62, -60 if name == "power" else -40, 300 if name == "power" else 280, col, lw * 1.2)
            if name == "power":
                c.line(cx, cy - r * 0.8, cx, cy - r * 0.05, col, lw * 1.2)
            else:
                c.polygon([(cx + r * 0.25, cy - r * 0.85), (cx + r * 0.75, cy - r * 0.5), (cx + r * 0.2, cy - r * 0.3)], col)
        elif name == "desktop":
            c.rrect_outline(cx - r * 0.8, cy - r * 0.6, r * 1.6, r * 1.05, r * 0.15, col, lw)
            c.line(cx, cy + r * 0.45, cx, cy + r * 0.75, col, lw)
            c.line(cx - r * 0.4, cy + r * 0.78, cx + r * 0.4, cy + r * 0.78, col, lw)
        elif name == "star":
            pts = []
            for k in range(10):
                ang = -math.pi / 2 + k * math.pi / 5
                rr = r * (0.9 if k % 2 == 0 else 0.4)
                pts.append((cx + math.cos(ang) * rr, cy + math.sin(ang) * rr))
            c.polygon(pts, col)
        elif name in ("app", "web", "more"):
            if name == "web":
                c.ring(cx, cy, r * 0.75, col, lw)
                c.line(cx - r * 0.75, cy, cx + r * 0.75, cy, col, lw * 0.8)
                c.arc(cx, cy, r * 0.75, 0, 360, col, lw * 0.5)
                c.line(cx, cy - r * 0.75, cx, cy + r * 0.75, col, lw * 0.8)
            else:
                for i in range(2):
                    for j in range(2):
                        c.rrect(cx - r * 0.7 + i * r * 0.78, cy - r * 0.7 + j * r * 0.78, r * 0.62, r * 0.62, r * 0.15, col)
        elif name == "chat":
            c.rrect(cx - r * 0.8, cy - r * 0.65, r * 1.6, r * 1.1, r * 0.35, col)
            c.polygon([(cx - r * 0.45, cy + r * 0.3), (cx - r * 0.1, cy + r * 0.3), (cx - r * 0.55, cy + r * 0.85)], col)
        elif name == "charge":
            c.polygon([(cx + r * 0.2, cy - r), (cx - r * 0.5, cy + r * 0.12), (cx - r * 0.06, cy + r * 0.12),
                       (cx - r * 0.2, cy + r), (cx + r * 0.5, cy - r * 0.12), (cx + r * 0.06, cy - r * 0.12)], GREEN)
        elif name == "clip":
            c.rrect_outline(cx - r * 0.6, cy - r * 0.7, r * 1.2, r * 1.55, r * 0.22, BLUE, lw)
            c.rrect(cx - r * 0.3, cy - r * 0.88, r * 0.6, r * 0.32, r * 0.1, BLUE)
            c.line(cx - r * 0.3, cy - r * 0.05, cx + r * 0.3, cy - r * 0.05, BLUE, lw)
            c.line(cx - r * 0.3, cy + r * 0.35, cx + r * 0.15, cy + r * 0.35, BLUE, lw)

    def weather_icon(self, cx, cy, kind, s=1.0, a=1.0):
        c = self.cv
        S = self.S * s
        sun, cloud = with_alpha(YELLOW, a), with_alpha(argb(255, 220, 225, 240), a)
        if kind in ("sun", "partly"):
            ox = oy = -3 * S if kind == "partly" else 0
            for k in range(8):
                ang = k * math.pi / 4 + time.time() * 0.3
                c.line(cx + ox + math.cos(ang) * 6 * S, cy + oy + math.sin(ang) * 6 * S,
                       cx + ox + math.cos(ang) * 8.5 * S, cy + oy + math.sin(ang) * 8.5 * S, sun, 1.6 * S)
            c.circle(cx + ox, cy + oy, 4.2 * S, sun)
        if kind == "moon":
            c.circle(cx, cy, 6 * S, sun)
            c.circle(cx + 3 * S, cy - 2.5 * S, 5 * S, self.BG_SOLID)
        if kind in ("partly", "cloud", "rain", "snow", "storm", "fog"):
            dx = 2 * S if kind == "partly" else 0
            c.circle(cx - 3 * S + dx, cy + 1 * S, 3.6 * S, cloud)
            c.circle(cx + 1 * S + dx, cy - 1.5 * S, 4.8 * S, cloud)
            c.circle(cx + 5 * S + dx, cy + 1.5 * S, 3.2 * S, cloud)
            c.rect(cx - 3 * S + dx, cy + 1 * S, 8 * S, 3.6 * S, cloud)
        if kind == "rain":
            t = time.time() * 2
            for i, k in enumerate((-3, 1, 5)):
                dy = ((t + i * 0.33) % 1) * 3 * S
                c.line(cx + k * S, cy + 6 * S + dy, cx + (k - 1) * S, cy + 8.5 * S + dy,
                       with_alpha(argb(255, 120, 180, 255), a), 1.5 * S)
        if kind == "snow":
            t = time.time()
            for i, k in enumerate((-3, 1, 5)):
                c.circle(cx + k * S, cy + 7 * S + ((t + i * 0.4) % 1) * 3 * S, 1.2 * S, cloud)
        if kind == "storm":
            c.polygon([(cx, cy + 4 * S), (cx - 2.5 * S, cy + 9 * S), (cx, cy + 8 * S), (cx - 1 * S, cy + 12 * S),
                       (cx + 3 * S, cy + 6.5 * S), (cx + 0.5 * S, cy + 7 * S)], sun)
        if kind == "fog":
            for k in (6, 9):
                c.line(cx - 6 * S, cy + k * S, cx + 7 * S, cy + k * S, cloud, 1.5 * S)

    # ---------- верхняя строка ----------
    def header_items(self):
        c, S, show = self.cv, self.S, self.ui["show"]
        now = dt.datetime.now()
        items = [("text", now.strftime("%H:%M:%S" if show["seconds"] else "%H:%M"), c.font(17, True), WHITE)]
        left = self.timer_left()
        if left is not None:
            items.append(("timer", f"{int(left // 60)}:{int(left % 60):02d}", c.font(14, True), YELLOW))
        if self.sw_running:
            s = self.stopwatch()
            items.append(("sw", f"{int(s // 60)}:{int(s % 60):02d}", c.font(14, True), BLUE))
        if self.pomo:
            pl = max(0, self.pomo["end"] - time.time())
            items.append(("pomo", f"{int(pl // 60)}:{int(pl % 60):02d}", c.font(14, True),
                          TOMATO if self.pomo["phase"] == "work" else GREEN))
        if self.game:
            played = time.time() - self.game["start"]
            label = f"{self.game['name']} · {self.hm(played) if played >= 60 else '0 м'}"
            p = self.ping_now()
            fps = f"{self.fps} FPS" if self.fps is not None else ""
            items.append(("game", (label, f"{p} мс" if p is not None else "— мс", self.ping_color(p), fps,
                                   self.fps_color(self.fps)), c.font(13, True), WHITE))
        lang = self.keyboard_lang()
        if lang != self.last_lang:
            if self.last_lang is not None:
                self.lang_flash = time.time()
            self.last_lang = lang
        if lang and show["lang"]:
            items.append(("chip", lang, c.font(11, True), WHITE))
        if self.weather and show["weather"]:
            items.append(("weather", self.weather, c.font(14, True), WHITE))
        if show["date"] and not self.game:      # в игре место нужнее для FPS и пинга
            items.append(("text", f"{WEEKDAYS[now.weekday()]}, {now.day} {MONTHS_SHORT[now.month - 1]}", c.font(14, True), WHITE))
        bat = self.battery()
        if bat and show["battery"]:
            items.append(("battery", bat, c.font(12, True), WHITE))
        dnd_left = float(self.ui.get("dnd_until", 0) or 0) - time.time()
        if dnd_left > 0 or self.ui.get("dnd"):
            items.append(("dnd", f"{int(dnd_left // 60) + 1} мин" if dnd_left > 0 else "", c.font(11.5, True), MUTED))
        mic, cam = self.privacy
        if (mic or cam) and self.ui.get("privacy_dots", True):
            # как на iPhone: оранжевая точка - кто-то слушает микрофон, зелёная - включена камера
            items.append(("privacy", (bool(mic), bool(cam)), None, WHITE))
        if self.ui.get("mini"):
            # «мини-островок» (как в Dyland): в покое только часы, а важное (таймер, игра, точки) остаётся
            items = items[:1] + [i for i in items[1:] if i[0] in ("timer", "sw", "pomo", "game", "privacy", "dnd")]
        out = []
        for kind, data, font, color in items:
            if kind == "privacy":
                w = (sum(data) * 11 - 3) * S
            elif kind == "dnd":
                w = 16 * S + (c.measure(data, font) + 3 * S if data else 0)
            elif kind == "text":
                w = c.measure(data, font)
            elif kind == "chip":
                w = c.measure(data, font) + 12 * S
            elif kind == "weather":
                w = 20 * S + c.measure(data[0], font)
            elif kind in ("timer", "sw", "pomo"):
                w = 18 * S + c.measure(data, font)
            elif kind == "game":
                w = 20 * S + c.measure(data[0], font) + 8 * S + c.measure(data[1], c.font(12, True))
                if data[3]:
                    w += 8 * S + c.measure(data[3], c.font(12, True))
            else:
                w = 26 * S + c.measure(f"{data[0]}%", font)
            out.append((kind, data, font, color, w))
        return out

    def draw_header(self, x0, y, w, h, items):
        c, S = self.cv, self.S
        gap = 13 * S
        total = sum(i[4] for i in items) + gap * (len(items) - 1)
        x = x0 + (w - total) / 2
        for kind, data, font, col, iw in items:
            if kind == "dnd":
                self.draw_icon("moon", x + 7 * S, y + h / 2, 7 * S, argb(255, 170, 150, 255))
                if data:
                    c.text(data, x + 16 * S, y, iw, h, font, col)
            elif kind == "privacy":
                dx = x + 4 * S
                for on, dcol in zip(data, (argb(255, 255, 159, 10), GREEN)):
                    if on:
                        glow = 0.5 + 0.5 * math.sin(time.time() * 3) if self.ui["anim"] else 0.5
                        c.circle(dx, y + h / 2, 6 * S, with_alpha(dcol, 0.18 + 0.12 * glow))
                        c.circle(dx, y + h / 2, 4 * S, dcol)
                        dx += 11 * S
            elif kind == "text":
                c.text(data, x, y, iw + 4 * S, h, font, col)
            elif kind == "chip":
                flash = max(0.0, 1 - (time.time() - self.lang_flash) / 0.8) if self.ui["anim"] else 0
                chip = self.ACC if flash > 0 else argb(255, 60, 60, 78)
                g = 3 * S * flash
                c.rrect(x - g, y + h / 2 - 10 * S - g, iw + g * 2, 20 * S + g * 2, 6 * S, chip)
                c.text(data, x, y, iw, h, font, col, align=1)
            elif kind in ("timer", "sw", "pomo"):
                if kind == "timer":
                    left = self.timer_left() or 0
                    frac = left / self.timer_total if self.timer_total else 0
                elif kind == "pomo":
                    frac = max(0, self.pomo["end"] - time.time()) / self.pomo["total"] if self.pomo else 0
                else:
                    frac = (self.stopwatch() % 60) / 60
                c.ring(x + 7 * S, y + h / 2, 6.5 * S, argb(255, 70, 70, 90), 2 * S)
                c.arc(x + 7 * S, y + h / 2, 6.5 * S, -90, 360 * frac, col, 2 * S)
                c.text(data, x + 17 * S, y, iw, h, font, col)
            elif kind == "weather":
                self.weather_icon(x + 8 * S, y + h / 2 - 1 * S, data[1])
                c.text(data[0], x + 19 * S, y, iw, h, font, col)
            elif kind == "game":
                label, ping, pcol, fps, fcol = data
                self.draw_icon("game", x + 8 * S, y + h / 2, 8 * S, self.ACC)
                lw_ = c.measure(label, font)
                c.text(label, x + 20 * S, y, lw_ + 4 * S, h, font, col)
                px = x + 28 * S + lw_
                if fps:
                    c.text(fps, px, y, iw, h, c.font(12, True), fcol)
                    px += c.measure(fps, c.font(12, True)) + 8 * S
                c.text(ping, px, y, iw, h, c.font(12, True), pcol)
            elif kind == "battery":
                pct, charging = data
                bx, by = x, y + h / 2 - 5.5 * S
                c.rrect_outline(bx, by, 19 * S, 11 * S, 3 * S, MUTED, 1.3 * S)
                c.rect(bx + 19.5 * S, by + 3.5 * S, 1.8 * S, 4 * S, MUTED)
                fill = GREEN if charging or pct > 30 else (YELLOW if pct > 15 else RED)
                c.rrect(bx + 2 * S, by + 2 * S, 15 * S * pct / 100, 7 * S, 1.5 * S, fill)
                c.text(f"{pct}%", bx + 24 * S, y, iw, h, font, col)
            x += iw + gap

    def update_audio(self, dtime):
        """Слушаем настоящий звук: быстро растёт, плавно падает. И замечаем смену громкости."""
        au = self.audio
        if not au:
            return
        try:
            au.refresh()
            peak = min(1.0, au.peak() * 1.6)
            vol = au.volume()
            mute = au.muted()
        except Exception:
            return
        self.level = peak if peak > self.level else self.level + (peak - self.level) * min(1.0, dtime * 7)
        t = time.time()
        for i in range(len(self.bands)):
            # у каждой полосы свой «ритм», но высота зависит от настоящего звука
            wob = 0.45 + 0.55 * abs(math.sin(t * (3.1 + (i % 5) * 0.9) + i * 0.8))
            target = self.level * wob * (1.15 - abs(i - 13.5) / 30)
            b = self.bands[i]
            self.bands[i] = target if target > b else b + (target - b) * min(1.0, dtime * 9)
        state = (round(vol or 0, 2), mute)
        if self.vol_seen is not None and state != self.vol_seen:
            self.vol_show = t + 1.6
        self.vol_seen = state

    def set_volume_at(self, x0, w):
        if not self.audio:
            return
        frac = clamp((self.click_xy[0] - x0) / w, 0, 1)
        self.audio.set_volume(frac)
        if frac > 0:
            self.audio.set_mute(False)

    def draw_equalizer(self, x, cy, playing, a=1.0):
        c, S, t = self.cv, self.S, time.time()
        for k in range(4):
            if playing and self.audio:
                v = self.bands[4 + k * 6]
                hh = (3 + v * 13) * S
            else:
                hh = (4 + (abs(math.sin(t * (5 + k * 1.3) + k)) * 9 if playing else 2)) * S
            c.rrect(x + k * 4.5 * S, cy - hh / 2, 3 * S, hh, 1.5 * S, with_alpha(self.ACC if k % 2 == 0 else self.ACC2, a))

    def draw_lyric(self, cur, frac, x, y, w, h, font, a=1.0):
        """Строчка песни: старая уезжает вверх, новая приезжает снизу, спетое подсвечивается."""
        c, S = self.cv, self.S
        k = self.lyric_anim
        col = self.lyric_color()
        shift = 12 * S
        if k < 1 and self.lyric_prev:
            c.text(self.lyric_prev, x, y - k * shift, w, h, font, with_alpha(col, a * (1 - k)), align=1)
        yy = y + (1 - k) * shift
        if self.ui["karaoke"] and frac is not None:
            tw = min(w, c.measure(cur, font))
            left = x + (w - tw) / 2
            c.text(cur, x, yy, w, h, font, with_alpha(argb(255, 120, 120, 140), a * k), align=1)
            c.clip_rect(left - 2 * S, yy - 6 * S, (tw + 4 * S) * frac, h + 12 * S)
            c.text(cur, x, yy, w, h, font, with_alpha(col, a * k), align=1)
            c.clip_rrect(*self.island_clip)
        else:
            c.text(cur, x, yy, w, h, font, with_alpha(col, a * k), align=1)

    # ---------- кнопки ----------
    def button(self, label, x, y, w, h, action, a, on=False, color=None, font=None):
        c, S = self.cv, self.S
        r = min(h / 2, 10 * S)
        c.rrect(x, y, w, h, r, with_alpha(self.ACC if on else (color or self.CARD), a))
        if self.expanded and self.mouse_over_rect(x, y, x + w, y + h):    # подсветка при наведении
            c.rrect(x, y, w, h, r, with_alpha(argb(40, 255, 255, 255), a))
            c.rrect_outline(x, y, w, h, r, with_alpha(argb(70, 255, 255, 255), a), 1 * S)
        c.text(label, x, y, w, h, font or c.font(12, True), with_alpha(DARK_TEXT if on else WHITE, a), align=1)
        self.hit(x, y, x + w, y + h, action)

    def card(self, x, y, w, h, r, a):
        """Карточка с лёгким объёмом: чуть светлее сверху и тонкая светлая кромка."""
        c, S = self.cv, self.S
        c.rrect(x, y, w, h, r, with_alpha(self.CARD, a))
        c.rrect_outline(x + 0.5 * S, y + 0.5 * S, w - S, h - S, r, with_alpha(argb(22, 255, 255, 255), a), 1 * S)

    def seg(self, x, y, w, options, current, pick, a, h=26):
        S, gap = self.S, 4 * self.S
        n = len(options)
        bw = (w - gap * (n - 1)) / n
        for i, (label, val) in enumerate(options):
            self.button(label, x + i * (bw + gap), y, bw, h * S, lambda v=val: pick(v), a, on=(val == current),
                        font=self.cv.font(11.5, True))
        return y + h * S

    def round_button(self, icon, cx, cy, r, action, a, filled=False):
        c = self.cv
        hot = self.expanded and self.mouse_over_rect(cx - r, cy - r, cx + r, cy + r)
        if hot:
            c.circle(cx, cy, r + 3 * self.S, with_alpha(self.ACC, a * 0.35))    # свечение при наведении
        if filled:
            c.circle(cx, cy, r, with_alpha(WHITE, a))
        else:
            c.circle(cx, cy, r, with_alpha(self.CARD, a))
            if hot:
                c.circle(cx, cy, r, with_alpha(argb(40, 255, 255, 255), a))
        col = with_alpha(self.BG_SOLID if filled else WHITE, a)
        if icon in ("play", "pause", "prev", "next"):
            rr = r * 0.62
            if icon == "play":
                c.polygon([(cx - rr * 0.35, cy - rr * 0.6), (cx - rr * 0.35, cy + rr * 0.6), (cx + rr * 0.6, cy)], col)
            elif icon == "pause":
                c.rrect(cx - rr * 0.45, cy - rr * 0.55, rr * 0.3, rr * 1.1, 1.5, col)
                c.rrect(cx + rr * 0.15, cy - rr * 0.55, rr * 0.3, rr * 1.1, 1.5, col)
            else:
                d = -1 if icon == "prev" else 1
                c.polygon([(cx - d * rr * 0.5, cy - rr * 0.55), (cx - d * rr * 0.5, cy + rr * 0.55), (cx + d * rr * 0.3, cy)], col)
                c.rect(cx + d * rr * 0.3 - (rr * 0.18 if d > 0 else 0), cy - rr * 0.55, rr * 0.18, rr * 1.1, col)
        else:
            self.draw_icon(icon, cx, cy, r * 0.6, col)
        self.hit(cx - r, cy - r, cx + r, cy + r, action)

    def draw_input(self, x, y, w, target, placeholder, a):
        c, S = self.cv, self.S
        ih = 32 * S
        active = self.typing == target
        c.rrect(x, y, w, ih, 10 * S, with_alpha(self.CARD, a))
        if active:
            c.rrect_outline(x, y, w, ih, 10 * S, with_alpha(self.ACC, a), 1.5 * S)
        caret = "|" if active and int(time.time() * 2) % 2 == 0 else ""
        if active and self.input_text:
            c.text(self.input_text + caret, x + 12 * S, y, w - 24 * S, ih, c.font(13), with_alpha(WHITE, a))
        else:
            c.text(caret + placeholder, x + 12 * S, y, w - 24 * S, ih, c.font(13), with_alpha(DIM, a))
        self.hit(x, y, x + w, y + ih, lambda: self.focus_input(target))
        return y + ih

    # ---------- разделы ----------
    def page_music(self, x, y, w, a):
        c, S = self.cv, self.S
        st = self.music()
        if not st:
            self.draw_icon("music", x + w / 2, y + 30 * S, 16 * S, with_alpha(DIM, a))
            c.text("Сейчас ничего не играет", x, y + 52 * S, w, 22 * S, c.font(14, True), with_alpha(WHITE, a), align=1)
            c.text("Включи Spotify, Яндекс Музыку или YouTube", x, y + 74 * S, w, 18 * S, c.font(11.5), with_alpha(MUTED, a), align=1)
            y += 100 * S
        else:
            playing = st.get("status") == "Playing"
            self.card(x, y, w, 70 * S, 14 * S, a)
            # жесты на карточке трека (как в Dyland): свайп - другой трек, двойной клик - пауза
            self.hit(x, y, x + w, y + 70 * S, self.start_cover_gesture)
            tx = x + 38 * S
            if self.cover:
                c.clip_rrect_intersect(x + 10 * S, y + 10 * S, 50 * S, 50 * S, 10 * S)
                c.image(self.cover.thumb, x + 10 * S, y + 10 * S, 50 * S, 50 * S)
                c.clip_rrect(*self.island_clip)
                tx = x + 70 * S
                self.draw_equalizer(x + w - 28 * S, y + 35 * S, playing, a)
            else:
                self.draw_equalizer(x + 14 * S, y + 35 * S, playing, a)
            c.text(st.get("title", ""), tx, y + 12 * S, x + w - tx - 34 * S, 22 * S, c.font(15, True), with_alpha(WHITE, a))
            c.text(st.get("artist", ""), tx, y + 34 * S, x + w - tx - 34 * S, 20 * S, c.font(12.5), with_alpha(MUTED, a))
            y += 80 * S
            cur, nxt, frac = self.current_lyrics()
            if cur is not None:
                self.draw_lyric(cur, frac, x, y, w, 28 * S, c.font(17, True), a)
                c.text(nxt, x, y + 28 * S, w, 22 * S, c.font(13), with_alpha(DIM, a), align=1)
            else:
                msg = {"loading": "ищу текст песни...", "none": "Для этой песни текста нет",
                       "error": "Нет связи с сервисом текстов (lrclib.net). Может помочь VPN"}.get(self.lyrics_state, "")
                c.text(msg, x, y + 12 * S, w, 24 * S, c.font(13), with_alpha(DIM, a), align=1)
            y += 56 * S
            # визуализатор: столбики танцуют, пока играет музыка
            nb = 28
            bw_ = (w - 20 * S) / nb
            tnow = time.time()
            for i in range(nb):
                if self.audio:
                    v = max(0.06, self.bands[i])      # настоящий звук
                elif playing and self.ui["anim"]:
                    v = abs(math.sin(tnow * (3.1 + (i % 5) * 0.9) + i * 0.8)) * abs(math.sin(tnow * 1.3 + i * 0.35))
                else:
                    v = 0.08
                bh = (3 + 19 * v) * S
                k = i / (nb - 1)
                col = argb(255, *[int(((self.ACC >> s) & 255) * (1 - k) + ((self.ACC2 >> s) & 255) * k) for s in (16, 8, 0)])
                c.rrect(x + 10 * S + i * bw_ + bw_ * 0.2, y + 22 * S - bh, bw_ * 0.6, bh, bw_ * 0.3, with_alpha(col, a * 0.9))
            y += 34 * S
            dur = st.get("dur") or 0
            if dur:
                pos = self.media.position()
                bar_x, bar_w = x + 40 * S, w - 80 * S
                hot = self.mouse_over_rect(bar_x, y - 8 * S, bar_x + bar_w, y + 12 * S)
                bh2 = (6 if hot else 4) * S
                c.rrect(bar_x, y, bar_w, bh2, bh2 / 2, with_alpha(argb(255, 60, 60, 80), a))
                c.rrect(bar_x - 2 * S, y - 2 * S, max(4 * S, bar_w * pos / dur) + 4 * S, bh2 + 4 * S, bh2, with_alpha(self.ACC, a * 0.25))
                c.rrect(bar_x, y, max(4 * S, bar_w * pos / dur), bh2, bh2 / 2, with_alpha(self.ACC, a))
                c.circle(bar_x + bar_w * pos / dur, y + bh2 / 2, (6 if hot else 4.5) * S, with_alpha(WHITE, a))

                def seek(bx=bar_x, bw=bar_w, d=dur):
                    frac = clamp((self.click_xy[0] - bx) / bw, 0, 1)
                    self.media.command(f"seek:{frac * d:.1f}")
                    # сразу показываем новое место, не дожидаясь ответа плеера
                    self.media.state["pos"], self.media.state["upd"] = frac * d, time.time() * 1000
                self.hit(bar_x, y - 8 * S, bar_x + bar_w, y + 12 * S, seek)
                f = c.font(11)
                c.text(f"{int(pos // 60)}:{int(pos % 60):02d}", x, y - 8 * S, 34 * S, 20 * S, f, with_alpha(MUTED, a), align=2)
                c.text(f"{int(dur // 60)}:{int(dur % 60):02d}", x + w - 34 * S, y - 8 * S, 34 * S, 20 * S, f, with_alpha(MUTED, a))
            y += 30 * S
            mid = x + w / 2
            self.round_button("prev", mid - 52 * S, y, 16 * S, lambda: self.media.command("prev"), a)
            self.round_button("pause" if playing else "play", mid, y, 21 * S, lambda: self.media.command("toggle"), a, filled=True)
            self.round_button("next", mid + 52 * S, y, 16 * S, lambda: self.media.command("next"), a)
            y += 32 * S
        y += 4 * S
        if self.audio and self.audio.vol:
            # ползунок громкости: клик ставит громкость в это место
            vol = self.audio.volume() or 0.0
            mute = self.audio.muted()
            self.round_button("mute" if mute or vol == 0 else "vol_up", x + 15 * S, y + 11 * S, 14 * S,
                              lambda m=mute: self.audio.set_mute(not m), a)
            sx, sw = x + 40 * S, w - 86 * S
            hot = self.mouse_over_rect(sx, y, sx + sw, y + 22 * S)
            th_ = (8 if hot else 6) * S
            c.rrect(sx, y + 11 * S - th_ / 2, sw, th_, th_ / 2, with_alpha(argb(255, 55, 55, 72), a))
            fill = 0 if mute else vol
            c.gradient_rect(sx, y + 11 * S - th_ / 2, max(th_, sw * fill), th_, self.ACC, self.ACC2, vertical=False)
            c.circle(sx + sw * fill, y + 11 * S, (7 if hot else 5.5) * S, with_alpha(WHITE, a))
            c.text(f"{round(fill * 100)}%", x + w - 42 * S, y, 42 * S, 22 * S, c.font(12, True), with_alpha(WHITE, a), align=2)
            self.hit(sx - 6 * S, y - 2 * S, sx + sw + 6 * S, y + 24 * S, lambda sx=sx, sw=sw: self.set_volume_at(sx, sw))
        else:
            c.text("Громкость", x + 2 * S, y, w, 22 * S, c.font(12, True), with_alpha(MUTED, a))
            bx = x + w - 3 * 36 * S
            for i, (icon, vk) in enumerate((("vol_down", 0xAE), ("mute", 0xAD), ("vol_up", 0xAF))):
                self.round_button(icon, bx + i * 36 * S + 15 * S, y + 11 * S, 14 * S, lambda vk=vk: press_key(vk), a)
        return y + 30 * S

    @staticmethod
    def hm(sec):
        sec = int(sec)
        h, m = sec // 3600, (sec % 3600) // 60
        return (f"{h} ч {m} м" if h else f"{m} м") if sec >= 60 else "меньше минуты"

    def page_summary(self, x, y, w, a):
        c, S, st = self.cv, self.S, self.stats
        c.text("Сегодня за компьютером", x + 2 * S, y, w, 18 * S, c.font(12), with_alpha(MUTED, a))
        total = int(st["total"])
        h, m = total // 3600, (total % 3600) // 60
        # большое время: «6 ч 42 м»
        bx = x + 2 * S
        for val, unit in ((h, "ч"), (m, "м")):
            vs = str(val)
            vw = c.measure(vs, c.font(30, True))
            c.text(vs, bx, y + 18 * S, vw + 4 * S, 40 * S, c.font(30, True), with_alpha(WHITE, a))
            bx += vw + 2 * S
            c.text(unit, bx, y + 26 * S, 20 * S, 30 * S, c.font(15, True), with_alpha(MUTED, a))
            bx += 22 * S
        armed = time.time() - self.reset_armed < 3
        self.button("Точно сбросить?" if armed else "↻ Заново", x + w - 124 * S, y + 22 * S, 124 * S, 30 * S,
                    self.reset_stats, a, color=argb(255, 90, 35, 50) if armed else None)
        y += 66 * S

        top = sorted(st["apps"].items(), key=lambda kv: -kv[1])[:3]
        if not top:
            c.rrect(x, y, w, 40 * S, 12 * S, with_alpha(self.CARD, a))
            c.text("Пока пусто: поработай немного, и тут появятся программы", x, y, w, 40 * S, c.font(11.5),
                   with_alpha(MUTED, a), align=1)
            y += 46 * S
        for i, (name, sec) in enumerate(top):
            c.rrect(x, y, w, 32 * S, 10 * S, with_alpha(self.CARD, a))
            c.circle(x + 16 * S, y + 16 * S, 8 * S, with_alpha(argb(255, 60, 60, 78), a))
            c.text(str(i + 1), x + 8 * S, y, 16 * S, 32 * S, c.font(10.5, True), with_alpha(WHITE, a), align=1)
            hue = (sum(map(ord, name)) % 360) / 360
            c.rrect(x + 30 * S, y + 7 * S, 18 * S, 18 * S, 5 * S, with_alpha(hsv(hue, 0.55, 0.95), a))
            c.text(name[:1].upper(), x + 30 * S, y + 7 * S, 18 * S, 18 * S, c.font(11, True), with_alpha(DARK_TEXT, a), align=1)
            c.text(name, x + 54 * S, y, w - 190 * S, 32 * S, c.font(13, True), with_alpha(WHITE, a))
            pct = round(100 * sec / st["total"]) if st["total"] else 0
            c.text(self.hm(sec), x + w - 140 * S, y, 90 * S, 32 * S, c.font(12.5, True), with_alpha(WHITE, a), align=2)
            c.text(f"{pct}%", x + w - 46 * S, y, 36 * S, 32 * S, c.font(11.5), with_alpha(MUTED, a), align=2)
            y += 36 * S
        y += 4 * S

        fav = max(st["artists"].items(), key=lambda kv: kv[1])[0] if st["artists"] else ""
        cards = [
            (str(st["shots"]), f"{plural(st['shots'], 'скриншот', 'скриншота', 'скриншотов')} через остров"),
            (str(st["tracks"]), plural(st["tracks"], "трек", "трека", "треков") + (f" · чаще: {fav}" if fav else "")),
            (self.hm(st["music"]) if st["music"] >= 60 else "0 м", "играла музыка"),
            (str(st["timers"]), f"{plural(st['timers'], 'таймер', 'таймера', 'таймеров')} завершено"),
        ]
        half = (w - 8 * S) / 2
        for i, (big, small) in enumerate(cards):
            cx = x + (i % 2) * (half + 8 * S)
            cy = y + (i // 2) * 58 * S
            c.rrect(cx, cy, half, 52 * S, 12 * S, with_alpha(self.CARD, a))
            c.text(big, cx + 12 * S, cy + 5 * S, half - 20 * S, 26 * S, c.font(17, True), with_alpha(WHITE, a))
            c.text(small, cx + 12 * S, cy + 29 * S, half - 20 * S, 18 * S, c.font(10.5), with_alpha(MUTED, a))
        y += 2 * 58 * S + 6 * S
        # график за неделю
        c.text("За неделю", x + 2 * S, y, w, 20 * S, c.font(12, True), with_alpha(MUTED, a))
        y += 24 * S
        week = self.week_data()
        top_sec = max(max(sec for _, sec, _ in week), 1.0)
        cell = w / 7
        for i, (label, sec, is_today) in enumerate(week):
            bh = max(3 * S, 44 * S * sec / top_sec)
            bx = x + i * cell + cell * 0.22
            col = self.ACC if is_today else argb(255, 70, 70, 92)
            c.rrect(bx, y + 46 * S - bh, cell * 0.56, bh, 4 * S, with_alpha(col, a))
            if sec >= 60:
                hrs = sec / 3600
                txt = f"{hrs:.0f}ч" if hrs >= 10 else (f"{hrs:.1f}ч" if hrs >= 1 else f"{int(sec // 60)}м")
                c.text(txt, x + i * cell, y + 46 * S - bh - 15 * S, cell, 14 * S, c.font(9.5, True), with_alpha(WHITE if is_today else MUTED, a), align=1)
            c.text(label, x + i * cell, y + 48 * S, cell, 16 * S, c.font(10.5, is_today), with_alpha(self.ACC if is_today else MUTED, a), align=1)
        return y + 68 * S

    # ---------- мини-игра «Кот-бегун» ----------
    def runner_click(self):
        r = self.runner
        if not r or r["over"]:
            self.runner = {"y": 0.0, "vy": 0.0, "obs": [], "score": 0.0, "speed": 190.0, "over": False, "next": 0.9}
        elif r["y"] <= 0.5:
            r["vy"] = 380.0      # прыжок

    def draw_runner(self, x, y, w, a):
        c, S = self.cv, self.S
        gh = 92 * S
        self.card(x, y, w, gh, 14 * S, a)
        ground = y + gh - 16 * S
        c.line(x + 10 * S, ground, x + w - 10 * S, ground, with_alpha(argb(255, 80, 80, 104), a), 1.5 * S)
        best = self.settings.get("runner_best", 0)
        r = self.runner
        dtime = self.last_dt
        cat_x = x + 46 * S
        if r and not r["over"]:
            r["vy"] -= 1400 * dtime
            r["y"] = max(0.0, r["y"] + r["vy"] * dtime)
            if r["y"] == 0:
                r["vy"] = 0.0
            r["speed"] += 6 * dtime
            r["score"] += dtime * 10
            r["next"] -= dtime
            if r["next"] <= 0:
                r["obs"].append([w / S - 16.0, random.choice((14, 18, 24)), random.choice((10, 14))])
                r["next"] = random.uniform(0.75, 1.6) * 190 / r["speed"]
            for o in r["obs"]:
                o[0] -= r["speed"] * dtime
            r["obs"] = [o for o in r["obs"] if o[0] > -20]
            for o in r["obs"]:
                ox = x + o[0] * S
                if ox < cat_x + 7 * S and ox + o[2] * S > cat_x - 7 * S and r["y"] < o[1]:
                    r["over"] = True
                    if int(r["score"]) > best:
                        self.settings["runner_best"] = int(r["score"])
                        save_json(SETTINGS_FILE, self.settings)
                        self.show_toast(f"Новый рекорд в «Кот-бегуне»: {int(r['score'])}!", "game", 3)
        if r:
            for o in r["obs"]:
                ox = x + o[0] * S
                c.rrect(ox, ground - o[1] * S, o[2] * S, o[1] * S, 3 * S, with_alpha(self.ACC2, a))
        cat_y = ground - 9 * S - (r["y"] * S if r else 0)
        c.clip_rrect_intersect(x, y, w, gh, 14 * S)
        self.draw_pet(cat_x, cat_y, True)
        c.clip_rrect(*self.island_clip)
        score = int(r["score"]) if r else 0
        c.text(f"{score}", x + w - 90 * S, y + 6 * S, 78 * S, 20 * S, c.font(14, True), with_alpha(WHITE, a), align=2)
        c.text(f"рекорд {max(best, score if r and r['over'] else best)}", x + w - 130 * S, y + 24 * S, 118 * S, 16 * S,
               c.font(10.5), with_alpha(MUTED, a), align=2)
        c.text("Кот-бегун", x + 12 * S, y + 6 * S, 120 * S, 20 * S, c.font(13, True), with_alpha(WHITE, a))
        if not r or r["over"]:
            msg = "Нажми, чтобы играть. Клик = прыжок" if not r else "Ой! Нажми, чтобы играть снова"
            c.text(msg, x, y + 36 * S, w, 20 * S, c.font(12, True), with_alpha(YELLOW, a), align=1)
        self.hit(x, y, x + w, y + gh, self.runner_click)
        return y + gh + 10 * S

    def pet_cat(self):
        """Гладим котика: сердечки и мурчание."""
        px, py = self.pet_xy
        for i in range(5):
            self.hearts.append((px + random.uniform(-6, 6) * self.S, py, time.time() + i * 0.08, random.uniform(-1, 1)))
        if random.random() < 0.5:
            self.show_toast(random.choice(["Мррр~", "Мур-мур!", "Ещё погладь!", "Котик доволен"]), "heart", 1.6)

    def draw_hearts(self, now):
        c, S = self.cv, self.S
        keep = []
        for hx, hy, t0, drift in self.hearts:
            k = (now - t0) / 1.1
            if k < 0:
                keep.append((hx, hy, t0, drift))
                continue
            if k >= 1:
                continue
            keep.append((hx, hy, t0, drift))
            x, y, s = hx + drift * 16 * S * k, hy - 26 * S * k, (4 + 2 * math.sin(k * math.pi)) * S
            col = argb(int(255 * (1 - k)), 255, 80, 130)
            c.circle(x - s * 0.5, y, s * 0.55, col)
            c.circle(x + s * 0.5, y, s * 0.55, col)
            c.polygon([(x - s * 1.05, y + s * 0.15), (x + s * 1.05, y + s * 0.15), (x, y + s * 1.25)], col)
        self.hearts = keep

    def enable_fps(self):
        if isl_fps.start_helper():
            self.show_toast("Готово! FPS появится через пару секунд", "game", 3)
        else:
            self.show_toast("Windows не разрешила - FPS без этого не посчитать", "game", 3)

    def draw_fps_card(self, x, y, w, a):
        """FPS игры с графиком за минуту и нагрузка процессора, видеокарты и памяти."""
        c, S = self.cv, self.S
        self.card(x, y, w, 96 * S, 14 * S, a)
        f = self.fps
        c.text("FPS", x + 14 * S, y + 6 * S, 60 * S, 18 * S, c.font(11, True), with_alpha(MUTED, a))
        no_access = self.fpsm.denied and not isl_fps.helper_alive()
        if f is not None:
            c.text(str(f), x + 14 * S, y + 20 * S, 90 * S, 40 * S, c.font(28, True), with_alpha(self.fps_color(f), a))
        elif no_access:
            c.text("нет доступа", x + 14 * S, y + 24 * S, 110 * S, 30 * S, c.font(12, True), with_alpha(DIM, a))
        else:
            c.text("—", x + 14 * S, y + 20 * S, 90 * S, 40 * S, c.font(28, True), with_alpha(DIM, a))
        # график FPS за последнюю минуту
        gx, gy, gw, gh = x + 110 * S, y + 8 * S, w - 124 * S, 40 * S
        vals = [v for v in self.fps_hist if v is not None]
        top = max([60] + vals)
        if self.fps_hist:
            bw = gw / 60
            for i, v in enumerate(self.fps_hist[-60:]):
                if v is None:
                    continue
                hh = max(2 * S, gh * min(1.0, v / top))
                c.rect(gx + i * bw, gy + gh - hh, max(1 * S, bw * 0.75), hh, with_alpha(self.fps_color(v), a * 0.85))
            if vals:
                avg = sum(vals) / len(vals)
                c.text(f"средний {avg:.0f} · мин {min(vals)}", gx, gy + gh + 1 * S, gw, 14 * S, c.font(9.5), with_alpha(DIM, a), align=2)
        elif no_access:
            self.button("Включить FPS", gx + gw - 120 * S, gy + 8 * S, 120 * S, 26 * S, self.enable_fps, a, font=c.font(11, True))
            c.text("Windows один раз спросит разрешение", gx, gy + 36 * S, gw, 14 * S, c.font(9.5), with_alpha(DIM, a), align=2)
        else:
            c.text("Запусти игру - тут будет график", gx, gy, gw, gh, c.font(10.5), with_alpha(DIM, a), align=1)
        # процессор / видеокарта / память
        bars = [("ЦП", self.cpu), ("Видеокарта", round(self.gpu_pct) if self.gpu_pct is not None else None), ("ОЗУ", self.ram)]
        bw_ = (w - 28 * S - 16 * S) / 3
        for i, (name, val) in enumerate(bars):
            bx = x + 14 * S + i * (bw_ + 8 * S)
            by = y + 70 * S
            c.text(name, bx, by - 4 * S, bw_, 14 * S, c.font(9.5, True), with_alpha(MUTED, a))
            c.text("—" if val is None else f"{val}%", bx, by - 4 * S, bw_, 14 * S, c.font(9.5, True), with_alpha(WHITE, a), align=2)
            c.rrect(bx, by + 12 * S, bw_, 5 * S, 2.5 * S, with_alpha(argb(255, 55, 55, 72), a))
            if val:
                col = GREEN if val < 60 else (YELLOW if val < 85 else RED)
                c.rrect(bx, by + 12 * S, max(5 * S, bw_ * val / 100), 5 * S, 2.5 * S, with_alpha(col, a))
        return y + 104 * S

    def page_game(self, x, y, w, a):
        c, S = self.cv, self.S
        y = self.draw_runner(x, y, w, a)
        if self.game:
            played = time.time() - self.game["start"]
            c.text(self.game["name"], x + 2 * S, y, w, 26 * S, c.font(18, True), with_alpha(WHITE, a))
            c.text(f"Играешь {self.hm(played)}", x + 2 * S, y + 26 * S, w, 20 * S, c.font(12), with_alpha(MUTED, a))
        else:
            c.text("Сейчас не в игре", x + 2 * S, y, w, 26 * S, c.font(16, True), with_alpha(WHITE, a))
            c.text("Запусти игру, и включится игровой режим", x + 2 * S, y + 26 * S, w, 20 * S, c.font(12), with_alpha(MUTED, a))
        y += 54 * S
        y = self.draw_fps_card(x, y, w, a)
        p = self.ping_now()
        c.rrect(x, y, w, 56 * S, 12 * S, with_alpha(self.CARD, a))
        c.text("Пинг", x + 12 * S, y + 4 * S, 80 * S, 20 * S, c.font(12, True), with_alpha(WHITE, a))
        c.text(f"{p} мс" if p is not None else "—", x + w - 92 * S, y + 4 * S, 80 * S, 20 * S, c.font(13, True),
               with_alpha(self.ping_color(p), a), align=2)
        vals = self.pings[-30:]
        if vals:
            bw = (w - 24 * S) / 30
            for i, v in enumerate(vals):
                hh = 4 * S if v is None else max(3 * S, min(22 * S, v / 150 * 22 * S))
                c.rect(x + 12 * S + i * bw, y + 48 * S - hh, bw * 0.7, hh, with_alpha(self.ping_color(v), a))
        y += 64 * S
        c.text("Сегодня в играх", x + 2 * S, y, w, 20 * S, c.font(12, True), with_alpha(MUTED, a))
        y += 22 * S
        top = sorted(self.stats.get("games", {}).items(), key=lambda kv: -kv[1])[:3]
        if not top:
            c.text("Пока не играл", x + 2 * S, y, w, 20 * S, c.font(12), with_alpha(DIM, a))
            y += 24 * S
        for name, sec in top:
            c.rrect(x, y, w, 28 * S, 9 * S, with_alpha(self.CARD, a))
            c.text(name, x + 12 * S, y, w - 120 * S, 28 * S, c.font(12.5, True), with_alpha(WHITE, a))
            c.text(self.hm(sec), x + w - 112 * S, y, 100 * S, 28 * S, c.font(12), with_alpha(MUTED, a), align=2)
            y += 32 * S
        c.text("Напомнить о перерыве", x + 2 * S, y + 4 * S, w, 20 * S, c.font(12, True), with_alpha(MUTED, a))
        y += 26 * S
        return self.seg(x, y, w, [("Выкл", 0), ("30 мин", 30), ("60 мин", 60), ("90 мин", 90)], self.ui["break_min"],
                        lambda v: self.set_ui("break_min", v), a) + 8 * S

    def draw_weather_details(self, x, y, w, a, info):
        """Плитки как в Atoll: ветер с компасом, влажность, давление, УФ и солнце на дуге."""
        c, S = self.cv, self.S
        gap = 6 * S
        tw_ = (w - gap * 3) / 4
        th_ = 58 * S
        tiles = [("Ветер", f"{info.get('wind', '—')} м/с"), ("Влажность", f"{info.get('humidity', '—')}%"),
                 ("Давление", f"{info.get('pressure') or '—'} мм"),
                 ("УФ-индекс", "—" if info.get("uv") is None else f"{info['uv']:.0f}")]
        for i, (name, val) in enumerate(tiles):
            tx = x + i * (tw_ + gap)
            self.card(tx, y, tw_, th_, 12 * S, a)
            c.text(name, tx, y + 5 * S, tw_, 14 * S, c.font(9.5, True), with_alpha(MUTED, a), align=1)
            c.text(val, tx, y + 20 * S, tw_, 20 * S, c.font(12.5, True), with_alpha(WHITE, a), align=1)
            if name == "Ветер" and info.get("wind_dir") is not None:
                # стрелка: куда дует ветер
                ang = math.radians(info["wind_dir"] + 180 - 90)
                cx, cy = tx + tw_ / 2, y + 47 * S
                c.ring(cx, cy, 6 * S, with_alpha(DIM, a), 1 * S)
                c.line(cx - math.cos(ang) * 5 * S, cy - math.sin(ang) * 5 * S, cx + math.cos(ang) * 5 * S,
                       cy + math.sin(ang) * 5 * S, with_alpha(BLUE, a), 1.6 * S)
                c.circle(cx + math.cos(ang) * 5 * S, cy + math.sin(ang) * 5 * S, 1.8 * S, with_alpha(BLUE, a))
            elif name == "Влажность" and info.get("humidity") is not None:
                c.rrect(tx + 10 * S, y + 45 * S, tw_ - 20 * S, 4 * S, 2 * S, with_alpha(argb(255, 55, 55, 72), a))
                c.rrect(tx + 10 * S, y + 45 * S, max(4 * S, (tw_ - 20 * S) * info["humidity"] / 100), 4 * S, 2 * S,
                        with_alpha(BLUE, a))
            elif name == "УФ-индекс" and info.get("uv") is not None:
                uv = info["uv"]
                txt = "слабый" if uv < 3 else ("средний" if uv < 6 else "высокий")
                c.text(txt, tx, y + 39 * S, tw_, 14 * S, c.font(9.5), with_alpha(GREEN if uv < 3 else (YELLOW if uv < 6 else RED), a), align=1)
            elif name == "Давление" and info.get("pressure"):
                p = info["pressure"]
                txt = "норма" if 745 <= p <= 765 else ("низкое" if p < 745 else "высокое")
                c.text(txt, tx, y + 39 * S, tw_, 14 * S, c.font(9.5), with_alpha(MUTED, a), align=1)
        y += th_ + gap
        rise, sset = info.get("sunrise"), info.get("sunset")
        if rise and sset:
            # солнце на дуге: где оно сейчас между восходом и закатом
            self.card(x, y, w, 64 * S, 12 * S, a)
            try:
                now = dt.datetime.now()
                r = dt.datetime.combine(now.date(), dt.time(int(rise[:2]), int(rise[3:5])))
                s_ = dt.datetime.combine(now.date(), dt.time(int(sset[:2]), int(sset[3:5])))
                k = clamp((now - r).total_seconds() / max(1, (s_ - r).total_seconds()), 0, 1)
            except ValueError:
                k = 0.5
            cx, cy, rr = x + w / 2, y + 56 * S, 42 * S
            for j in range(24):
                a1 = math.pi + math.pi * j / 24
                a2 = math.pi + math.pi * (j + 0.5) / 24
                c.line(cx + math.cos(a1) * rr, cy + math.sin(a1) * rr, cx + math.cos(a2) * rr, cy + math.sin(a2) * rr,
                       with_alpha(DIM, a), 1.2 * S)
            ang = math.pi + math.pi * k
            sx, sy = cx + math.cos(ang) * rr, cy + math.sin(ang) * rr
            c.circle(sx, sy, 7 * S, with_alpha(YELLOW, a * 0.3))
            c.circle(sx, sy, 4.5 * S, with_alpha(YELLOW, a))
            c.text(f"Восход {rise}", x + 12 * S, y + 6 * S, 110 * S, 16 * S, c.font(10.5, True), with_alpha(WHITE, a))
            c.text(f"Закат {sset}", x + w - 122 * S, y + 6 * S, 110 * S, 16 * S, c.font(10.5, True), with_alpha(WHITE, a), align=2)
            if info.get("rain") is not None:
                c.text(f"Дождь сегодня: {info['rain']}%", x + 12 * S, y + 40 * S, 120 * S, 16 * S, c.font(10), with_alpha(MUTED, a))
            y += 72 * S
        return y

    def page_weather(self, x, y, w, a):
        c, S = self.cv, self.S
        if not self.settings.get("city"):
            c.text("Напиши свой город, чтобы видеть погоду", x, y, w, 22 * S, c.font(13), with_alpha(MUTED, a), align=1)
            return self.draw_input(x, y + 28 * S, w, "city", "Город... (Enter)", a) + 8 * S
        info = self.weather_info or {}
        if self.weather:
            self.weather_icon(x + 34 * S, y + 32 * S, self.weather[1], s=2.4, a=a)
            c.text(self.weather[0], x + 72 * S, y + 6 * S, 110 * S, 50 * S, c.font(34, True), with_alpha(WHITE, a))
        city = self.settings.get("city_name") or self.settings["city"]
        c.text(city, x + 170 * S, y + 6 * S, w - 170 * S, 22 * S, c.font(14, True), with_alpha(WHITE, a))
        if "feels" in info:
            c.text(f"Ощущается {info['feels']}°  ·  ветер {info['wind']} м/с", x + 170 * S, y + 28 * S, w - 170 * S, 18 * S,
                   c.font(11.5), with_alpha(MUTED, a))
            c.text(f"Днём до {info['max']}°, ночью до {info['min']}°", x + 170 * S, y + 46 * S, w - 170 * S, 18 * S,
                   c.font(11.5), with_alpha(MUTED, a))
        elif info.get("error"):
            c.text(info["error"], x + 170 * S, y + 28 * S, w - 170 * S, 18 * S, c.font(11.5), with_alpha(RED, a))
        else:
            c.text("загружаю...", x + 170 * S, y + 28 * S, w - 170 * S, 18 * S, c.font(11.5), with_alpha(MUTED, a))
        y += 74 * S
        hours = info.get("hours") or []
        if hours:
            c.rrect(x, y, w, 70 * S, 14 * S, with_alpha(self.CARD, a))
            cell = w / len(hours)
            for i, (hh, temp, kind) in enumerate(hours):
                cx = x + i * cell + cell / 2
                c.text(hh[:2], x + i * cell, y + 4 * S, cell, 16 * S, c.font(10.5), with_alpha(MUTED, a), align=1)
                self.weather_icon(cx, y + 32 * S, kind, s=0.9, a=a)
                c.text(f"{temp}°", x + i * cell, y + 46 * S, cell, 18 * S, c.font(12, True), with_alpha(WHITE, a), align=1)
            y += 78 * S
        if info.get("humidity") is not None:
            y = self.draw_weather_details(x, y, w, a, info)
        if self.typing == "city":
            y = self.draw_input(x, y, w, "city", "Новый город... (Enter)", a) + 8 * S
        else:
            self.button("Сменить город", x + w / 2 - 70 * S, y, 140 * S, 26 * S, lambda: self.focus_input("city"), a)
            y += 34 * S
        return y

    def page_timer(self, x, y, w, a):
        c, S = self.cv, self.S
        left = self.timer_left()
        cx, cy, r = x + 52 * S, y + 46 * S, 40 * S
        c.ring(cx, cy, r, with_alpha(argb(255, 55, 55, 72), a), 6 * S)
        if left is not None and self.timer_total:
            c.arc(cx, cy, r, -90, 360 * left / self.timer_total, with_alpha(YELLOW, a), 6 * S)
        txt = f"{int((left or 0) // 60)}:{int((left or 0) % 60):02d}"
        c.text(txt, cx - r, cy - 14 * S, r * 2, 28 * S, c.font(18, True), with_alpha(YELLOW if left else WHITE, a), align=1)
        bx = x + 110 * S
        bw = (w - 110 * S - 8 * S) / 2
        for i, m in enumerate(TIMER_PRESETS):
            self.button(f"{m} мин", bx + (i % 2) * (bw + 8 * S), y + 6 * S + (i // 2) * 32 * S, bw, 26 * S,
                        lambda m=m: self.start_timer(m), a)
        self.button("+1 мин", bx, y + 70 * S, bw, 26 * S, self.add_minute, a)
        if left is not None:
            self.button("Стоп", bx + bw + 8 * S, y + 70 * S, bw, 26 * S, lambda: setattr(self, "timer_end", None), a,
                        color=argb(255, 90, 35, 50))
        y += 108 * S
        c.text("Секундомер", x + 2 * S, y, w, 22 * S, c.font(14, True), with_alpha(WHITE, a))
        y += 26 * S
        s = self.stopwatch()
        c.rrect(x, y, w, 46 * S, 14 * S, with_alpha(self.CARD, a))
        c.text(f"{int(s // 60):02d}:{int(s % 60):02d}.{int(s * 10) % 10}", x + 14 * S, y, 150 * S, 46 * S,
               c.font(22, True, "Consolas"), with_alpha(BLUE if self.sw_running else WHITE, a))
        self.button("Пауза" if self.sw_running else "Старт", x + w - 170 * S, y + 10 * S, 76 * S, 26 * S, self.sw_toggle, a,
                    on=not self.sw_running)
        self.button("Сброс", x + w - 88 * S, y + 10 * S, 76 * S, 26 * S, self.sw_reset, a)
        y += 56 * S
        # помодоро: 25 минут учёбы, 5 минут отдыха
        p = self.pomo
        self.card(x, y, w, 50 * S, 14 * S, a)
        self.draw_icon("pomo", x + 24 * S, y + 25 * S, 11 * S, with_alpha(TOMATO, a))
        if p:
            left = max(0, p["end"] - time.time())
            phase = "Учёба" if p["phase"] == "work" else "Перерыв"
            c.text(f"{phase} · {int(left // 60)}:{int(left % 60):02d}", x + 46 * S, y + 6 * S, w - 150 * S, 22 * S, c.font(14, True),
                   with_alpha(TOMATO if p["phase"] == "work" else GREEN, a))
            done = p["cycles"]
            c.text(f"сделано {done} {plural(done, 'подход', 'подхода', 'подходов')}", x + 46 * S, y + 26 * S, w - 150 * S, 18 * S,
                   c.font(11), with_alpha(MUTED, a))
        else:
            c.text("Помодоро", x + 46 * S, y + 6 * S, w - 150 * S, 22 * S, c.font(14, True), with_alpha(WHITE, a))
            c.text("25 минут учёбы, 5 минут отдыха", x + 46 * S, y + 26 * S, w - 140 * S, 18 * S, c.font(11), with_alpha(MUTED, a))
        self.button("Стоп" if p else "Старт", x + w - 88 * S, y + 12 * S, 76 * S, 26 * S, self.pomo_toggle, a, on=not p,
                    color=argb(255, 90, 35, 50) if p else None)
        return y + 58 * S

    def page_clip(self, x, y, w, a):
        c, S = self.cv, self.S
        if not self.clips:
            self.draw_icon("clip", x + w / 2, y + 22 * S, 14 * S, with_alpha(DIM, a))
            c.text("Пока пусто", x, y + 44 * S, w, 22 * S, c.font(14, True), with_alpha(WHITE, a), align=1)
            c.text("Скопируй что-нибудь (Ctrl+C), и текст появится тут", x, y + 66 * S, w, 18 * S, c.font(11.5), with_alpha(MUTED, a), align=1)
            return y + 92 * S
        # инструменты для последнего скопированного текста (как в Atoll): всё на этом компьютере
        c.text("С последним текстом:", x + 2 * S, y, w, 18 * S, c.font(11.5, True), with_alpha(MUTED, a))
        y += 20 * S
        n = len(extra.TEXT_TOOLS)
        gap = 4 * S
        bw = (w - gap * (n - 1)) / n
        for i, (title, fn) in enumerate(extra.TEXT_TOOLS):
            self.button(title, x + i * (bw + gap), y, bw, 26 * S, lambda f=fn, t=title: self.apply_text_tool(f, t), a,
                        font=c.font(10.5, True))
        y += 34 * S
        c.text("Нажми на текст, чтобы скопировать его снова", x + 2 * S, y, w, 18 * S, c.font(11.5), with_alpha(MUTED, a))
        y += 24 * S
        for i, text in enumerate(self.clips[:8]):
            hot = self.mouse_over_rect(x, y, x + w, y + 28 * S)
            c.rrect(x, y, w, 28 * S, 9 * S, with_alpha(self.CARD, a))
            if hot:
                c.rrect(x, y, w, 28 * S, 9 * S, with_alpha(argb(34, 255, 255, 255), a))
            c.text(str(i + 1), x + 4 * S, y, 20 * S, 28 * S, c.font(10.5, True), with_alpha(self.ACC, a), align=1)
            c.text(text.replace("\n", " "), x + 26 * S, y, w - 36 * S, 28 * S, c.font(12.5), with_alpha(WHITE, a))
            self.hit(x, y, x + w, y + 28 * S, lambda i=i: self.copy_again(i))
            y += 32 * S
        self.button("Очистить историю", x + w / 2 - 80 * S, y + 2 * S, 160 * S, 26 * S, lambda: self.clips.clear(), a)
        c.text("История хранится только до выключения островка", x, y + 32 * S, w, 18 * S, c.font(10.5), with_alpha(MUTED, a), align=1)
        return y + 54 * S

    # ---------- звонки и уведомления ----------
    @staticmethod
    def app_color(name):
        n = (name or "").lower()
        for key, col in (("telegram", argb(255, 42, 171, 238)), ("discord", argb(255, 88, 101, 242)),
                         ("whatsapp", argb(255, 37, 211, 102)), ("viber", argb(255, 115, 96, 242)),
                         ("vk", argb(255, 0, 119, 255)), ("zoom", argb(255, 45, 140, 255)),
                         ("teams", argb(255, 98, 100, 167)), ("skype", argb(255, 0, 175, 240))):
            if key in n:
                return col
        return hsv((sum(map(ord, n)) % 360) / 360, 0.55, 0.95)

    @staticmethod
    def proc_of(app, aumid=""):
        text = f"{app} {aumid}".lower()
        for key, proc in CALL_PROCS.items():
            if key in text:
                return proc
        return ""

    def who_from_titles(self, app, titles):
        """С кем разговор - по заголовку окна программы (что получится узнать)."""
        for t in titles or []:
            t = re.sub(r"\s*[-–—|]\s*(Discord|Telegram|WhatsApp|Viber|Zoom|Skype|Microsoft Teams|VK)\s*$", "", t, flags=re.I)
            t = re.sub(r"^\(\d+\)\s*", "", t).strip(" #@")
            if t and t.lower() not in (app.lower(), "telegram", "discord", "whatsapp", "zoom meeting", "zoom"):
                return t
        return ""

    def process_notif_events(self, now):
        w = self.notifw
        while self.scan_q:
            self.apply_tg_scan(now, self.scan_q.popleft())
        while w.events:
            ev = w.events.popleft()
            kind = ev.get("type")
            if kind == "notif":
                app = ev.get("app") or "Уведомление"
                item = {"id": ev.get("id"), "app": app, "proc": self.proc_of(app, ev.get("aumid", "")),
                        "title": (ev.get("title") or "").strip(), "body": (ev.get("body") or "").strip(), "time": now}
                text = f"{item['title']} {item['body']}"
                if item["proc"] and CALL_WORDS.search(text) and self.ui.get("calls", True):
                    who = item["title"]
                    if CALL_WORDS.search(who) and item["body"]:
                        who = item["body"]
                    item["who"] = re.sub(r"(?i)\s*(входящий|видео|аудио|голосовой)?\s*(звонок|вызов)\s*(от)?\s*", " ", who).strip(" :·-") or app
                    self.incoming = dict(item, start=now)
                    self.count("calls")
                    if not self.is_dnd():
                        try:
                            import winsound
                            pass    # без звука - уведомления и звонки показываются тихо
                        except Exception:
                            pass
                    continue
                if item["proc"]:
                    self.native_at[item["proc"].lower()] = now
                self.push_notif(item, now)
            elif kind == "gone":
                if self.incoming and self.incoming.get("id") == ev.get("id"):
                    self.incoming = None
            elif kind == "calls":
                fresh = {}
                for cl in ev.get("calls") or []:
                    proc = cl.get("proc", "")
                    old = self.calls.get(proc)
                    who = self.who_from_titles(cl.get("app", ""), cl.get("titles"))
                    if old:
                        fresh[proc] = dict(old, who=who or old.get("who", ""))
                        continue
                    if self.incoming and self.incoming.get("proc", "").lower() == proc:
                        who = self.incoming.get("who") or who
                        self.incoming = None
                    fresh[proc] = {"proc": proc, "app": cl.get("app", proc), "who": who, "start": now}
                ended = [c for p, c in self.calls.items() if p not in fresh]
                for c in ended:
                    if now - c["start"] < 5:     # мигнул микрофон - это не звонок
                        continue
                    self.show_toast(f"Звонок в {c['app']} завершён · {self.mmss(now - c['start'])}", "phone_down", 3)
                self.calls = fresh
            elif kind == "action":
                if ev.get("pressed"):
                    continue
                app = ev.get("app") or "программу"
                if ev.get("focused"):
                    self.show_toast(f"Открыл {app} — нажми кнопку там", "phone", 3)
                else:
                    self.show_toast(f"Не нашёл окно {app}", "phone", 3)
        self.side_notifs = [n for n in self.side_notifs if now < n["until"]]
        if self.incoming and now - self.incoming["start"] > 60:
            if self.incoming.get("hwnd"):
                self.call_dismissed.add(self.incoming["hwnd"])
            self.incoming = None

    def push_notif(self, item, now):
        self.notifs.insert(0, item)
        del self.notifs[30:]
        self.count("notifs")
        if self.ui.get("notifs", True) and not self.is_dnd() and not self.game:
            playing = self.media.state.get("status") == "Playing"
            side = bool(self.ui.get("two_drops", True) and playing and not self.expanded)
            self.side_notifs.insert(0, dict(item, until=now + 7, start=now, side=side))
            del self.side_notifs[4:]
            try:
                import winsound
                pass    # без звука - уведомления и звонки показываются тихо
            except Exception:
                pass

    def scan_tg_windows(self):
        """(в фоновом потоке) Окна Telegram: заголовок главного и картинки остальных -
        есть ли в них зелёная кнопка «ответить» и красная «сбросить»."""
        found = isl_calls.windows_of(TG_PROCS, hidden=True)
        fg = user32.GetForegroundWindow()
        fg_pid = wt.DWORD()
        user32.GetWindowThreadProcessId(fg, ctypes.byref(fg_pid))
        fg_exe = isl_calls._exe_of(fg_pid.value) if fg_pid.value else ""
        ml, mt, mr, mb = self.monitor
        res = {}
        for proc, wins in found.items():
            # главное окно - самое большое окно с заголовком (даже если Telegram спрятан в трей)
            titled = [wv for wv in wins if wv[1].strip() and wv[2][2] > 60 and wv[2][3] > 60]
            if not titled:
                continue
            vis = isl_calls.user32.IsWindowVisible
            with_unread = [wv for wv in titled if re.search(r"\(\d+\)\s*$", wv[1])]
            # спрятанное окно размером с экран - это просмотрщик фото, не главное окно
            normal = [wv for wv in titled if vis(wv[0]) or (wv[2][2] < (mr - ml) and wv[2][3] < (mb - mt))]
            pick = with_unread or normal or titled
            main = max(pick, key=lambda wv: wv[2][2] * wv[2][3])
            cands = []
            for hwnd, title, (x, y, w, h), iconic in wins:
                if hwnd == main[0] or iconic or w < 150 or h < 150 or not isl_calls.user32.IsWindowVisible(hwnd):
                    continue
                info = {"hwnd": hwnd, "title": title.replace("‎", "").replace("‏", "").strip(),
                        "w": w, "h": h, "green": None, "red": None, "blank": True}
                cap = isl_calls.capture_window(hwnd)
                if cap:
                    data, cw, ch = cap
                    info["blank"] = isl_calls.is_blank(data, cw, ch)
                    if not info["blank"]:
                        info["green"], info["red"] = isl_calls.find_call_buttons(0, 0, cw, ch, data=data)
                        if info["red"] and not info["green"] and hwnd not in self.dbg_saved:
                            # красная есть, а «Принять» не нашлась - сохраним полоску с кнопками, чтобы разобраться
                            self.dbg_saved.add(hwnd)
                            try:
                                isl_calls.save_strip(os.path.join(APP_DIR, "call_buttons.bmp"), data, cw, ch, info["red"])
                            except Exception:
                                traceback.print_exc()
                cands.append(info)
            res[proc] = {"main_title": main[1], "cands": cands, "fg": fg_exe == proc}
        return res

    def _net_loop(self):
        """Раз в 10 секунд: какой Wi-Fi и включён ли VPN - чтобы сказать, когда это поменялось."""
        prev = None
        while self.running:
            try:
                cur = extra.net_state()
            except Exception:
                cur = prev
            if prev is not None and cur != prev and self.ui.get("net_toast", True):
                (ssid0, vpn0), (ssid1, vpn1) = prev, cur
                now = time.time()
                if ssid1 != ssid0:
                    self.push_notif({"id": None, "app": "Сеть", "proc": "", "time": now, "icon": "wifi", "color": BLUE,
                                     "title": f"Wi‑Fi: {ssid1}" if ssid1 else "Wi‑Fi отключён",
                                     "body": "Подключено" if ssid1 else (f"Был {ssid0}" if ssid0 else "")}, now)
                if bool(vpn1) != bool(vpn0):
                    self.push_notif({"id": None, "app": "Сеть", "proc": "", "time": now, "icon": "vpn",
                                     "color": GREEN if vpn1 else MUTED, "title": "VPN включён" if vpn1 else "VPN выключен",
                                     "body": vpn1 or vpn0 or ""}, now)
            prev = cur
            self.vpn_now = cur[1] if cur else None
            for _ in range(20):
                if not self.running:
                    return
                time.sleep(0.5)

    def tab_badge(self, name):
        """Красная точка над вкладкой: там есть что-то новое (как в Dyland)."""
        now = time.time()
        if name == "notifs":
            return any(n["time"] > self.notifs_seen for n in self.notifs)
        if name == "calendar":
            return any(not ad and 0 < (s - dt.datetime.now()).total_seconds() < 3600 for s, _, ad in self.cal_events)
        if name == "settings":
            return bool(self.upd_info)
        if name == "todo":
            return False
        if name == "more":
            bar = self.bar_tabs()
            return any(self.tab_badge(t) for t, _ in TABS if t not in bar and t != "settings")
        return False

    def draw_week_top(self, x, y, w, a):
        """Итоги: что ты слушал чаще всего за неделю."""
        c, S = self.cv, self.S
        week_ago = time.time() - 7 * 86400
        counts = {}
        for h in self.settings.get("history", []):
            if h.get("time", 0) >= week_ago:
                counts[h["key"]] = counts.get(h["key"], 0) + 1
        top = sorted(counts.items(), key=lambda kv: -kv[1])[:5]
        y = self.section_title("Топ песен за неделю", x, y + 6 * S, w, a)
        if not top:
            c.text("Включи музыку - тут появятся любимые песни", x, y, w, 18 * S, c.font(11), with_alpha(DIM, a), align=1)
            return y + 26 * S
        self.card(x, y, w, len(top) * 30 * S, 12 * S, a)
        for i, (key, n) in enumerate(top):
            ry = y + i * 30 * S
            c.text(str(i + 1), x + 6 * S, ry, 22 * S, 30 * S, c.font(12, True), with_alpha(self.ACC, a), align=1)
            c.text(key, x + 30 * S, ry, w - 90 * S, 30 * S, c.font(11.5), with_alpha(WHITE, a))
            c.text(f"{n} {plural(n, 'раз', 'раза', 'раз')}", x + w - 64 * S, ry, 56 * S, 30 * S, c.font(10.5), with_alpha(MUTED, a), align=2)
        return y + len(top) * 30 * S + 10 * S

    def _scan_loop(self):
        while self.running:
            try:
                self.scan_q.append(self.scan_tg_windows())
            except Exception:
                traceback.print_exc()
            time.sleep(0.8)

    def debug_log(self, text):
        """Короткий журнал про окна звонков (без текста сообщений) - чтобы найти, почему звонок не виден."""
        try:
            path = os.path.join(APP_DIR, "calls_debug.log")
            if os.path.exists(path) and os.path.getsize(path) > 100_000:
                os.replace(path, path + ".old")
            with open(path, "a", encoding="utf-8") as f:
                f.write(dt.datetime.now().strftime("%d.%m %H:%M:%S ") + text + "\n")
        except OSError:
            pass

    def apply_tg_scan(self, now, res):
        """Главный поток: по результатам осмотра окон - непрочитанные и входящий звонок."""
        for proc, r in res.items():
            m = re.search(r"\((\d+)\)\s*$", r["main_title"])
            unread = int(m.group(1)) if m else 0
            prev = self.unread.get(proc)
            self.unread[proc] = unread
            if prev is not None and unread > prev and now - self.native_at.get(proc, 0) > 5:
                new = unread - prev
                self.push_notif({"id": None, "app": "Telegram", "proc": proc, "time": now,
                                 "title": "Новое сообщение" if new == 1 else f"Новых сообщений: {new}",
                                 "body": f"Непрочитанных всего: {unread}"}, now)
            known = self.tg_known.setdefault(proc, set())
            sig = ";".join(f"{c['w']}x{c['h']} t{len(c['title'])} {'G' if c['green'] else ''}{'R' if c['red'] else ''}"
                           f"{'blank' if c['blank'] else ''}" for c in r["cands"])
            if sig != self.tg_sig.get(proc):
                self.tg_sig[proc] = sig
                self.debug_log(f"{proc}: окна [{sig}] микрофон={'да' if proc in self.calls else 'нет'} "
                               f"телеграм_впереди={'да' if r['fg'] else 'нет'}")
            ringing = None
            for c in r["cands"]:
                if c["green"] and c["red"] and proc not in self.calls:
                    ringing = (c, "green")         # зелёная «ответить» рядом с красной «сбросить» - точно звонят
                    break
                if c["blank"] and c["hwnd"] not in known and not r["fg"] and proc not in self.calls:
                    ringing = (c, "new")           # картинку не снять: новое окно появилось само - скорее всего звонок
            hwnds = {c["hwnd"] for c in r["cands"]}
            self.tg_known[proc] = hwnds
            self.call_dismissed &= hwnds | {h for p, v in self.tg_known.items() if p != proc for h in v}
            if proc in self.calls and r["cands"] and r["cands"][0]["title"]:
                self.calls[proc]["who"] = r["cands"][0]["title"]
            inc = self.incoming
            mine = inc and inc.get("win") and inc.get("proc") == proc
            if ringing and self.ui.get("calls", True):
                c, how = ringing
                if c["hwnd"] in self.call_dismissed:
                    continue
                if mine and inc.get("hwnd") == c["hwnd"]:
                    if c["title"]:
                        inc["who"] = c["title"]
                    continue
                self.incoming = {"id": f"win:{c['hwnd']}", "app": "Telegram", "proc": proc,
                                 "who": c["title"] or "Telegram", "start": now, "hwnd": c["hwnd"], "win": True, "how": how}
                self.debug_log(f"{proc}: показал входящий звонок ({how})")
                self.count("calls")
                if not self.is_dnd():
                    try:
                        import winsound
                        pass    # без звука - уведомления и звонки показываются тихо
                    except Exception:
                        pass
            elif mine and (inc.get("how") == "green" or inc.get("hwnd") not in hwnds):
                # зелёная кнопка пропала (ответили/сбросили в самом Telegram) или окно закрылось
                self.incoming = None

    @staticmethod
    def mmss(sec):
        sec = int(max(0, sec))
        return f"{sec // 3600}:{sec % 3600 // 60:02d}:{sec % 60:02d}" if sec >= 3600 else f"{sec // 60}:{sec % 60:02d}"

    def call_action(self, act, proc, hwnd=None):
        if not proc:          # пример звонка
            if act != "focus":
                self.incoming = None
                self.show_toast("Звонок принят (пример)" if act == "accept" else "Звонок отклонён (пример)",
                                "phone" if act == "accept" else "phone_down", 2)
            return
        if act == "focus":
            self.notifw.command(f"focus:{proc}")
            return
        if hwnd:
            self.call_dismissed.add(hwnd)
        if act == "accept":
            self.incoming = None
        elif self.incoming and self.incoming.get("proc") == proc:
            self.incoming = None
        self.debug_log(f"{proc}: нажата кнопка {act}")
        self.show_toast("Принимаю звонок…" if act == "accept" else "Сбрасываю звонок…",
                        "phone" if act == "accept" else "phone_down", 1.5)

        def work():
            ok = False
            try:
                ok = isl_calls.press_call_button(proc, act, prefer=hwnd)
            except Exception:
                traceback.print_exc()
            if not ok:     # кнопку по цвету не нашли - пробуем через «специальные возможности» Windows
                self.notifw.command(f"{act}:{proc}")
        threading.Thread(target=work, daemon=True).start()

    def open_notif(self, item):
        if item in self.side_notifs:
            self.side_notifs.remove(item)
        if item.get("open_tab"):
            self.open_tab(item["open_tab"])
            self.settings_sect = "more"
        elif item.get("path"):
            # показываем файл в папке (сам файл не запускаем - вдруг это программа)
            extra.run_hidden(["explorer.exe", "/select," + item["path"]])
        elif item.get("proc"):
            self.notifw.command(f"focus:{item['proc']}")

    def island_notifs(self):
        """Уведомления, которые показывает сам островок (а не отдельная капля рядом)."""
        return [n for n in self.side_notifs if not n.get("side")]

    def demo_notif(self):
        now = time.time()
        item = {"id": None, "app": "Telegram", "proc": "", "time": now, "title": "Пример уведомления",
                "body": "Так будут выглядеть новые сообщения"}
        self.side_notifs.insert(0, dict(item, until=now + 7, start=now))
        del self.side_notifs[4:]

    def demo_call(self):
        self.incoming = {"id": "demo", "app": "Telegram", "proc": "", "who": "Пример звонка",
                         "start": time.time(), "demo": True}

    def close_notif(self, item):
        if item in self.side_notifs:
            self.side_notifs.remove(item)

    # ---------- окно справа ----------
    def side_click(self, x, y):
        for x0, y0, x1, y1, action, _g in reversed(self.side_hits):
            if x0 <= x <= x1 and y0 <= y <= y1:
                action()
                return

    def pill_button(self, label, x, y, w, h, bg, fg, action, a, bold=True):
        c, S = self.cv, self.S
        hot = self.mouse_over_rect(x, y, x + w, y + h)
        if hot:
            c.rrect(x - 1.5 * S, y - 1.5 * S, w + 3 * S, h + 3 * S, h / 2 + 1.5 * S, with_alpha(bg, a * 0.35))
        c.rrect(x, y, w, h, h / 2, with_alpha(bg, a))
        c.text(label, x, y, w, h, c.font(11.5, bold), with_alpha(fg, a), align=1)
        self.hit(x - 2 * S, y - 2 * S, x + w + 2 * S, y + h + 2 * S, action, "any")

    def draw_live_notif(self, x0, y0, w, h, a, now, n):
        """Уведомление прямо в островке: кружок-значок, имя жирным и текст серым."""
        c, S = self.cv, self.S
        if self.mouse_over_rect(x0, y0, x0 + w, y0 + h):
            n["until"] = max(n["until"], now + 2.5)       # навёл мышку - не исчезает
        cy = y0 + h / 2
        col = n.get("color") or self.app_color(n["app"])
        pop = 1 + 0.18 * math.sin(clamp((now - n["start"]) * 3, 0, 1) * math.pi) if self.ui["anim"] else 1
        c.circle(x0 + 28 * S, cy, 15 * S * pop, with_alpha(col, a))
        self.draw_icon(n.get("icon", "chat"), x0 + 28 * S, cy + 0.5 * S, 7.5 * S, with_alpha(WHITE, a))
        hide = self.ui.get("notif_hide")
        title = "Новое сообщение" if hide else (n["title"] or n["app"])
        body = n["app"] if hide else (n["body"] or n["app"])
        c.text(title, x0 + 52 * S, cy - 18 * S, w - 66 * S, 18 * S, c.font(13.5, True), with_alpha(WHITE, a))
        c.text(body.replace("\n", " "), x0 + 52 * S, cy - 1 * S, w - 66 * S, 17 * S, c.font(11.5), with_alpha(MUTED, a))
        self.hit(x0, y0, x0 + w, y0 + h, lambda it=n: self.open_notif(it), "any")

    def drop_action(self, what):
        files = self.drop["files"] if self.drop else []
        self.drop = None
        if not files:
            return
        try:
            if what == "zip":
                def work():
                    try:
                        out = more.make_zip(files)
                        self.push_notif({"id": None, "app": "Файлы", "proc": "", "time": time.time(), "icon": "download",
                                         "color": GREEN, "title": "ZIP готов", "body": os.path.basename(out), "path": out},
                                        time.time())
                    except Exception:
                        self.show_toast("Не получилось сжать", "clip", 2)
                threading.Thread(target=work, daemon=True).start()
                self.show_toast("Сжимаю в ZIP…", "download", 2)
            elif what == "copy":
                if more.copy_files_to_clipboard(self.hwnd, files):
                    self.clip_seq = user32.GetClipboardSequenceNumber()
                    self.show_toast("Файлы в буфере — вставь в Telegram, чат или папку (Ctrl+V)", "clip", 3)
            elif what == "path":
                text = "\n".join(files)
                if set_clipboard_text(self.hwnd, text):
                    self.clip_seq = user32.GetClipboardSequenceNumber()
                    self.show_toast("Путь скопирован", "clip", 2)
            elif what == "folder":
                extra.run_hidden(["explorer.exe", "/select," + files[0]])
            elif what == "shelf":
                for f in files[:20]:
                    self.shelf_add("file", f)
                self.show_toast(f"На полке: {len(files)}", "shelf", 1.5)
        except Exception:
            traceback.print_exc()

    def draw_drop(self, x0, y0, w, h, a):
        """Файл бросили на островок: что с ним сделать."""
        c, S = self.cv, self.S
        files = self.drop["files"]
        name = os.path.basename(files[0]) + (f" и ещё {len(files) - 1}" if len(files) > 1 else "")
        c.circle(x0 + 30 * S, y0 + 30 * S, 16 * S, with_alpha(self.ACC, a))
        self.draw_icon("clip", x0 + 30 * S, y0 + 30 * S, 8.5 * S, with_alpha(WHITE, a))
        c.text(name, x0 + 56 * S, y0 + 12 * S, w - 100 * S, 20 * S, c.font(13.5, True), with_alpha(WHITE, a))
        c.text(more.human_size(files) + " · что сделать?", x0 + 56 * S, y0 + 31 * S, w - 100 * S, 16 * S, c.font(11),
               with_alpha(MUTED, a))
        bx = x0 + w - 30 * S
        c.text("✕", bx - 10 * S, y0 + 12 * S, 20 * S, 20 * S, c.font(12, True), with_alpha(MUTED, a), align=1)
        self.hit(bx - 14 * S, y0 + 8 * S, bx + 14 * S, y0 + 36 * S, lambda: setattr(self, "drop", None), "any")
        acts = [("Сжать в ZIP", "zip"), ("Копировать", "copy"), ("На полку", "shelf"), ("Папка", "folder")]
        gap = 6 * S
        bw = (w - 28 * S - gap * (len(acts) - 1)) / len(acts)
        for i, (label, what) in enumerate(acts):
            self.pill_button(label, x0 + 14 * S + i * (bw + gap), y0 + h - 40 * S, bw, 28 * S,
                             WHITE if i == 0 else argb(255, 52, 52, 68), DARK_TEXT if i == 0 else WHITE,
                             lambda w_=what: self.drop_action(w_), a, bold=True)

    def draw_live_call(self, x0, y0, w, h, a, now, inc):
        """Входящий звонок прямо в островке: кто звонит и две кнопки - «Отклонить» и «Принять»."""
        c, S = self.cv, self.S
        col = self.app_color(inc["app"])
        cx, cy = x0 + 30 * S, y0 + 34 * S
        if self.ui["anim"]:
            for k in range(2):
                ph = ((now - inc["start"]) * 0.8 + k * 0.5) % 1
                c.circle(cx, cy, (16 + 12 * ph) * S, with_alpha(GREEN, a * 0.3 * (1 - ph)))
        c.circle(cx, cy, 16 * S, with_alpha(GREEN, a))
        wig = math.sin(now * 24) * 0.2 if self.ui["anim"] and (now * 1.1) % 1 < 0.45 else 0
        self.draw_icon("phone", cx + wig * 6 * S, cy, 8.5 * S, with_alpha(DARK_TEXT, a))
        c.text(f"{inc['app']} · входящий звонок", x0 + 56 * S, cy - 20 * S, w - 70 * S, 16 * S, c.font(11),
               with_alpha(col, a))
        c.text(inc.get("who") or inc["app"], x0 + 56 * S, cy - 4 * S, w - 70 * S, 22 * S, c.font(16, True), with_alpha(WHITE, a))
        proc, hwnd = inc.get("proc"), inc.get("hwnd")
        bh, bw = 28 * S, 104 * S
        by = y0 + h - bh - 12 * S
        bx = x0 + w - 14 * S - bw
        self.pill_button("Принять", bx, by, bw, bh, WHITE, DARK_TEXT,
                         lambda: self.call_action("accept", proc, hwnd), a)
        self.pill_button("Отклонить", bx - bw - 8 * S, by, bw, bh, argb(255, 74, 26, 32), RED,
                         lambda: self.call_action("decline", proc, hwnd), a)
        self.pill_button("Открыть", x0 + 14 * S, by, 84 * S, bh, argb(255, 44, 44, 56), WHITE,
                         lambda: self.call_action("focus", proc, hwnd), a, bold=False)

    def side_frame(self, now):
        """Рисует окошко справа. Возвращает True, пока что-то показывается/анимируется."""
        in_island = self.ui.get("notif_place", "island") == "island"
        cards = []
        if self.incoming and not in_island:
            cards.append(("incoming", self.incoming, 70))
        # «две капли»: уведомление во время музыки показываем отдельной каплей рядом с островком
        cards += [("notif", n, 66) for n in self.side_notifs if not in_island or n.get("side")]
        # скопировал текст или ссылку - второй островок-«копия»
        if self.clip_pill and self.ui.get("copy_island", True) and now < self.clip_pill.get("until", 0):
            cards.insert(0, ("clip", self.clip_pill, 92))
        if not cards:
            if self.side_shown:
                user32.ShowWindow(self.side_hwnd, 0)
                self.side_shown = False
            self.side_hits = []
            return False
        S = self.S
        # окошко стоит рядом с островком справа (если островок прижат вправо - слева от него)
        ix0, iy0, ix1, iy1 = self.island
        ml, mt, mr, mb = self.monitor
        from_left = self.ui["pos"] != "right"
        if from_left:
            sx = self.wx + ix1 + 4 * S
        else:
            sx = self.wx + ix0 - self.SW - 4 * S
        self.sx = int(clamp(sx, ml, mr - self.SW))
        self.sy = int(self.wy + iy0 - 8 * S)
        saved = (self.cv, self.hits, self.wx, self.wy)
        self.cv, self.hits, self.wx, self.wy = self.side_cv, [], self.sx, self.sy
        try:
            c = self.cv
            c.clear()
            y = 8 * S
            pad = 10 * S
            w = self.SW - pad * 2
            for kind, item, hh in cards:
                hh *= S
                k = clamp((now - item["start"]) / 0.35, 0, 1) if self.ui["anim"] else 1
                ease = 1 - (1 - k) ** 3
                fade = clamp((item["until"] - now) / 0.35, 0, 1) if kind in ("notif", "clip") else 1
                a = min(ease, fade)
                # выезжает «из островка»
                x0 = pad + (1 - ease) * (w + 20 * S) * (-1 if from_left else 1)
                over = self.mouse_over_rect(x0, y, x0 + w, y + hh)
                if over and kind in ("notif", "clip"):      # навёл мышку - не исчезает
                    item["until"] = max(item["until"], now + 2.5)
                for g in range(5):
                    gg = (5 - g) * 2.2 * S
                    c.rrect(x0 - gg / 2, y + 2 * S - gg / 3, w + gg, hh + gg / 1.5, 18 * S + gg / 2, argb(int(16 * a), 0, 0, 0))
                c.rrect(x0, y, w, hh, 18 * S, with_alpha(self.BG_SOLID, a * 0.96))
                col = BLUE if kind == "clip" else self.app_color(item.get("app", ""))
                c.gradient_rect(x0, y, w, min(hh, 22 * S), argb(int(26 * a), 255, 255, 255), argb(0, 255, 255, 255))
                c.rrect_outline(x0 + 0.5 * S, y + 0.5 * S, w - S, hh - S, 18 * S, with_alpha(col, a * (0.9 if kind == "incoming" else 0.45)),
                                (2 if kind == "incoming" else 1) * S)
                if kind == "incoming":
                    self.draw_incoming(x0, y + 5 * S, w, a, now, item)
                elif kind == "clip":
                    self.draw_clip_pill(x0, y, w, hh, a)
                else:
                    self.draw_notif(x0, y + 5 * S, w, a, now, item)
                y += hh + 8 * S
                if y > self.SH - 60 * S:
                    break
            self.side_hits = self.hits
        finally:
            self.cv, self.hits, self.wx, self.wy = saved
        self.side_blit()
        if not self.side_shown:
            user32.ShowWindow(self.side_hwnd, 4)     # SW_SHOWNOACTIVATE
            self.side_shown = True
        if self.side_shown:
            user32.SetWindowPos(self.side_hwnd, HWND_TOPMOST, 0, 0, 0, 0, 0x1 | 0x2 | 0x10)
        return True

    def toggle_mic(self):
        if not self.audio:
            return
        m = self.audio.mic_muted()
        if m is None:
            self.show_toast("Микрофон не найден", "mic_off", 2)
            return
        self.audio.set_mic_mute(not m)
        self.show_toast("Микрофон выключен" if not m else "Микрофон включён", "mic_off" if not m else "mic", 1.5)

    def app_badge(self, app, cx, cy, r, a):
        c, S = self.cv, self.S
        c.circle(cx, cy, r, with_alpha(self.app_color(app), a))
        letter = (app or "?").strip()[:1].upper()
        c.text(letter, cx - r, cy - r, r * 2, r * 2, c.font(round(r / S * 0.95, 1), True), with_alpha(WHITE, a), align=1)

    def draw_incoming(self, x0, y0, w, a, now, inc):
        c, S = self.cv, self.S
        cy = y0 + 30 * S
        col = self.app_color(inc["app"])
        if self.ui["anim"]:
            for k in range(2):
                ph = ((now - inc["start"]) * 0.9 + k * 0.5) % 1
                c.circle(x0 + 34 * S, cy, (18 + 14 * ph) * S, with_alpha(col, a * 0.35 * (1 - ph)))
        c.circle(x0 + 34 * S, cy, 18 * S, with_alpha(col, a))
        wig = math.sin(now * 22) * 0.18 if self.ui["anim"] and (now * 1.2) % 1 < 0.5 else 0
        self.draw_icon("phone", x0 + 34 * S + wig * 8 * S, cy, 10 * S, with_alpha(WHITE, a))
        c.text(f"Входящий звонок · {inc['app']}", x0 + 62 * S, cy - 19 * S, w - 170 * S, 16 * S, c.font(10.5, True), with_alpha(col, a))
        c.text(inc.get("who") or inc["app"], x0 + 62 * S, cy - 4 * S, w - 170 * S, 22 * S, c.font(15, True), with_alpha(WHITE, a))
        proc = inc.get("proc")
        for k, (act, icon, bg) in enumerate((("decline", "phone_down", RED), ("accept", "phone", GREEN))):
            bx = x0 + w - (84 - k * 46) * S
            hot = self.mouse_over_rect(bx - 19 * S, cy - 19 * S, bx + 19 * S, cy + 19 * S)
            c.circle(bx, cy, (19 if hot else 17) * S, with_alpha(bg, a))
            self.draw_icon(icon, bx, cy, 9 * S, with_alpha(WHITE, a))
            self.hit(bx - 21 * S, cy - 21 * S, bx + 21 * S, cy + 21 * S,
                     lambda act=act: self.call_action(act, proc, inc.get("hwnd")), "any")

    def draw_notif(self, x0, y0, w, a, now, n):
        c, S = self.cv, self.S
        cy = y0 + 25 * S
        self.app_badge(n["app"], x0 + 30 * S, cy, 15 * S, a)
        hide = self.ui.get("notif_hide")
        c.text(n["app"], x0 + 54 * S, cy - 21 * S, w - 160 * S, 16 * S, c.font(10.5, True), with_alpha(self.app_color(n["app"]), a))
        c.text("Новое сообщение" if hide else (n["title"] or n["app"]), x0 + 54 * S, cy - 6 * S, w - 100 * S, 20 * S,
               c.font(13.5, True), with_alpha(WHITE, a))
        if not hide and n["body"]:
            c.text(n["body"].replace("\n", " "), x0 + 54 * S, cy + 9 * S, w - 100 * S, 18 * S, c.font(11.5), with_alpha(MUTED, a))
        # полоска «сколько осталось»
        k = clamp((n["until"] - now) / 7, 0, 1)
        c.rrect(x0 + 54 * S, y0 + 52 * S, (w - 108 * S) * k, 2 * S, 1 * S, with_alpha(self.app_color(n["app"]), a * 0.7))
        ago = int(now - n["time"])
        c.text("сейчас" if ago < 60 else f"{ago // 60} мин", x0 + w - 100 * S, cy - 21 * S, 60 * S, 16 * S,
               c.font(10), with_alpha(DIM, a), align=2)
        bx = x0 + w - 26 * S
        hot = self.mouse_over_rect(bx - 12 * S, cy - 12 * S, bx + 12 * S, cy + 12 * S)
        if hot:
            c.circle(bx, cy, 11 * S, with_alpha(self.CARD, a))
        c.text("✕", bx - 10 * S, cy - 10 * S, 20 * S, 20 * S, c.font(12, True), with_alpha(WHITE if hot else MUTED, a), align=1)
        self.hit(bx - 14 * S, cy - 14 * S, bx + 14 * S, cy + 14 * S, lambda it=n: self.close_notif(it), "any")
        self.hit(x0, y0, bx - 14 * S, y0 + 54 * S, lambda it=n: self.open_notif(it), "any")

    def draw_call(self, x0, y0, w, a, now):
        c, S = self.cv, self.S
        call = next(iter(self.calls.values()))
        cy = y0 + 17 * S
        col = self.app_color(call["app"])
        c.circle(x0 + 26 * S, cy, 11 * S, with_alpha(GREEN, a))
        self.draw_icon("phone", x0 + 26 * S, cy, 6.5 * S, with_alpha(DARK_TEXT, a))
        text = f"{call['app']} · {self.mmss(now - call['start'])}"
        c.text(text, x0 + 44 * S, cy - 10 * S, w - 140 * S, 20 * S, c.font(13, True), with_alpha(col, a))
        tw = c.measure(text, c.font(13, True))
        if call.get("who"):
            c.text("с " + call["who"], x0 + 50 * S + tw, cy - 10 * S, w - 150 * S - tw, 20 * S, c.font(12.5), with_alpha(WHITE, a))
        self.hit(x0, y0, x0 + w - 96 * S, y0 + 34 * S, lambda p=call["proc"]: self.call_action("focus", p), "any")
        muted = self.audio.mic_muted() if self.audio else None
        bx = x0 + w - 72 * S
        c.circle(bx, cy, 13 * S, with_alpha(RED if muted else self.CARD, a))
        self.draw_icon("mic_off" if muted else "mic", bx, cy, 7.5 * S, with_alpha(WHITE, a))
        self.hit(bx - 15 * S, cy - 15 * S, bx + 15 * S, cy + 15 * S, self.toggle_mic, "any")
        bx += 36 * S
        c.circle(bx, cy, 13 * S, with_alpha(RED, a))
        self.draw_icon("phone_down", bx, cy, 7.5 * S, with_alpha(WHITE, a))
        self.hit(bx - 15 * S, cy - 15 * S, bx + 15 * S, cy + 15 * S, lambda p=call["proc"]: self.call_action("decline", p), "any")

    def page_notifs(self, x, y, w, a):
        c, S = self.cv, self.S
        ui = self.ui
        acc = self.notifw.access
        if self.calls:
            call = next(iter(self.calls.values()))
            c.rrect(x, y, w, 34 * S, 10 * S, with_alpha(self.CARD, a))
            self.draw_call(x - 6 * S, y, w + 12 * S, a, time.time())
            y += 42 * S
        if acc and acc != "Allowed":
            c.text("Нет доступа к уведомлениям Windows", x, y, w, 20 * S, c.font(12.5, True), with_alpha(RED, a))
            c.text("Параметры → Конфиденциальность → Уведомления → разрешить", x, y + 18 * S, w, 18 * S, c.font(11), with_alpha(MUTED, a))
            self.button("Открыть", x + w - 90 * S, y, 90 * S, 24 * S, lambda: os.startfile("ms-settings:privacy-notifications"), a)
            y += 44 * S
        if self.unread and not any(self.native_at.get(p) for p in self.unread):
            # Telegram показывает свои всплывашки, а не уведомления Windows - текст сообщений нам не виден
            c.rrect(x, y, w, 58 * S, 10 * S, with_alpha(self.CARD, a))
            c.text("Хочешь видеть текст сообщений из Telegram?", x + 10 * S, y + 4 * S, w - 20 * S, 18 * S,
                   c.font(11.5, True), with_alpha(BLUE, a))
            c.text("Telegram → Настройки → Уведомления и звуки →", x + 10 * S, y + 21 * S, w - 20 * S, 16 * S,
                   c.font(10.5), with_alpha(WHITE, a))
            c.text("включи «Использовать уведомления Windows»", x + 10 * S, y + 37 * S, w - 20 * S, 16 * S,
                   c.font(10.5), with_alpha(WHITE, a))
            y += 66 * S
        self.button("Показать пример", x, y, w / 2 - 4 * S, 26 * S, self.demo_notif, a)
        self.button("Пример звонка", x + w / 2 + 4 * S, y, w / 2 - 4 * S, 26 * S, self.demo_call, a)
        y += 34 * S
        if not self.notifs:
            self.draw_icon("bell", x + w / 2, y + 22 * S, 14 * S, with_alpha(DIM, a))
            c.text("Уведомлений пока нет", x, y + 44 * S, w, 22 * S, c.font(14, True), with_alpha(WHITE, a), align=1)
            c.text("Сюда попадут сообщения из Telegram, Discord, WhatsApp и др.", x, y + 66 * S, w, 18 * S,
                   c.font(11.5), with_alpha(MUTED, a), align=1)
            y += 96 * S
        else:
            for item in self.notifs[:6]:
                hot = self.mouse_over_rect(x, y, x + w, y + 40 * S)
                c.rrect(x, y, w, 40 * S, 10 * S, with_alpha(self.CARD, a))
                if hot:
                    c.rrect(x, y, w, 40 * S, 10 * S, with_alpha(argb(26, 255, 255, 255), a))
                self.app_badge(item["app"], x + 20 * S, y + 20 * S, 11 * S, a)
                ago = int((time.time() - item["time"]) // 60)
                when = "сейчас" if ago < 1 else (f"{ago} мин" if ago < 60 else dt.datetime.fromtimestamp(item["time"]).strftime("%H:%M"))
                head = item["app"] if ui.get("notif_hide") else (item["title"] or item["app"])
                c.text(head, x + 38 * S, y + 3 * S, w - 100 * S, 18 * S, c.font(12, True), with_alpha(WHITE, a))
                c.text(when, x + w - 60 * S, y + 3 * S, 52 * S, 18 * S, c.font(10.5), with_alpha(DIM, a), align=2)
                sub = "Новое сообщение" if ui.get("notif_hide") else (item["body"] or item["app"])
                c.text(sub.replace("\n", " "), x + 38 * S, y + 20 * S, w - 48 * S, 17 * S, c.font(11), with_alpha(MUTED, a))
                self.hit(x, y, x + w, y + 40 * S, lambda it=item: self.open_notif(it))
                y += 44 * S
            self.button("Очистить", x + w / 2 - 60 * S, y + 2 * S, 120 * S, 26 * S, lambda: self.notifs.clear(), a)
            y += 36 * S
        y = self.section_title("Где показывать", x, y + 4 * S, w, a)
        y = self.seg(x, y, w, [("Прямо в островке", "island"), ("Окошком сбоку", "side")],
                     ui.get("notif_place", "island"), lambda v: self.set_ui("notif_place", v), a, h=28) + 12 * S
        for k in ("notif_hide", "dnd"):
            ui.setdefault(k, False)
        y = self.setting_rows(x, y, w, [
            ("chat", "Показывать уведомления", "", "notifs"),
            ("phone", "Звонки", "Карточка с «Принять» и «Отклонить»", "calls"),
            ("lock", "Скрывать текст сообщений", "Видно только «Новое сообщение»", "notif_hide"),
            ("music", "Две капли", "Сообщение во время музыки - отдельной каплей рядом", "two_drops"),
            ("moon", "Не беспокоить", "Ничего не всплывает", "dnd")], a)
        y = self.section_title("Не беспокоить на время", x, y, w, a)
        left = float(ui.get("dnd_until", 0) or 0) - time.time()
        y = self.chips(x, y, w, [("30 минут", 30), ("1 час", 60), ("2 часа", 120), ("Выключить", 0)],
                       lambda v: v == 0 and left <= 0,
                       self.set_dnd_for, a)
        if left > 0:
            c.text(f"Тишина ещё {self.hm(left)}", x, y - 8 * S, w, 18 * S, c.font(11, True), with_alpha(self.ACC, a), align=1)
            y += 16 * S
        c.text("Уведомления не уходят с компьютера и забываются после выключения", x, y - 4 * S, w, 18 * S,
               c.font(10), with_alpha(DIM, a), align=1)
        return y + 24 * S

    def page_calendar(self, x, y, w, a):
        c, S = self.cv, self.S
        today = dt.date.today()
        mm = today.month - 1 + self.cal_offset
        year, month = today.year + mm // 12, mm % 12 + 1
        c.text(f"{MONTHS[month - 1]} {year}", x + 4 * S, y, w, 24 * S, c.font(15, True), with_alpha(WHITE, a))
        for k, (label, d) in enumerate((("‹", -1), ("›", 1))):
            bx = x + w - (52 - k * 26) * S
            self.button(label, bx, y + 1 * S, 22 * S, 22 * S, lambda d=d: setattr(self, "cal_offset", self.cal_offset + d), a,
                        font=c.font(15, True))
        y += 28 * S
        cell = w / 7
        for i, wd in enumerate(WEEKDAYS):
            c.text(wd, x + i * cell, y, cell, 18 * S, c.font(11, True), with_alpha(RED if i >= 5 else DIM, a), align=1)
        y += 20 * S
        for week in calendar.Calendar(0).monthdayscalendar(year, month):
            for i, day in enumerate(week):
                if not day:
                    continue
                cx = x + i * cell + cell / 2
                is_today = (year, month, day) == (today.year, today.month, today.day)
                if is_today:
                    c.circle(cx, y + 11 * S, 11 * S, with_alpha(self.ACC, a))
                col = DARK_TEXT if is_today else (argb(255, 255, 140, 150) if i >= 5 else argb(255, 210, 210, 225))
                c.text(str(day), x + i * cell, y, cell, 22 * S, c.font(12.5, is_today), with_alpha(col, a), align=1)
            y += 24 * S
        days = (dt.date(today.year + 1, 1, 1) - today).days
        c.text(f"До Нового года: {days} {plural(days, 'день', 'дня', 'дней')}", x, y + 2 * S, w, 20 * S,
               c.font(12, True), with_alpha(self.ACC2, a), align=1)
        y += 30 * S
        # события из твоего Google / Яндекс / Outlook календаря (по секретной ICS-ссылке, как в Atoll)
        y = self.section_title("Ближайшее", x, y, w, a)
        url = self.settings.get("ics_url")
        if self.typing == "ics" or not url:
            y = self.draw_input(x, y, w, "ics", "Вставь ICS-ссылку календаря (Ctrl+V, Enter)", a) + 4 * S
            c.text("Google: Настройки календаря → «Секретный адрес в формате iCal»", x, y, w, 16 * S, c.font(10), with_alpha(DIM, a), align=1)
            return y + 22 * S
        if self.cal_err:
            c.text(self.cal_err, x, y, w, 18 * S, c.font(11.5), with_alpha(RED, a), align=1)
            y += 22 * S
        evs = self.cal_events[:5]
        if not evs and not self.cal_err:
            c.text("Ближайшие две недели свободны" if self.cal_at else "загружаю...", x, y, w, 18 * S, c.font(11.5),
                   with_alpha(DIM, a), align=1)
            y += 22 * S
        for start, title, allday in evs:
            self.card(x, y, w, 30 * S, 10 * S, a)
            today = start.date() == dt.date.today()
            when = ("сегодня" if today else f"{start.day} {MONTHS_SHORT[start.month - 1]}") + ("" if allday else f" {start:%H:%M}")
            ww = c.measure(when, c.font(11, True)) + 4 * S
            c.text(when, x + 10 * S, y, ww, 30 * S, c.font(11, True), with_alpha(self.ACC if today else MUTED, a))
            c.text(title, x + 18 * S + ww, y, w - 28 * S - ww, 30 * S, c.font(12), with_alpha(WHITE, a))
            y += 34 * S
        self.button("Изменить ссылку", x + w / 2 - 66 * S, y + 2 * S, 132 * S, 24 * S, lambda: self.focus_input("ics"), a,
                    font=c.font(10.5, True))
        return y + 32 * S

    def page_notes(self, x, y, w, a):
        c, S = self.cv, self.S
        y = self.draw_input(x, y, w, "note", "Заметка или «18:00 сделать уроки»", a) + 4 * S
        c.text("Если начать со времени, островок напомнит в этот час", x + 2 * S, y, w, 16 * S, c.font(10.5), with_alpha(MUTED, a))
        y += 20 * S
        if not self.notes:
            c.text("Заметок пока нет", x, y + 4 * S, w, 20 * S, c.font(12), with_alpha(DIM, a), align=1)
            return y + 30 * S
        for i, note in enumerate(self.notes[:8]):
            c.rrect(x, y, w, 28 * S, 9 * S, with_alpha(self.CARD, a))
            rem = self.reminder_time(note["text"])
            if rem:   # напоминание: колокольчик и время цветом
                self.draw_icon("bell", x + 13 * S, y + 13 * S, 7 * S, with_alpha(YELLOW, a))
                ts = f"{rem[0]:02d}:{rem[1]:02d}"
                tw_ = c.measure(ts, c.font(12.5, True))
                c.text(ts, x + 24 * S, y, tw_ + 4 * S, 28 * S, c.font(12.5, True), with_alpha(YELLOW, a))
                c.text(rem[2], x + 30 * S + tw_, y, w - 62 * S - tw_, 28 * S, c.font(12.5), with_alpha(WHITE, a))
            else:
                c.circle(x + 12 * S, y + 14 * S, 3 * S, with_alpha(self.ACC2, a))
                c.text(note["text"], x + 22 * S, y, w - 54 * S, 28 * S, c.font(12.5), with_alpha(WHITE, a))
            dx = x + w - 28 * S
            c.text("✕", dx, y, 24 * S, 28 * S, c.font(12, True), with_alpha(DIM, a), align=1)
            self.hit(dx, y, dx + 24 * S, y + 28 * S, lambda i=i: self.delete_note(i))
            y += 32 * S
        if len(self.notes) > 8:
            c.text(f"и ещё {len(self.notes) - 8}...", x, y, w, 18 * S, c.font(11), with_alpha(DIM, a), align=1)
            y += 20 * S
        return y

    def delete_note(self, i):
        if 0 <= i < len(self.notes):
            del self.notes[i]
            save_json(NOTES_FILE, self.notes)

    def page_system(self, x, y, w, a):
        c, S = self.cv, self.S
        free, total, tfree = ctypes.c_uint64(), ctypes.c_uint64(), ctypes.c_uint64()
        kernel32.GetDiskFreeSpaceExW("C:\\", ctypes.byref(free), ctypes.byref(total), ctypes.byref(tfree))
        disk_used = round(100 * (1 - tfree.value / total.value)) if total.value else 0
        cards = [("Процессор", self.cpu, f"{self.cpu}%"),
                 ("Память", self.ram, f"{self.ram}%  из {getattr(self, 'ram_total', 0) / 2**30:.0f} ГБ"),
                 ("Диск C:", disk_used, f"свободно {tfree.value / 2**30:.0f} ГБ")]
        bat = self.battery()
        if bat:
            cards.append(("Батарея", bat[0], f"{bat[0]}%" + ("  ⚡ заряжается" if bat[1] else "")))
        for label, val, txt in cards:
            c.rrect(x, y, w, 44 * S, 12 * S, with_alpha(self.CARD, a))
            c.text(label, x + 12 * S, y + 3 * S, w / 2, 20 * S, c.font(12, True), with_alpha(WHITE, a))
            c.text(txt, x + w / 2, y + 3 * S, w / 2 - 12 * S, 20 * S, c.font(11.5), with_alpha(MUTED, a), align=2)
            good = label == "Батарея"
            col = (GREEN if val > 30 else RED) if good else (GREEN if val < 60 else (YELLOW if val < 85 else RED))
            c.rrect(x + 12 * S, y + 28 * S, w - 24 * S, 6 * S, 3 * S, with_alpha(argb(255, 55, 55, 72), a))
            c.rrect(x + 12 * S, y + 28 * S, max(6 * S, (w - 24 * S) * val / 100), 6 * S, 3 * S, with_alpha(col, a))
            y += 50 * S
        if self.net_speed:
            # скорость интернета прямо сейчас (как «Монитор» в Dyland)
            down, upl = self.net_speed
            c.rrect(x, y, w, 34 * S, 12 * S, with_alpha(self.CARD, a))
            c.text("Интернет", x + 12 * S, y, w / 3, 34 * S, c.font(12, True), with_alpha(WHITE, a))
            c.text(f"↓ {extra.fmt_bytes(down)}/с", x + w * 0.36, y, w * 0.3, 34 * S, c.font(12, True), with_alpha(GREEN, a))
            c.text(f"↑ {extra.fmt_bytes(upl)}/с", x + w * 0.68, y, w * 0.3, 34 * S, c.font(12, True), with_alpha(BLUE, a))
            y += 40 * S
        up = kernel32.GetTickCount64() // 1000
        hours, mins = up // 3600, (up % 3600) // 60
        c.text(f"Компьютер включён {hours} ч {mins} мин", x, y, w, 20 * S, c.font(12), with_alpha(MUTED, a), align=1)
        y += 22 * S
        mic, cam = self.privacy
        if mic or cam:
            parts = []
            if mic:
                parts.append("микрофон — " + ", ".join(mic))
            if cam:
                parts.append("камера — " + ", ".join(cam))
            c.text("Сейчас используют: " + "  ·  ".join(parts), x, y, w, 18 * S, c.font(11.5, True),
                   with_alpha(argb(255, 255, 159, 10), a), align=1)
            y += 22 * S
        # пункт управления (как в Atoll)
        now = time.time()
        icons_off = not extra.desktop_icons_visible()
        tiles = [[("wifi", "Wi‑Fi", lambda: os.startfile("ms-settings:network-wifi"), False),
                  ("bluetooth", "Bluetooth", lambda: os.startfile("ms-settings:bluetooth"), False),
                  ("vpn", "VPN", self.open_vpn, False),
                  ("desktop", "Чистый стол", self.toggle_clean_desktop, icons_off)],
                 [("screenshot", "Скриншот", self.take_screenshot, False),
                  ("lock", "Блокировка", lambda: user32.LockWorkStation(), False),
                  ("mute", "Без звука", lambda: press_key(0xAD), False),
                  ("moon", "Сон", lambda: self.power("sleep"), False)],
                 [("restart", "Точно? Ещё раз" if self.confirm.get("restart", 0) > now else "Перезагрузка",
                   lambda: self.power("restart"), self.confirm.get("restart", 0) > now),
                  ("power", "Точно? Ещё раз" if self.confirm.get("off", 0) > now else "Выключение",
                   lambda: self.power("off"), self.confirm.get("off", 0) > now)]]
        for row in tiles:
            n = len(row)
            gap = 6 * S
            tw_ = (w - gap * (n - 1)) / n
            th_ = 50 * S if n > 2 else 34 * S
            for i, (icon, label_, fn, on) in enumerate(row):
                tx = x + i * (tw_ + gap)
                hot = self.mouse_over_rect(tx, y, tx + tw_, y + th_)
                bg = self.ACC if on else (argb(255, 62, 62, 80) if hot else self.CARD)
                c.rrect(tx, y, tw_, th_, 12 * S, with_alpha(bg, a))
                fg = DARK_TEXT if on else WHITE
                if n > 2:
                    self.draw_icon(icon, tx + tw_ / 2, y + 18 * S, 8 * S, with_alpha(fg, a))
                    c.text(label_, tx, y + 29 * S, tw_, 18 * S, c.font(10.5, True), with_alpha(fg, a), align=1)
                else:
                    self.draw_icon(icon, tx + 20 * S, y + th_ / 2, 7.5 * S, with_alpha(RED if not on else fg, a))
                    c.text(label_, tx + 34 * S, y, tw_ - 40 * S, th_, c.font(11.5, True), with_alpha(fg, a))
                self.hit(tx, y, tx + tw_, y + th_, fn)
            y += th_ + gap
        return self.draw_batteries(x, y + 6 * S, w, a)

    # ---------- элементы интерфейса для настроек ----------
    def section_title(self, text, x, y, w, a):
        c, S = self.cv, self.S
        c.text(text.upper(), x + 4 * S, y, w, 16 * S, c.font(10, True), with_alpha(DIM, a))
        return y + 19 * S

    def switch(self, x, y, on, a, key):
        """Переключатель как на iPhone: дорожка и белый кружок, который плавно переезжает."""
        c, S = self.cv, self.S
        pos = self.sw_anim.get(key, 1.0 if on else 0.0)
        target = 1.0 if on else 0.0
        pos += (target - pos) * (0.35 if self.ui["anim"] else 1.0)
        if abs(pos - target) < 0.01:
            pos = target
        self.sw_anim[key] = pos
        tw_, th_ = 38 * S, 22 * S
        c.rrect(x, y, tw_, th_, th_ / 2, with_alpha(argb(255, 64, 64, 82), a))
        if pos > 0:
            c.rrect(x, y, tw_, th_, th_ / 2, with_alpha(self.ACC, a * pos))
        kx = x + th_ / 2 + pos * (tw_ - th_)
        c.circle(kx, y + th_ / 2 + 0.8 * S, 8.6 * S, argb(int(60 * a), 0, 0, 0))
        c.circle(kx, y + th_ / 2, 8.6 * S, with_alpha(WHITE, a))

    def setting_rows(self, x, y, w, rows, a):
        """Группа строк в одной карточке (как в настройках iPhone).
        rows: (значок, заголовок, подпись или "", ключ ui) или (значок, заголовок, подпись, None, кнопка, действие)."""
        c, S = self.cv, self.S
        heights = [(44 if r[2] else 38) * S for r in rows]
        total = sum(heights)
        self.card(x, y, w, total, 14 * S, a)
        yy = y
        for i, (r, hh) in enumerate(zip(rows, heights)):
            icon, title, sub, key = r[:4]
            hot = self.mouse_over_rect(x, yy, x + w, yy + hh)
            if hot:
                c.rrect(x + 2 * S, yy + 2 * S, w - 4 * S, hh - 4 * S, 11 * S, with_alpha(argb(18, 255, 255, 255), a))
            c.rrect(x + 10 * S, yy + hh / 2 - 12 * S, 24 * S, 24 * S, 7 * S, with_alpha(self.ACC, a * 0.22))
            self.draw_icon(icon, x + 22 * S, yy + hh / 2, 7 * S, with_alpha(self.ACC, a))
            if sub:
                c.text(title, x + 44 * S, yy + 4 * S, w - 110 * S, 20 * S, c.font(12.5, True), with_alpha(WHITE, a))
                c.text(sub, x + 44 * S, yy + 22 * S, w - 110 * S, 16 * S, c.font(10.5), with_alpha(MUTED, a))
            else:
                c.text(title, x + 44 * S, yy, w - 110 * S, hh, c.font(12.5, True), with_alpha(WHITE, a))
            if key:
                on = bool(self.ui.get(key, True))
                self.switch(x + w - 50 * S, yy + hh / 2 - 11 * S, on, a, key)
                self.hit(x, yy, x + w, yy + hh, lambda k=key: self.set_ui(k, not self.ui.get(k, True)))
            elif len(r) > 4:
                label, fn = r[4], r[5]
                bw = c.measure(label, c.font(11, True)) + 22 * S
                self.button(label, x + w - bw - 10 * S, yy + hh / 2 - 13 * S, bw, 26 * S, fn, a, font=c.font(11, True))
            if i < len(rows) - 1:
                c.line(x + 44 * S, yy + hh, x + w - 10 * S, yy + hh, with_alpha(argb(255, 255, 255, 255), a * 0.06), 1 * S)
            yy += hh
        return y + total + 12 * S

    def chips(self, x, y, w, options, is_on, pick, a, h=28):
        """Кнопки-«таблетки», которые сами переносятся на новую строку."""
        c, S = self.cv, self.S
        gap = 6 * S
        cx, cy = x, y
        f = c.font(11.5, True)
        for label, val in options:
            bw = c.measure(label, f) + 26 * S
            if cx + bw > x + w + 0.5 and cx > x:
                cx, cy = x, cy + (h + 6) * S
            on = is_on(val)
            hot = self.mouse_over_rect(cx, cy, cx + bw, cy + h * S)
            bg = self.ACC if on else (argb(255, 52, 52, 68) if hot else self.CARD)
            c.rrect(cx, cy, bw, h * S, h * S / 2, with_alpha(bg, a))
            if not on:
                c.rrect_outline(cx + 0.5 * S, cy + 0.5 * S, bw - S, h * S - S, h * S / 2, with_alpha(argb(26, 255, 255, 255), a), 1 * S)
            c.text(label, cx, cy, bw, h * S, f, with_alpha(DARK_TEXT if on else WHITE, a), align=1)
            self.hit(cx, cy, cx + bw, cy + h * S, lambda v=val: pick(v))
            cx += bw + gap
        return cy + h * S + 12 * S

    def swatches(self, x, y, w, options, current, pick, a):
        """Кружки-цвета с подписью; выбранный обведён."""
        c, S = self.cv, self.S
        n = len(options)
        cell = w / n
        for i, (key, name, c1, c2) in enumerate(options):
            cx = x + cell * i + cell / 2
            cy = y + 16 * S
            sel = key == current
            hot = self.mouse_over_rect(cx - 18 * S, y, cx + 18 * S, y + 50 * S)
            if sel:
                c.ring(cx, cy, 16.5 * S, with_alpha(WHITE, a), 2 * S)
            elif hot:
                c.ring(cx, cy, 16.5 * S, with_alpha(argb(255, 120, 120, 140), a), 1.5 * S)
            if c1 is None:          # радуга
                for k in range(12):
                    c.arc(cx, cy, 9 * S, k * 30, 31, with_alpha(hsv(k / 12, 0.75, 1.0), a), 6 * S)
            else:
                c.circle(cx, cy, 12.5 * S, with_alpha(c1, a))
                if c2 is not None:
                    c.polygon([(cx + 12.5 * S * math.cos(math.radians(d)), cy + 12.5 * S * math.sin(math.radians(d)))
                               for d in range(-45, 136, 15)], with_alpha(c2, a))
            c.text(name, cx - cell / 2, cy + 18 * S, cell, 16 * S, c.font(10, sel), with_alpha(WHITE if sel else MUTED, a), align=1)
            self.hit(cx - cell / 2, y, cx + cell / 2, y + 50 * S, lambda k=key: pick(k))
        return y + 56 * S

    def reset_settings(self):
        now = time.time()
        if self.confirm.get("reset", 0) < now:
            self.confirm["reset"] = now + 3
            return
        self.confirm.pop("reset", None)
        import copy
        self.ui = copy.deepcopy(DEFAULT_UI)
        self.settings["ui"] = self.ui
        save_json(SETTINGS_FILE, self.settings)
        self.set_ui("size", self.ui["size"])
        self.show_toast("Настройки сброшены", "settings", 2)

    def page_check(self, x, y, w, a):
        """«Проверка» (как в Atoll): что работает, что нет и почему - с кнопкой «исправить»."""
        c, S = self.cv, self.S
        good, warn, bad = GREEN, YELLOW, RED
        rows = []
        acc = self.notifw.access
        rows.append(("Уведомления Windows", "есть доступ" if acc == "Allowed" else ("проверяю..." if acc is None else "нет доступа"),
                     good if acc == "Allowed" else (warn if acc is None else bad),
                     None if acc == "Allowed" else ("Открыть", lambda: os.startfile("ms-settings:privacy-notifications"))))
        if self.unread and not any(self.native_at.get(p) for p in self.unread):
            rows.append(("Сообщения Telegram", "видно только «новое сообщение»", warn, None))
        if self.fpsm.denied and not isl_fps.helper_alive():
            rows.append(("FPS в играх", "нужно разрешение Windows", warn, ("Включить", self.enable_fps)))
        else:
            rows.append(("FPS в играх", "работает" if self.fps_started else "включится в игре", good, None))
        mic = self.audio.mic_muted() if self.audio else None
        rows.append(("Звук и микрофон", ("звук есть" if self.audio else "звук не найден") + (", микрофон есть" if mic is not None else ", микрофона нет"),
                     good if self.audio and mic is not None else warn, None))
        werr = (self.weather_info or {}).get("error")
        rows.append(("Погода", "работает" if self.weather and not werr else (werr or "ещё не загрузилась"),
                     good if self.weather and not werr else warn, None))
        lerr = self.lyrics_state == "error"
        rows.append(("Тексты песен", "lrclib.net недоступен — может помочь VPN" if lerr else "работает",
                     bad if lerr else good, None))
        hk = len(getattr(self, "hotkeys_ok", []))
        rows.append(("Горячие клавиши", f"работают {hk} из 3", good if hk == 3 else warn, None))
        rows.append(("Список программ", f"нашёл {len(self.apps.apps)}" if self.apps.loaded else "собираю...", good, None))
        self.card(x, y, w, len(rows) * 40 * S, 14 * S, a)
        for i, (title, status, col, fix) in enumerate(rows):
            ry = y + i * 40 * S
            c.circle(x + 16 * S, ry + 20 * S, 4.5 * S, with_alpha(col, a))
            c.text(title, x + 30 * S, ry + 3 * S, w - 120 * S, 18 * S, c.font(12, True), with_alpha(WHITE, a))
            c.text(status, x + 30 * S, ry + 20 * S, w - 120 * S, 16 * S, c.font(10.5), with_alpha(MUTED, a))
            if fix:
                bw = c.measure(fix[0], c.font(11, True)) + 22 * S
                self.button(fix[0], x + w - bw - 10 * S, ry + 7 * S, bw, 26 * S, fix[1], a, font=c.font(11, True))
            if i < len(rows) - 1:
                c.line(x + 30 * S, ry + 40 * S, x + w - 10 * S, ry + 40 * S, with_alpha(WHITE, a * 0.06), 1 * S)
        y += len(rows) * 40 * S + 14 * S
        # прятать островок поверх выбранных программ
        y = self.section_title("Прятать островок поверх программ", x, y, w, a)
        apps = list(self.ui.get("hide_apps") or [])
        opts = [(f"{n}  ✕", n) for n in apps]
        cand = self.last_fg if self.last_fg and self.last_fg not in apps else None
        if cand:
            opts.append((f"+ {cand}", cand))
        if opts:
            y = self.chips(x, y, w, opts, lambda v: v in apps, self.toggle_hide_app, a)
        c.text("Открой нужную программу, потом вернись сюда и нажми «+»", x, y - 6 * S, w, 16 * S, c.font(10), with_alpha(DIM, a), align=1)
        return y + 16 * S

    # ---------- настройки ----------
    def page_settings(self, x, y, w, a):
        c, S, ui = self.cv, self.S, self.ui
        sects = [("look", "Вид"), ("island", "Островок"), ("features", "Функции"), ("check", "Проверка"), ("more", "Ещё")]
        cur = getattr(self, "settings_sect", "look")
        # переключатель разделов - «таблетка» с ползунком
        n = len(sects)
        c.rrect(x, y, w, 32 * S, 16 * S, with_alpha(argb(255, 22, 22, 30), a))
        cell = w / n
        idx = [k for k, _ in sects].index(cur)
        tx = x + cell * idx
        self.sect_x = tx if getattr(self, "sect_x", None) is None or not ui["anim"] else self.sect_x + (tx - self.sect_x) * 0.3
        c.rrect(self.sect_x + 3 * S, y + 3 * S, cell - 6 * S, 26 * S, 13 * S, with_alpha(self.ACC, a))
        for i, (k, title) in enumerate(sects):
            on = k == cur
            c.text(title, x + cell * i, y, cell, 32 * S, c.font(11.5, True), with_alpha(DARK_TEXT if on else WHITE, a), align=1)
            self.hit(x + cell * i, y, x + cell * (i + 1), y + 32 * S, lambda k=k: setattr(self, "settings_sect", k))
        y += 44 * S

        if cur == "look":
            y = self.section_title("Тема", x, y, w, a)
            y = self.swatches(x, y, w, [(k, v[0], rgb(v[3]), rgb(v[4])) for k, v in THEMES.items()], ui["theme"],
                              lambda v: self.set_ui("theme", v), a)
            y = self.section_title("Фон островка", x, y, w, a)
            y = self.chips(x, y, w, [("Обычный", "none"), ("Обложка песни", "cover"), ("Градиент", "gradient"),
                                     ("Аврора", "aurora"), ("Матрица", "matrix"), ("Космос", "space")],
                           lambda v: ui.get("wall", "cover") == v, lambda v: self.set_ui("wall", v), a)
            y = self.section_title("Рамка", x, y, w, a)
            y = self.chips(x, y, w, [("Без рамки", "none"), ("Свечение", "glow"), ("RGB-переливы", "rgb"), ("Цвет обложки", "cover")],
                           lambda v: ui.get("border", "rgb") == v, lambda v: self.set_ui("border", v), a)
            y = self.section_title("Скругление", x, y, w, a)
            y = self.chips(x, y, w, [("Круглый", "round"), ("Средний", "mid"), ("Почти квадратный", "square")],
                           lambda v: ui.get("round", "round") == v, lambda v: self.set_ui("round", v), a)
            y = self.section_title("Эффекты внутри", x, y, w, a)
            y = self.chips(x, y, w, [("Нет", "none"), ("Искры", "sparks"), ("Снег", "snow"), ("Звёзды", "stars"), ("Погода", "weather"), ("Сезон", "season")],
                           lambda v: ui.get("fx", "sparks") == v, lambda v: self.set_ui("fx", v), a)
            y = self.section_title("Цвет текста песни", x, y, w, a)
            y = self.swatches(x, y, w, [(k, v[0], self.ACC if k == "accent" else (None if k == "rainbow" else rgb(v[1])), None)
                                        for k, v in LYRIC_COLORS.items()], ui["lyric"], lambda v: self.set_ui("lyric", v), a)
            return y

        if cur == "island":
            half = (w - 12 * S) / 2
            self.section_title("Размер", x, y, half, a)
            self.section_title("Прозрачность", x + half + 12 * S, y, half, a)
            y += 19 * S
            self.seg(x, y, half, [("S", "S"), ("M", "M"), ("L", "L")], ui["size"], lambda v: self.set_ui("size", v), a, h=28)
            self.seg(x + half + 12 * S, y, half, [("100", 100), ("90", 90), ("80", 80), ("70", 70)], ui["opacity"],
                     lambda v: self.set_ui("opacity", v), a, h=28)
            y += 40 * S
            y = self.section_title("Где на экране", x, y, w, a)
            y = self.seg(x, y, w, [("Слева", "left"), ("По центру", "center"), ("Справа", "right")],
                         None if ui.get("custom_pos") else ui["pos"], lambda v: self.set_ui("pos", v), a, h=28) + 4 * S
            c.text("Или потащи островок правой кнопкой мыши куда угодно" if not ui.get("custom_pos")
                   else "Островок стоит там, куда ты его перетащил — нажми место выше, чтобы вернуть",
                   x, y, w, 16 * S, c.font(10), with_alpha(DIM, a), align=1)
            y += 24 * S
            y = self.section_title("Питомец", x, y, w, a)
            y = self.chips(x, y, w, [("Рыжий котик", "ginger"), ("Чёрный котик", "black"), ("Белый котик", "white"), ("Жучок", "beetle")],
                           lambda v: ui.get("pet_kind", "ginger") == v, lambda v: self.set_ui("pet_kind", v), a)
            y = self.section_title("Плавность", x, y, w, a)
            y = self.chips(x, y, w, [("Плавно (60 кадров)", "smooth"), ("Обычно", "normal"), ("Для слабого ПК", "eco")],
                           lambda v: ui.get("fps_mode", "normal") == v, lambda v: self.set_ui("fps_mode", v), a)
            y = self.section_title("Вид в покое", x, y, w, a)
            y = self.chips(x, y, w, [("Обычный", False), ("Мини: только часы", True)],
                           lambda v: bool(ui.get("mini")) == v, lambda v: self.set_ui("mini", v), a)
            y = self.section_title("Что видно в свёрнутом островке", x, y, w, a)
            y = self.chips(x, y, w, [("Погода", "weather"), ("Дата", "date"), ("Язык", "lang"), ("Батарея", "battery"),
                                     ("Секунды", "seconds")], lambda v: ui["show"][v], self.toggle_show, a)
            y = self.setting_rows(x, y, w, [
                ("summary", "Анимации", "Пружинки, волны и плавные переходы", "anim"),
                ("heart", "Котик в островке", "Нажми на него - он мурчит", "pet"),
                ("system", "Прятать в полном экране", "F11, игры и фильмы", "hide_fullscreen"),
                ("mic", "Точки микрофона и камеры", "Оранжевая и зелёная, как на iPhone", "privacy_dots")], a)
            return y

        if cur == "features":
            y = self.setting_rows(x, y, w, [
                ("music", "Караоке-подсветка песни", "Строчка закрашивается в такт", "karaoke"),
                ("game", "Игровой режим", "Пинг и время в игре", "gamemode"),
                ("caps", "Сообщать про Caps Lock", "", "caps_toast"),
                ("clip", "Второй островок при копировании", "Рядом появляется «копия» с кнопками", "copy_island"),
                ("clip", "Помнить буфер после перезапуска", "Иначе история забывается при выключении", "clip_save"),
                ("wifi", "Сообщать о смене Wi‑Fi и VPN", "", "net_toast")], a)
            y = self.setting_rows(x, y, w, [
                ("chat", "Уведомления", "Сообщения из Telegram, Discord…", "notifs"),
                ("phone", "Звонки", "Карточка с «Принять» и «Отклонить»", "calls"),
                ("moon", "Не беспокоить", "Ничего не всплывает", "dnd")], a)
            city = self.settings.get("city_name") or self.settings.get("city") or "не выбран"
            y = self.setting_rows(x, y, w, [
                ("weather", "Город для погоды", city, None, "Сменить",
                 lambda: (self.open_tab("weather"), self.focus_input("city")))], a)
            return y

        if cur == "check":
            return self.page_check(x, y, w, a)
        # «Ещё»: горячие клавиши и о программе
        y = self.section_title("Горячие клавиши", x, y, w, a)
        keys = [(getattr(self, "cmd_keys", None) or "Ctrl+Alt+Пробел", "Командная строка", bool(getattr(self, "cmd_keys", None))),
                ("Ctrl+Alt+I", "Спрятать / показать", "Ctrl+Alt+I" in getattr(self, "hotkeys_ok", [])),
                ("Ctrl+Alt+S", "Скриншот", "Ctrl+Alt+S" in getattr(self, "hotkeys_ok", []))]
        self.card(x, y, w, len(keys) * 36 * S, 14 * S, a)
        for i, (k, what, ok) in enumerate(keys):
            yy = y + i * 36 * S
            c.text(what, x + 14 * S, yy, w / 2, 36 * S, c.font(12.5, True), with_alpha(WHITE if ok else DIM, a))
            parts = k.split("+")
            kx = x + w - 12 * S
            for p in reversed(parts):
                pw = c.measure(p, c.font(10.5, True)) + 14 * S
                kx -= pw
                c.rrect(kx, yy + 8 * S, pw, 20 * S, 6 * S, with_alpha(argb(255, 58, 58, 74), a))
                c.text(p, kx, yy + 8 * S, pw, 20 * S, c.font(10.5, True), with_alpha(WHITE if ok else DIM, a), align=1)
                kx -= 4 * S
            if i < len(keys) - 1:
                c.line(x + 14 * S, yy + 36 * S, x + w - 12 * S, yy + 36 * S, with_alpha(WHITE, a * 0.06), 1 * S)
        y += len(keys) * 36 * S + 14 * S
        y = self.section_title("Обновления", x, y, w, a)
        info = self.upd_info
        if info and not self.upd_busy:
            btn = (f"Обновить до {info['version']}", self.install_update)
        else:
            btn = ("Проверить", lambda: self.check_update(manual=True))
        sub = self.upd_state or ("Проверяется само раз в 6 часов" if self.update_url() else "Адрес обновлений не задан")
        y = self.setting_rows(x, y, w, [
            ("download", f"Версия {upd.VERSION}", sub, None, btn[0], btn[1]),
            ("star", "Обновлять самому", "Скачивает и ставит новую версию без вопросов", "auto_update")], a)
        if info and info.get("notes"):
            c.text("Что нового: " + " · ".join(info["notes"][:4]), x, y - 6 * S, w, 16 * S, c.font(10), with_alpha(MUTED, a), align=1)
            y += 14 * S
        if self.typing == "updurl":
            y = self.draw_input(x, y, w, "updurl", "Ссылка на version.json (Enter)", a) + 10 * S
        elif not DEFAULT_UPDATE_URL:
            self.button("Указать адрес обновлений", x + w / 2 - 90 * S, y - 4 * S, 180 * S, 24 * S,
                        lambda: self.focus_input("updurl"), a, font=c.font(10.5, True))
            y += 28 * S
        y = self.section_title("О программе", x, y, w, a)
        now = time.time()
        y = self.setting_rows(x, y, w, [
            ("notes", "Папка островка", "Настройки, заметки, журнал", None, "Открыть",
             lambda: extra.run_hidden(["explorer.exe", APP_DIR])),
            ("settings", "Сбросить настройки", "Вернуть всё как было",
             None, "Точно?" if self.confirm.get("reset", 0) > now else "Сбросить", self.reset_settings)], a)
        c.text("Островок · идеи командной строки и пункта управления — из Atoll (MIT)", x, y - 2 * S, w, 16 * S,
               c.font(10), with_alpha(DIM, a), align=1)
        return y + 18 * S

    # ---------- кадр ----------
    def mouse_over(self):
        x, y = cursor_pos()
        x0, y0, x1, y1 = self.island
        m = 6 * self.S
        return self.wx + x0 - m <= x <= self.wx + x1 + m and self.wy + y0 - m <= y <= self.wy + y1 + m

    def spring(self, cur, vel, target):
        if not self.ui["anim"]:
            return target, 0.0
        vel = (vel + (target - cur) * 0.2) * 0.62
        cur += vel
        if abs(target - cur) < 0.4 and abs(vel) < 0.4:
            return target, 0.0
        return cur, vel

    def frame(self):
        now = time.time()
        dtime = min(0.1, now - self.last_frame)
        self.last_frame = now
        self.last_dt = dtime
        c, S = self.cv, self.S
        self.hits = []
        items = self.header_items()
        pet_w = 24 * S if self.ui.get("pet", True) else 0
        header_w = sum(i[4] for i in items) + 13 * S * (len(items) - 1) + 36 * S + pet_w
        row_h = 38 * S

        st = self.music()
        playing = bool(st) and st.get("status") == "Playing"
        if self.toast and now > self.toast[2]:
            self.toast = None
        if not self.expanded and self.mouse_over():
            self.hover_last_in = now
        hovering = not self.expanded and now - self.hover_last_in < 0.35
        self.hover_k = clamp(self.hover_k + (dtime * 5 if hovering else -dtime * 6), 0, 1)
        if not self.ui["anim"]:
            self.hover_k = 1.0 if hovering else 0.0

        self.process_notif_events(now)
        mode, line, frac = None, None, None
        if not self.expanded and self.tab == "command":
            self.tab = getattr(self, "cmd_prev_tab", "music") or "music"
            if self.typing == "cmd":
                self.typing = None
        live = self.ui.get("notif_place", "island") == "island"
        if live and self.incoming and self.incoming["start"] != self.incoming_seen:
            self.incoming_seen = self.incoming["start"]     # звонок важнее - сворачиваем раскрытый островок
            self.expanded = False
            self.typing = None
        if not self.expanded:
            if self.drop and now - self.drop["start"] > 25:
                self.drop = None
            if self.clip_pill and now > self.clip_pill.get("until", self.clip_pill["start"] + 9):
                self.clip_pill = None
            if live and self.incoming:
                mode = "incoming"
            elif self.drop:
                mode = "drop"
            elif self.qr_show:
                mode = "qr"
            elif self.clip_pill and not self.ui.get("copy_island", True):
                mode = "clippill"
            elif self.toast:
                mode, line = "toast", self.toast[0]
            elif live and self.island_notifs():
                mode = "notif"
            elif now < self.vol_show and self.vol_seen:
                mode, line = "volume", "громкость"
            elif hovering:
                mode = "hover"
            elif self.calls and self.ui.get("calls", True):
                mode = "call"
            elif self.dlw.current:
                mode = "dl"
            elif self.jobs.current:
                mode = "job"
            elif playing:
                mode = "lyrics"
                line, _, frac = self.current_lyrics()
                if line is None:
                    line = f"{st.get('artist', '')} — {st.get('title', '')}".strip(" —")

        quick = ["command"] + self.pinned() + ["more", "screenshot"]
        if self.expanded:
            tw, th = max(380 * S, header_w), self.expanded_h
        elif mode == "hover":
            tw, th = max(header_w, len(quick) * 34 * S + 24 * S), row_h + 36 * S
        elif mode == "volume":
            tw, th = max(header_w, 300 * S), row_h + 30 * S
        elif mode == "call":
            tw, th = max(header_w, 330 * S), row_h + 36 * S
        elif mode in ("dl", "job"):
            tw, th = max(header_w, 330 * S), row_h + 34 * S
        elif mode == "drop":
            tw, th = max(header_w, 400 * S), 112 * S
        elif mode == "clippill":
            tw, th = max(header_w, 420 * S), 96 * S
        elif mode == "qr":
            tw, th = max(header_w, 280 * S), 280 * S
        elif mode == "incoming":
            tw, th = max(header_w, 400 * S), 104 * S
        elif mode == "notif":
            n = self.island_notifs()[0]
            hide = self.ui.get("notif_hide")
            tlen = max(c.measure("Новое сообщение" if hide else (n["title"] or n["app"]), c.font(13.5, True)),
                       c.measure("" if hide else n["body"][:80], c.font(11.5)))
            tw, th = clamp(tlen + 92 * S, max(header_w, 290 * S), 470 * S), 54 * S
        elif mode == "toast" and self.toast[1] == "track":
            tw = clamp(c.measure(line, c.font(14, True)) + 110 * S, max(header_w, 300 * S), self.W - 30 * S)
            th = row_h + 52 * S
        elif mode in ("toast", "lyrics"):
            tw = clamp(c.measure(line, c.font(14, True)) + 84 * S, max(header_w, 280 * S), self.W - 30 * S)
            th = row_h + 30 * S
        else:
            tw, th = header_w, row_h
        self.cur_w, self.vel_w = self.spring(self.cur_w, self.vel_w, tw)
        self.cur_h, self.vel_h = self.spring(self.cur_h, self.vel_h, th)
        self.lyric_anim = min(1.0, self.lyric_anim + dtime * 4)
        self.tab_anim = min(1.0, self.tab_anim + dtime * 5)

        w, h = max(40 * S, self.cur_w), max(row_h, self.cur_h)
        pos = self.ui["pos"]
        x0 = 10 * S if pos == "left" else (self.W - w - 10 * S if pos == "right" else (self.W - w) / 2)
        y0 = 2 * S
        if self.toast and self.toast[1] == "alarm" and self.ui["anim"]:
            k = now - self.toast[3]
            x0 += math.sin(k * 45) * 6 * S * max(0.0, 1 - k / 1.2)
        roundness = {"round": 1.0, "mid": 0.62, "square": 0.36}.get(self.ui.get("round", "round"), 1.0)
        radius = (19 * S if h < 90 * S else 24 * S) * roundness
        c.clear()
        # тень и свечение в такт музыке
        border = self.ui.get("border", "rgb")
        glow = playing and self.ui["anim"] and border != "none"
        self.update_audio(dtime)
        pulse = min(1.0, self.level * 1.4) if self.audio else 0.5 + 0.5 * math.sin(now * 3.2)
        rgb1, rgb2 = hsv((now * 0.12) % 1, 0.75, 1.0), hsv((now * 0.12 + 0.38) % 1, 0.75, 1.0)
        if border == "cover":
            # как в Dyland: островок окрашивается в цвета обложки песни
            rgb1, rgb2 = (self.cover.c1, self.cover.c2) if self.cover and st else (self.ACC, self.ACC2)
        flow = border in ("rgb", "cover")
        for k in range(6):
            g = (6 - k) * 2.0 * S
            if glow:
                base = (rgb1 if k % 2 else rgb2) if flow else self.ACC
                col = with_alpha(base, 0.035 + 0.05 * pulse)
            else:
                col = argb(13, 0, 0, 0)
            c.rrect(x0 - g / 2, y0 + 1 * S - (g / 3 if glow else 0), w + g, h + g / 2 + (g / 3 if glow else 0), radius + g / 2, col)
        c.rrect(x0, y0, w, h, radius, self.BG)
        self.island_clip = (x0, y0, w, h, radius)
        c.clip_rrect(*self.island_clip)
        # обои: размытая обложка или живой градиент
        self.update_cover(st)
        wall = self.ui.get("wall", "cover")
        if wall == "cover" and self.cover and st:
            c.image(self.cover.small, x0 - 30 * S, y0 - 30 * S, w + 60 * S, h + 60 * S)
            c.rrect(x0, y0, w, h, radius, with_alpha(self.BG_SOLID, 0.6))
        elif wall == "gradient":
            c1, c2 = (self.cover.c1, self.cover.c2) if self.cover else (self.ACC, self.ACC2)
            c.gradient_rrect(x0, y0, w, h, radius, c1, c2, math.sin(now * 0.5) * w * 0.4)
            c.rrect(x0, y0, w, h, radius, with_alpha(self.BG_SOLID, 0.55))
        elif wall in ("aurora", "matrix", "space") and self.ui["anim"] and self.ui.get("fps_mode") != "eco":
            self.draw_live_wall(wall, x0, y0, w, h, now, dtime)
        self.draw_particles(x0, y0, w, h, playing, dtime, now)
        # стеклянный блик сверху
        c.gradient_rect(x0, y0, w, min(h, 26 * S), argb(30, 255, 255, 255), argb(0, 255, 255, 255))
        grow = clamp((h - row_h) / max(1.0, th - row_h), 0, 1) if th > row_h else 0
        if mode in ("incoming", "notif", "drop", "clippill", "qr"):
            # «живая активность»: островок целиком превращается в уведомление/звонок
            k = clamp(1 - abs(w - tw) / max(1.0, tw * 0.5), 0, 1) * clamp(1 - abs(h - th) / max(1.0, th), 0, 1)
            if mode == "incoming":
                self.draw_live_call(x0, y0, w, h, k, now, self.incoming)
            elif mode == "drop":
                self.draw_drop(x0, y0, w, h, k)
            elif mode == "clippill":
                self.draw_clip_pill(x0, y0, w, h, k)
            elif mode == "qr":
                self.draw_qr(x0, y0, w, h, k)
            else:
                self.draw_live_notif(x0, y0, w, h, k, now, self.island_notifs()[0])
        else:
            if pet_w:
                self.pet_xy = (x0 + 22 * S, y0 + row_h / 2 + 1 * S)
                self.draw_pet(*self.pet_xy, playing)
                self.hit(x0 + 8 * S, y0, x0 + 36 * S, y0 + row_h, self.pet_cat, "any")
            self.draw_header(x0 + pet_w, y0, w - pet_w, row_h, items)

        if mode == "toast" and self.toast[1] == "track":
            # карточка новой песни: обложка + название
            a = grow
            cy = y0 + row_h + 22 * S
            if self.cover:
                c.clip_rrect_intersect(x0 + 14 * S, cy - 20 * S, 40 * S, 40 * S, 9 * S)
                c.image(self.cover.thumb, x0 + 14 * S, cy - 20 * S, 40 * S, 40 * S)
                c.clip_rrect(*self.island_clip)
            else:
                self.draw_icon("music", x0 + 34 * S, cy, 12 * S, with_alpha(self.ACC, a))
            c.text("Сейчас играет", x0 + 64 * S, cy - 21 * S, w - 80 * S, 18 * S, c.font(10.5, True), with_alpha(self.ACC, a))
            parts = line.split(" — ", 1)
            c.text(parts[-1], x0 + 64 * S, cy - 6 * S, w - 80 * S, 20 * S, c.font(14, True), with_alpha(WHITE, a))
            if len(parts) > 1:
                c.text(parts[0], x0 + 64 * S, cy + 11 * S, w - 80 * S, 18 * S, c.font(11.5), with_alpha(MUTED, a))
        elif mode == "call":
            self.draw_call(x0, y0 + row_h, w, grow, now)
        elif mode == "job":
            a = grow
            app, pct = self.jobs.current
            cy = y0 + row_h + 15 * S
            c.ring(x0 + 26 * S, cy, 11 * S, with_alpha(argb(255, 60, 60, 78), a), 3 * S)
            c.arc(x0 + 26 * S, cy, 11 * S, -90, 3.6 * pct, with_alpha(GREEN, a), 3 * S)
            c.text(f"{app} · идёт задача", x0 + 46 * S, cy - 10 * S, w - 110 * S, 20 * S, c.font(12.5, True), with_alpha(WHITE, a))
            c.text(f"{pct}%", x0 + w - 66 * S, cy - 10 * S, 50 * S, 20 * S, c.font(12.5, True), with_alpha(GREEN, a), align=2)
        elif mode == "dl":
            a = grow
            name, size, speed, count = self.dlw.current
            cy = y0 + row_h + 15 * S
            c.circle(x0 + 26 * S, cy, 11 * S, with_alpha(BLUE, a))
            self.draw_icon("download", x0 + 26 * S, cy, 6.5 * S, with_alpha(DARK_TEXT, a))
            spin = (now * 300) % 360 if self.ui["anim"] else 0
            c.arc(x0 + 26 * S, cy, 14 * S, spin, 90, with_alpha(BLUE, a * 0.8), 2 * S)
            info = f"{extra.fmt_bytes(size)} · {extra.fmt_bytes(speed)}/с" + (f" · файлов: {count}" if count > 1 else "")
            iw = c.measure(info, c.font(11))
            c.text(name, x0 + 46 * S, cy - 10 * S, w - 70 * S - iw, 20 * S, c.font(12.5, True), with_alpha(WHITE, a))
            c.text(info, x0 + w - 16 * S - iw, cy - 10 * S, iw + 2 * S, 20 * S, c.font(11), with_alpha(MUTED, a), align=2)
            self.hit(x0, y0 + row_h, x0 + w, y0 + row_h + 34 * S,
                     lambda: extra.run_hidden(["explorer.exe", self.dlw.folder]), "any")
        elif mode == "volume":
            a = grow
            vol, mute = self.vol_seen
            cy = y0 + row_h + 11 * S
            self.draw_icon("mute" if mute or vol == 0 else "vol_up", x0 + 26 * S, cy, 8 * S, with_alpha(WHITE, a))
            bx, bw = x0 + 46 * S, w - 104 * S
            c.rrect(bx, cy - 3 * S, bw, 6 * S, 3 * S, with_alpha(argb(255, 55, 55, 72), a))
            fill = 0 if mute else vol
            if fill > 0:
                c.gradient_rect(bx, cy - 3 * S, max(6 * S, bw * fill), 6 * S, self.ACC, self.ACC2, vertical=False)
            c.text("без звука" if mute else f"{round(vol * 100)}%", x0 + w - 56 * S, cy - 11 * S, 44 * S, 22 * S,
                   c.font(12, True), with_alpha(WHITE, a), align=2)
        elif mode == "toast":
            a = grow
            k = now - self.toast[3]
            pop = 1 + 0.25 * math.sin(min(1.0, k * 3) * math.pi) if self.ui["anim"] else 1
            # значок в цветном кружке и тонкая полоска «сколько осталось» - как у уведомлений
            warm = self.toast[1] in ("timer", "alarm", "caps")
            tint = YELLOW if warm else self.ACC
            cy_ = y0 + row_h + 9 * S
            c.circle(x0 + 24 * S, cy_, 11 * S * pop, with_alpha(tint, a * 0.22))
            self.draw_icon(self.toast[1], x0 + 24 * S, cy_, 6.8 * S * pop, with_alpha(tint, a))
            c.text(line, x0 + 42 * S, y0 + row_h - 4 * S, w - 64 * S, 26 * S, c.font(13.5, True), with_alpha(WHITE, a), align=1)
            total = max(0.1, self.toast[2] - self.toast[3])
            left = clamp((self.toast[2] - now) / total, 0, 1)
            c.rrect(x0 + w * 0.3, y0 + row_h + 25 * S, w * 0.4 * left, 2 * S, 1 * S, with_alpha(tint, a * 0.5))
        elif mode == "lyrics":
            a = grow
            self.draw_equalizer(x0 + 16 * S, y0 + row_h + 9 * S, True, a)
            self.draw_lyric(line, frac, x0 + 38 * S, y0 + row_h - 4 * S, w - 62 * S, 26 * S, c.font(14, True), a)
        elif mode == "hover" or (self.hover_k > 0 and not self.expanded):
            n = len(quick)
            cell = (w - 20 * S) / n
            for i, name in enumerate(quick):
                k = clamp(self.hover_k * 1.8 - i * 0.1, 0, 1)
                cx = x0 + 10 * S + cell * i + cell / 2
                cy = y0 + row_h + 14 * S + (1 - k) * 8 * S
                over = self.mouse_over_rect(cx - 14 * S, cy - 14 * S, cx + 14 * S, cy + 14 * S)
                if over:
                    c.circle(cx, cy, 14 * S, with_alpha(self.CARD, k))
                self.draw_icon(name, cx, cy, 9 * S * (0.7 + 0.3 * k), with_alpha(self.ACC if over else WHITE, k))
                self.hit(cx - cell / 2, cy - 16 * S, cx + cell / 2, cy + 16 * S, lambda n=name: self.open_tab(n), "hover")

        if self.expanded or (h > row_h + 70 * S and mode not in ("incoming", "notif", "drop", "clippill", "qr")):
            ea = clamp((h - row_h - 40 * S) / (160 * S), 0, 1) if self.expanded else clamp((h - row_h - 70 * S) / (200 * S), 0, 1) * 0.6
            end = self.draw_expanded(x0, y0 + row_h, w, ea)
            if self.expanded:
                self.expanded_h = min(self.H - 10 * S, end - y0 + 12 * S)
        self.draw_hearts(now)
        # волны от кликов
        self.ripples = [r for r in self.ripples if now - r[2] < 0.45]
        for rx, ry, t0 in self.ripples:
            k = (now - t0) / 0.45
            c.circle(rx, ry, (8 + 44 * k) * S, argb(int(55 * (1 - k)), 255, 255, 255))
        c.reset_clip()
        # рамка: переливающаяся RGB или тонкая светлая кромка
        if flow:
            c.gradient_outline(x0 + 0.5 * S, y0 + 0.5 * S, w - S, h - S, radius, rgb1, rgb2,
                               (2.2 if playing else 1.5) * S, (now * 70 * S) % (w * 1.2 + 1))
        else:
            c.rrect_outline(x0 + 0.5 * S, y0 + 0.5 * S, w - S, h - S, radius, argb(34, 255, 255, 255), 1 * S)
        self.island = (x0, y0, x0 + w, y0 + h)
        self.blit()
        fx = self.ui.get("fx", "sparks") if self.ui["anim"] and self.ui.get("fps_mode") != "eco" else "none"
        return (self.cur_w != tw or self.cur_h != th or playing or self.expanded or bool(self.toast)
                or self.hover_k > 0 or now - self.lang_flash < 1 or self.sw_running or flow
                or fx in ("snow", "stars", "weather", "season") or bool(self.particles) or bool(self.ripples) or bool(self.pomo)
                or self.ui.get("wall") in ("aurora", "matrix", "space") or now < self.vol_show
                or bool(self.hearts) or bool(self.runner) or bool(self.calls) or bool(self.incoming) or bool(self.side_notifs) or bool(self.dlw.current)
                or bool(self.drop) or bool(self.jobs.current) or bool(self.clip_pill) or bool(self.qr_show))

    def draw_live_wall(self, kind, x0, y0, w, h, now, dtime):
        """Живые обои внутри островка."""
        c, S, lv = self.cv, self.S, self.level
        if kind == "aurora":
            # северное сияние: «шторки» света колышутся, ярче под музыку
            step = 6 * S
            for band, (hue, ph) in enumerate(((0.38, 0.0), (0.52, 2.1), (0.78, 4.0))):
                n = int(w / step) + 1
                for i in range(n):
                    xx = x0 + i * step
                    wave = math.sin(i * 0.11 + now * (0.6 + band * 0.25) + ph) + 0.5 * math.sin(i * 0.05 - now * 0.4 + ph)
                    top = y0 + h * (0.05 + 0.12 * band) + wave * 9 * S
                    hh = h * (0.35 + 0.15 * math.sin(i * 0.07 + now + band)) + lv * 20 * S
                    col = hsv((hue + 0.04 * math.sin(now * 0.3 + i * 0.02)) % 1, 0.7, 1.0)
                    al = int(40 + 45 * lv + 25 * (0.5 + 0.5 * math.sin(i * 0.2 + now * 1.5 + band)))
                    c.gradient_rect(xx, top, step + 1, hh, with_alpha(col, al / 255), with_alpha(col, 0))
            return
        if kind == "matrix":
            # падающие символы как в фильме «Матрица»
            if not hasattr(self, "mx_cols") or abs(self.mx_cols[0] - w) > 2 * S:
                cols = max(4, int(w / (13 * S)))
                self.mx_cols = (w, [[random.uniform(-h, h), random.uniform(40, 90), random.random()] for _ in range(cols)])
            cw = w / len(self.mx_cols[1])
            f = c.font(11, True, "Consolas")
            chars = "01アイウエオカキクケコサシスセソタチツテト"
            speed = 1 + lv * 2.5
            for i, col in enumerate(self.mx_cols[1]):
                col[0] += col[1] * S * dtime * speed
                if col[0] - 8 * 14 * S > h:
                    col[0] = random.uniform(-30 * S, 0)
                    col[1] = random.uniform(40, 90)
                for k in range(8):
                    yy = col[0] - k * 14 * S
                    if yy < -14 * S or yy > h:
                        continue
                    ch = chars[int(col[2] * 97 + k * 7 + int(now * 6) * (k == 0)) % len(chars)]
                    al = 1.0 if k == 0 else max(0.1, 0.75 - k * 0.09)
                    tint = argb(255, 200, 255, 210) if k == 0 else argb(255, 40, 230, 110)
                    c.text(ch, x0 + i * cw, y0 + yy - 14 * S, cw, 14 * S, f, with_alpha(tint, al * 0.8), align=1)
            c.rrect(x0, y0, w, h, 0, with_alpha(self.BG_SOLID, 0.45))
            return
        # космос: звёзды летят навстречу, под музыку - быстрее
        if not hasattr(self, "stars3d"):
            self.stars3d = [[random.uniform(-1, 1), random.uniform(-1, 1), random.uniform(0.1, 1)] for _ in range(70)]
        cx, cy = x0 + w / 2, y0 + h / 2
        speed = (0.25 + lv * 1.8) * dtime
        for s in self.stars3d:
            pz = s[2]
            s[2] -= speed
            if s[2] <= 0.04:
                s[0], s[1], s[2] = random.uniform(-1, 1), random.uniform(-1, 1), 1.0
                continue
            sx, sy = cx + s[0] / s[2] * w * 0.25, cy + s[1] / s[2] * h * 0.6
            px, py = cx + s[0] / pz * w * 0.25, cy + s[1] / pz * h * 0.6
            if not (x0 <= sx <= x0 + w and y0 <= sy <= y0 + h):
                continue
            br = clamp(1.2 - s[2], 0.15, 1.0)
            col = argb(int(255 * br), 220, 230, 255)
            c.line(px, py, sx, sy, col, max(0.8, (1.2 - s[2]) * 2.2) * S)

    def draw_weather_fx(self, x0, y0, w, h, dtime, now):
        """Эффект «Погода»: в островке идёт то же, что за окном."""
        c, S = self.cv, self.S
        kind = self.weather[1] if self.weather else ""
        if kind in ("rain", "storm"):
            if len(self.rain) < 40 and random.random() < 30 * dtime:
                self.rain.append([random.uniform(0, w + 20 * S), -6 * S, random.uniform(220, 320) * S])
            keep = []
            for r in self.rain:
                r[1] += r[2] * dtime
                r[0] -= r[2] * dtime * 0.25
                if r[1] < h + 8 * S:
                    keep.append(r)
                    c.line(x0 + r[0], y0 + r[1], x0 + r[0] + 2.5 * S, y0 + r[1] - 9 * S, argb(110, 140, 190, 255), 1.2 * S)
            self.rain = keep
            if kind == "storm" and random.random() < dtime * 0.4:
                self.flash = now
            if now - getattr(self, "flash", 0) < 0.12:
                c.rect(x0, y0, w, h, argb(70, 230, 230, 255))
        elif kind == "snow":
            if len(self.rain) < 30 and random.random() < 9 * dtime:
                self.rain.append([random.uniform(0, w), -3 * S, random.uniform(14, 28) * S, random.random() * 6])
            keep = []
            for r in self.rain:
                r[1] += r[2] * dtime
                if r[1] < h + 4 * S:
                    keep.append(r)
                    c.circle(x0 + r[0] + math.sin(now + r[3]) * 4 * S, y0 + r[1], 1.6 * S, argb(190, 255, 255, 255))
            self.rain = keep
        elif kind in ("sun", "partly"):
            # солнечный луч медленно проходит по островку
            k = (now * 0.12) % 1.6 - 0.3
            c.gradient_rect(x0 + w * k - 40 * S, y0, 80 * S, h, argb(26, 255, 220, 120), argb(0, 255, 220, 120), vertical=False)
        else:
            self.rain = []

    def draw_season(self, x0, y0, w, h, dtime, now):
        """Время года прямо в островке (как темы-сезоны в Atoll)."""
        c, S = self.cv, self.S
        month = dt.date.today().month
        season = "winter" if month in (12, 1, 2) else "spring" if month <= 5 else "summer" if month <= 8 else "autumn"
        sp = self.__dict__.setdefault("season_p", [])
        if season == "summer":
            # тёплое солнце в углу и светлячки
            c.gradient_rect(x0, y0, w * 0.5, h, argb(34, 255, 200, 90), argb(0, 255, 200, 90), vertical=False)
            if len(sp) < 12 and random.random() < 3 * dtime:
                sp.append([random.uniform(0, w), h + 3 * S, random.uniform(-14, -6) * S, random.random() * 6, 6.0])
        else:
            rate = {"winter": 8, "spring": 4, "autumn": 3.5}[season]
            if len(sp) < 34 and random.random() < rate * dtime:
                speed = {"winter": (14, 28), "spring": (16, 26), "autumn": (18, 32)}[season]
                sp.append([random.uniform(0, w), -5 * S, random.uniform(*speed) * S, random.random() * 6, 99.0])
        keep = []
        for p in sp:
            p[1] += p[2] * dtime
            p[4] -= dtime
            if p[4] <= 0 or p[1] > h + 8 * S or p[1] < -10 * S:
                continue
            keep.append(p)
            px = x0 + p[0] + math.sin(now * 1.3 + p[3]) * 6 * S
            py = y0 + p[1]
            if season == "winter":
                c.circle(px, py, (1.2 + (p[3] % 1.2)) * S, argb(200, 255, 255, 255))
            elif season == "summer":
                glow = 0.5 + 0.5 * math.sin(now * 4 + p[3] * 3)
                c.circle(px, py, 3.5 * S, argb(int(50 * glow), 255, 230, 120))
                c.circle(px, py, 1.4 * S, argb(int(220 * glow), 255, 240, 150))
            else:
                ang = now * 2.2 + p[3]
                if season == "spring":
                    col = argb(210, 255, 170, 205) if p[3] < 3 else argb(210, 255, 220, 235)
                    rx, ry = 3.2 * S, 1.8 * S
                else:
                    col = (argb(220, 240, 120, 40), argb(220, 220, 70, 50), argb(220, 250, 190, 60))[int(p[3]) % 3]
                    rx, ry = 4.2 * S, 2.2 * S
                ca, sa = math.cos(ang), math.sin(ang)
                pts = [(px + ca * rx * math.cos(t) - sa * ry * math.sin(t), py + sa * rx * math.cos(t) + ca * ry * math.sin(t))
                       for t in [k * math.pi / 4 for k in range(8)]]
                c.polygon(pts, col)
        self.season_p = keep
        if season == "winter":
            # гирлянда по верхнему краю
            n = max(6, int(w / (22 * S)))
            for i in range(n):
                gx = x0 + (i + 0.5) * w / n
                gy = y0 + 3 * S + math.sin(i * 1.7) * 1.5 * S
                col = (argb(255, 255, 80, 80), argb(255, 255, 210, 60), argb(255, 80, 220, 120), argb(255, 90, 170, 255))[i % 4]
                on = 0.35 + 0.65 * (0.5 + 0.5 * math.sin(now * 3 + i * 1.3))
                c.circle(gx, gy, 3.6 * S, with_alpha(col, 0.25 * on))
                c.circle(gx, gy, 1.7 * S, with_alpha(col, on))

    def draw_particles(self, x0, y0, w, h, playing, dtime, now):
        """Эффекты внутри островка: искры под музыку, снег или мерцающие звёзды."""
        c, S, P = self.cv, self.S, self.particles
        fx = self.ui.get("fx", "sparks") if self.ui["anim"] and self.ui.get("fps_mode") != "eco" else "none"
        if fx == "weather":
            P.clear()
            self.draw_weather_fx(x0, y0, w, h, dtime, now)
            return
        if fx == "season":
            P.clear()
            self.draw_season(x0, y0, w, h, dtime, now)
            return
        if fx == "stars":
            P.clear()
            for i in range(16):
                sx = x0 + ((i * 0.618034) % 1) * w
                sy = y0 + ((i * 0.381966 + 0.13) % 1) * h
                tw = 0.25 + 0.6 * abs(math.sin(now * 1.3 + i * 1.7))
                c.circle(sx, sy, (0.8 + (i % 3) * 0.4) * S, argb(int(200 * tw), 255, 255, 255))
            return
        if fx == "none":
            P.clear()
            return
        if fx == "sparks":
            rate = (6 + 60 * self.level) if playing else 0     # чем громче, тем больше искр
        else:
            rate = 7
        if rate and len(P) < 50 and random.random() < rate * dtime:
            if fx == "sparks":
                P.append([random.random(), h + 2 * S, -random.uniform(18, 40) * S, random.uniform(1.4, 2.4),
                          random.uniform(1.0, 2.2) * S, random.random()])
            else:
                P.append([random.random(), -2 * S, random.uniform(12, 26) * S, 99.0, random.uniform(1.0, 2.0) * S, random.random()])
        keep = []
        for p in P:
            p[1] += p[2] * dtime
            p[3] -= dtime
            if p[3] <= 0 or p[1] > h + 6 * S or p[1] < -6 * S:
                continue
            keep.append(p)
            px = x0 + (p[0] + math.sin(now * 1.5 + p[5] * 9) * 0.012) * w
            if fx == "sparks":
                col = with_alpha(self.ACC if p[5] < 0.5 else self.ACC2, min(1.0, p[3]) * 0.85)
            else:
                col = argb(170, 255, 255, 255)
            c.circle(px, y0 + p[1], p[4], col)
        self.particles = keep

    def draw_pet(self, cx, cy, playing):
        """Котик: следит глазами за курсором, качает головой под музыку, спит, когда тебя нет."""
        c, S, t = self.cv, self.S, time.time()
        kind = self.ui.get("pet_kind", "ginger")
        fur = {"black": argb(255, 46, 44, 54), "white": argb(255, 236, 236, 242)}.get(kind, argb(255, 255, 176, 84))
        pink, dark = argb(255, 255, 150, 170), argb(255, 40, 30, 30)
        if playing and self.ui["anim"]:
            cy += math.sin(t * 6.5) * (0.6 + 3.0 * self.level) * S    # качается сильнее, когда громко
        r = 9 * S
        if kind == "beetle":
            self.draw_beetle(cx, cy, r, playing, t)
            return
        for sd in (-1, 1):
            c.polygon([(cx + sd * r * 0.98, cy - r * 0.15), (cx + sd * r * 0.82, cy - r * 1.28), (cx + sd * r * 0.1, cy - r * 0.78)], fur)
            c.polygon([(cx + sd * r * 0.8, cy - r * 0.5), (cx + sd * r * 0.74, cy - r * 1.0), (cx + sd * r * 0.38, cy - r * 0.76)], pink)
        c.circle(cx, cy, r, fur)
        asleep = not playing and idle_seconds() > 120
        blink = (t % 4.3) < 0.14
        mx, my = cursor_pos()
        dx, dy = mx - (self.wx + cx), my - (self.wy + cy)
        dist = math.hypot(dx, dy) or 1.0
        for sd in (-1, 1):
            ex, ey = cx + sd * r * 0.42, cy - r * 0.1
            if asleep or blink:
                c.line(ex - r * 0.2, ey, ex + r * 0.2, ey, dark, 1.4 * S)
            else:
                c.circle(ex, ey, r * 0.25, argb(255, 200, 230, 90) if kind == "black" else WHITE)
                c.circle(ex + dx / dist * r * 0.1, ey + dy / dist * r * 0.1, r * 0.14, dark)
        c.polygon([(cx - r * 0.12, cy + r * 0.22), (cx + r * 0.12, cy + r * 0.22), (cx, cy + r * 0.38)], pink)
        c.line(cx, cy + r * 0.38, cx - r * 0.2, cy + r * 0.55, dark, 1 * S)
        c.line(cx, cy + r * 0.38, cx + r * 0.2, cy + r * 0.55, dark, 1 * S)
        if asleep:
            k = (t * 0.6) % 1
            zx, zy, zs = cx + r * (0.9 + k * 0.5), cy - r * (0.8 + k * 0.7), r * 0.28
            col = argb(int(220 * (1 - k)), 200, 205, 255)
            c.line(zx - zs, zy - zs, zx + zs, zy - zs, col, 1.3 * S)
            c.line(zx + zs, zy - zs, zx - zs, zy + zs, col, 1.3 * S)
            c.line(zx - zs, zy + zs, zx + zs, zy + zs, col, 1.3 * S)

    def draw_beetle(self, cx, cy, r, playing, t):
        """Жучок: панцирь в точках, усики качаются под музыку, глаза следят за курсором, спит, когда тебя нет."""
        c, S = self.cv, self.S
        shell, dark = argb(255, 230, 60, 70), argb(255, 30, 26, 32)
        wave = math.sin(t * 7) * (1 + 3 * self.level) * S if playing and self.ui["anim"] else math.sin(t * 2) * 0.6 * S
        for sd in (-1, 1):
            c.line(cx + sd * r * 0.25, cy - r * 0.55, cx + sd * r * 0.7 + wave * sd, cy - r * 1.25, dark, 1.3 * S)
            c.circle(cx + sd * r * 0.7 + wave * sd, cy - r * 1.25, 1.5 * S, dark)
        c.circle(cx, cy - r * 0.35, r * 0.55, dark)                       # голова
        c.circle(cx, cy + r * 0.25, r * 0.85, shell)                      # панцирь
        c.line(cx, cy - r * 0.55, cx, cy + r * 1.05, dark, 1.2 * S)
        for px, py in ((-0.42, 0.05), (0.42, 0.05), (-0.35, 0.55), (0.35, 0.55)):
            c.circle(cx + px * r, cy + py * r, r * 0.14, dark)
        asleep = not playing and idle_seconds() > 120
        mx, my = cursor_pos()
        dx, dy = mx - (self.wx + cx), my - (self.wy + cy)
        dist = math.hypot(dx, dy) or 1.0
        for sd in (-1, 1):
            ex, ey = cx + sd * r * 0.25, cy - r * 0.45
            if asleep or (t % 3.7) < 0.12:
                c.line(ex - r * 0.12, ey, ex + r * 0.12, ey, WHITE, 1.1 * S)
            else:
                c.circle(ex, ey, r * 0.17, WHITE)
                c.circle(ex + dx / dist * r * 0.06, ey + dy / dist * r * 0.06, r * 0.08, dark)

    def mouse_over_rect(self, x0, y0, x1, y1):
        x, y = cursor_pos()
        return self.wx + x0 <= x <= self.wx + x1 and self.wy + y0 <= y <= self.wy + y1

    def draw_expanded(self, x0, y, w, a):
        c, S = self.cv, self.S
        pad = 14 * S
        x, cw = x0 + pad, w - pad * 2
        if self.tab == "command":
            return self.page_command(x, y + 8 * S, cw, a)
        # полоска разделов: только закреплённые + «Все разделы» + настройки, у каждого подпись
        bar = self.bar_tabs()
        n = len(bar)
        cell = cw / n
        cur = self.tab if self.tab in bar else "more"     # раздел из «Все разделы» подсвечивает «Ещё»
        idx = bar.index(cur)
        target = x + cell * idx
        if self.tab_x is None or not self.ui["anim"]:
            self.tab_x = target
        self.tab_x += (target - self.tab_x) * 0.3
        bh = 46 * S
        c.rrect(x - 4 * S, y, cw + 8 * S, bh, 16 * S, with_alpha(argb(255, 20, 20, 28), a * 0.85))
        c.rrect(self.tab_x + 2 * S, y + 3 * S, cell - 4 * S, bh - 6 * S, 13 * S, with_alpha(self.ACC, a * 0.2))
        c.rrect_outline(self.tab_x + 2.5 * S, y + 3.5 * S, cell - 5 * S, bh - 7 * S, 13 * S, with_alpha(self.ACC, a * 0.45), 1 * S)
        for i, name in enumerate(bar):
            cx = x + cell * i + cell / 2
            active = name == cur
            hot = not active and self.mouse_over_rect(x + cell * i, y, x + cell * (i + 1), y + bh)
            if hot:
                c.rrect(x + cell * i + 2 * S, y + 3 * S, cell - 4 * S, bh - 6 * S, 13 * S, with_alpha(argb(22, 255, 255, 255), a))
            pop = 1 + 0.25 * math.sin(self.tab_anim * math.pi) if active and self.ui["anim"] else 1
            col = self.ACC if active else (WHITE if hot else MUTED)
            self.draw_icon(name, cx, y + 17 * S, 8 * S * pop, with_alpha(col, a))
            if not active and self.tab_badge(name):
                c.circle(cx + 9 * S, y + 9 * S, 3.6 * S, with_alpha(argb(255, 255, 69, 58), a))
            c.text(SHORT_TITLES.get(name, name), x + cell * i, y + 27 * S, cell, 15 * S, c.font(9.5, active),
                   with_alpha(WHITE if active else MUTED, a), align=1)
            self.hit(x + cell * i, y, x + cell * (i + 1), y + bh, lambda n=name: self.open_tab(n))
        y += bh + 10 * S
        title = ALL_TITLES.get(self.tab, "")
        k = self.tab_anim
        dx = (1 - k) * 22 * S * self.tab_dir
        pa = a * (k if self.ui["anim"] else 1)
        c.text(title, x + dx, y, cw, 24 * S, c.font(17, True), with_alpha(WHITE, pa))
        if self.tab not in bar and self.tab != "more":    # открыто из «Все разделы» - можно закрепить
            pinned = self.tab in self.pinned()
            lab = "Убрать сверху" if pinned else "Закрепить сверху"
            lw_ = c.measure(lab, c.font(10.5, True)) + 18 * S
            self.button(lab, x + cw - lw_, y + 1 * S, lw_, 22 * S, lambda t=self.tab: self.toggle_pin(t), pa,
                        font=c.font(10.5, True))
        y += 32 * S
        page = getattr(self, "page_" + self.tab)
        if self.tab == "notifs":
            self.notifs_seen = time.time()
        end = page(x + dx, y, cw, pa)
        if self.tab == "music":
            end = self.draw_music_extra(x + dx, end, cw, pa)
        elif self.tab == "summary":
            end = self.draw_week_top(x + dx, end, cw, pa)
        return end

    def start_cover_gesture(self):
        self.gesture = {"x": self.click_xy[0], "t": time.time()}

    def end_cover_gesture(self, x):
        g, self.gesture = self.gesture, None
        if not g:
            return
        dx = x - g["x"]
        if abs(dx) > 40 * self.S:
            self.media.command("next" if dx < 0 else "prev")
            self.show_toast("Следующий трек" if dx < 0 else "Предыдущий трек", "music", 1.2)
            return
        now = time.time()
        if now - getattr(self, "last_cover_tap", 0) < 0.4:
            self.media.command("toggle")
            self.last_cover_tap = 0
        else:
            self.last_cover_tap = now

    def wheel_volume(self, delta):
        if not self.audio:
            return
        v = self.audio.volume() or 0.0
        self.audio.set_volume(clamp(v + (0.04 if delta > 0 else -0.04), 0, 1))
        self.audio.set_mute(False)

    def toggle_favorite(self):
        st = self.media.state
        key = f"{st.get('artist', '')} — {st.get('title', '')}".strip(" —")
        if not key:
            return
        fav = list(self.settings.get("favorites", []))
        if key in fav:
            fav.remove(key)
            self.show_toast("Убрано из избранного", "heart", 1.5)
        else:
            fav.insert(0, key)
            self.show_toast("Добавлено в избранное", "heart", 1.5)
        self.settings["favorites"] = fav[:200]
        save_json(SETTINGS_FILE, self.settings)

    def draw_music_extra(self, x, y, w, a):
        """Под плеером: «в избранное» и громкость каждой программы (как микшер Windows)."""
        c, S = self.cv, self.S
        st = self.media.state if self.music() else None
        if st:
            key = f"{st.get('artist', '')} — {st.get('title', '')}".strip(" —")
            fav = key in self.settings.get("favorites", [])
            lab = "В избранном" if fav else "В избранное"
            bw = c.measure(lab, c.font(11, True)) + 40 * S
            self.button("", x, y, bw, 26 * S, self.toggle_favorite, a, on=fav)
            self.draw_icon("heart", x + 16 * S, y + 13 * S, 6 * S, with_alpha(WHITE, a))
            c.text(lab, x + 26 * S, y, bw - 30 * S, 26 * S, c.font(11, True), with_alpha(DARK_TEXT if fav else WHITE, a), align=1)
            n = len(self.settings.get("favorites", []))
            if n:
                c.text(f"в избранном песен: {n}", x + bw + 8 * S, y, w - bw - 8 * S, 26 * S, c.font(10.5), with_alpha(DIM, a))
            y += 36 * S
        outs = [o for o in self.outputs if "steam streaming" not in o[1].lower()]
        if len(outs) > 1:
            # куда выводить звук: колонки, наушники, Bluetooth (как в Dyland)
            y = self.section_title("Звук идёт в", x, y, w, a)

            def short(n):
                m = re.match(r"^[^()]*\((.+)\)\s*$", n)
                return (m.group(1) if m else n)[:22]

            def pick(dev_id):
                if more.set_output_device(dev_id):
                    self.outs_at = 0
                    self.outputs = more.output_devices()
            y = self.chips(x, y, w, [(short(n), i) for i, n, _ in outs], lambda v: any(d and i == v for i, _, d in outs), pick, a)
        apps = self.mix_apps
        if not apps:
            return y
        y = self.section_title("Громкость программ", x, y, w, a)
        rows = len(apps)
        self.card(x, y, w, rows * 34 * S, 14 * S, a)
        for i, (name, vol, mute) in enumerate(apps):
            ry = y + i * 34 * S
            mx = x + 18 * S
            self.draw_icon("mute" if mute or vol == 0 else "vol_up", mx, ry + 17 * S, 6.5 * S, with_alpha(RED if mute else WHITE, a))
            self.hit(mx - 12 * S, ry, mx + 12 * S, ry + 34 * S,
                     lambda n=name: (self.mixer.toggle_mute(n), setattr(self, "mix_apps", self.mixer.refresh())))
            c.text(name, x + 34 * S, ry, 96 * S, 34 * S, c.font(11.5, True), with_alpha(WHITE, a))
            bx, bw_ = x + 136 * S, w - 136 * S - 50 * S
            c.rrect(bx, ry + 15 * S, bw_, 5 * S, 2.5 * S, with_alpha(argb(255, 60, 60, 80), a))
            fill = 0 if mute else vol
            if fill > 0:
                c.rrect(bx, ry + 15 * S, max(5 * S, bw_ * fill), 5 * S, 2.5 * S, with_alpha(self.ACC, a))
            c.circle(bx + bw_ * fill, ry + 17.5 * S, 5 * S, with_alpha(WHITE, a))
            c.text("без звука" if mute else f"{round(vol * 100)}%", x + w - 50 * S, ry, 40 * S, 34 * S, c.font(10.5), with_alpha(MUTED, a), align=2)

            def set_v(n=name, bx=bx, bw=bw_):
                self.mixer.set_volume(n, clamp((self.click_xy[0] - bx) / bw, 0, 1))
                self.mix_apps = self.mixer.refresh()
            self.hit(bx - 6 * S, ry, bx + bw_ + 6 * S, ry + 34 * S, set_v)
            if i < rows - 1:
                c.line(x + 34 * S, ry + 34 * S, x + w - 10 * S, ry + 34 * S, with_alpha(WHITE, a * 0.06), 1 * S)
        return y + rows * 34 * S + 10 * S

    # ---------- главный цикл ----------
    def fullscreen_app(self):
        if not self.ui["hide_fullscreen"]:
            return False
        fg = user32.GetForegroundWindow()
        if not fg or fg == self.hwnd:
            return False
        buf = ctypes.create_unicode_buffer(64)
        user32.GetClassNameW(fg, buf, 64)
        if buf.value in ("Progman", "WorkerW", "Shell_TrayWnd"):
            return False
        r = wt.RECT()
        user32.GetWindowRect(fg, ctypes.byref(r))
        ml, mt, mr, mb = self.monitor
        return r.left <= ml and r.top <= mt and r.right >= mr and r.bottom >= mb

    def check_click_outside(self):
        down = bool(user32.GetAsyncKeyState(0x01) & 0x8000)
        if down and not self.prev_lbutton and self.expanded:
            x, y = cursor_pos()
            x0, y0, x1, y1 = self.island
            if not (self.wx + x0 <= x <= self.wx + x1 and self.wy + y0 <= y <= self.wy + y1):
                self.expanded = False
                self.typing = None
                self.cal_offset = 0
        self.prev_lbutton = down

    def run(self):
        msg = wt.MSG()
        start = time.time()
        last_check = 0
        threading.Thread(target=self._scan_loop, daemon=True).start()
        threading.Thread(target=self._net_loop, daemon=True).start()
        try:
            while self.running:
                while user32.PeekMessageW(ctypes.byref(msg), None, 0, 0, 1):
                    if msg.message == WM_QUIT:
                        self.running = False
                        break
                    user32.TranslateMessage(ctypes.byref(msg))
                    user32.DispatchMessageW(ctypes.byref(msg))
                busy = True
                try:
                    now = time.time()
                    if now - last_check > 1:
                        last_check = now
                        self.update_system()
                        hide = self.user_hidden or self.fullscreen_app() or self.hidden_by_app()
                        if hide != self.hidden:
                            self.hidden = hide
                            user32.ShowWindow(self.hwnd, 0 if hide else 4)
                        if not hide:
                            user32.SetWindowPos(self.hwnd, HWND_TOPMOST, 0, 0, 0, 0, 0x1 | 0x2 | 0x10)
                        if self.settings.get("city") and now - self.weather_at > 900:
                            self.weather_at = now
                            threading.Thread(target=self.update_weather, daemon=True).start()
                    self.check_click_outside()
                    if not self.hidden:
                        busy = self.frame() or self.mouse_over()
                    else:
                        self.process_notif_events(now)
                    busy = self.side_frame(time.time()) or busy
                except Exception:
                    self.errors += 1
                    if self.errors <= 3:
                        traceback.print_exc()
                if self.run_seconds and time.time() - start > self.run_seconds:
                    break
                time.sleep(1 / {"smooth": 60, "eco": 15}.get(self.ui.get("fps_mode"), FPS) if busy else 0.12)
        except KeyboardInterrupt:
            pass
        finally:
            self.save_stats()
            self.media.stop()
            self.notifw.stop()
            if self.icons_hidden_by_us or self.ui.get("icons_hidden"):
                extra.set_desktop_icons(True)       # значки рабочего стола возвращаем, как было
                self.ui["icons_hidden"] = False
                save_json(SETTINGS_FILE, self.settings)
            user32.DestroyWindow(self.side_hwnd)
            user32.DestroyWindow(self.hwnd)


def main():
    global APP_DIR, SETTINGS_FILE, NOTES_FILE, LYRICS_DIR
    try:
        sys.stdout.reconfigure(errors="replace")
    except Exception:
        pass
    args = sys.argv
    seconds = float(args[args.index("--seconds") + 1]) if "--seconds" in args else None
    if "--data" in args:   # отдельная папка настроек (для проверки)
        APP_DIR = core.APP_DIR = args[args.index("--data") + 1]
        SETTINGS_FILE = os.path.join(APP_DIR, "settings.json")
        NOTES_FILE = os.path.join(APP_DIR, "notes.json")
        LYRICS_DIR = os.path.join(APP_DIR, "lyrics")
    if "--city" in args:
        s = load_json(SETTINGS_FILE, {})
        s["city"] = args[args.index("--city") + 1]
        s.pop("lat", None)
        save_json(SETTINGS_FILE, s)

    k32 = ctypes.WinDLL("kernel32", use_last_error=True)
    k32.CreateMutexW.restype = H
    k32.CreateMutexW.argtypes = [VP, wt.BOOL, wt.LPCWSTR]
    _mutex = k32.CreateMutexW(None, False, "DesktopIslandSingleInstance")  # noqa: F841 (держим до выхода)
    if ctypes.get_last_error() == 183 and "--data" not in args:
        print("Островок уже запущен.")
        return
    print("Островок запущен! Наведи мышку - мини-иконки, клик - раскрыть, правый клик - меню.")
    app = Island(seconds)
    if "--tab" in args:
        app.open_tab(args[args.index("--tab") + 1])
    app.run()
    print(f"Пока! (ошибок: {app.errors})")


if __name__ == "__main__":
    main()
