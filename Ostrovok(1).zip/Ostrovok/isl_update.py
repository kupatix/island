"""Автообновление островка.

Где-то в интернете лежат рядом два файла: version.json и Ostrovok.zip (их делает site/build.py).
version.json: {"version": "2.6", "zip": "Ostrovok.zip", "sha256": "...", "size": 123, "notes": ["..."],
               "python": "3.13.2"}
Островок раз в 6 часов скачивает version.json. Если версия новее - показывает «Доступно обновление».
По кнопке: скачивает архив, сверяет sha256 (если хоть байт не совпал - ничего не ставит), заменяет только
свои файлы (.py/.ps1/.md/.txt), а папку python - только если в обновлении другой Python.
Старые файлы сохраняются в папку backup, чтобы можно было откатиться.
"""
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
import zipfile

VERSION = "2.9"
HERE = os.path.dirname(os.path.abspath(__file__))
APP_FILES = ("island.py", "isl_core.py", "isl_calls.py", "isl_extra.py", "isl_fps.py", "isl_more.py", "isl_update.py", "isl_battery.py", "isl_qr.py",
             "media.ps1", "notif.ps1", "README.md", "THIRD_PARTY.txt", "install.bat", "install.ps1",
             "uninstall.bat", "uninstall.ps1")
MAX_ZIP = 200 * 1024 * 1024


def parse_version(v):
    out = []
    for part in str(v).split("."):
        digits = "".join(ch for ch in part if ch.isdigit())
        out.append(int(digits) if digits else 0)
    return tuple(out)


def newer(remote, local=VERSION):
    return parse_version(remote) > parse_version(local)


def _get(url, limit, timeout=20):
    if not url.lower().startswith("https://"):
        raise ValueError("обновления берём только по https")
    req = urllib.request.Request(url, headers={"User-Agent": f"Ostrovok/{VERSION}"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = r.read(limit + 1)
    if len(data) > limit:
        raise ValueError("файл слишком большой")
    return data


def check(url):
    """Возвращает данные о новой версии или None, если обновлений нет."""
    info = json.loads(_get(url, 64 * 1024).decode("utf-8"))
    ver = str(info.get("version", ""))
    if not ver or not newer(ver):
        return None
    info["zip_url"] = urllib.parse.urljoin(url, info.get("zip", "Ostrovok.zip"))
    return info


def install(info, progress=None):
    """Скачивает, проверяет и ставит обновление в папку островка. Возвращает True при успехе."""
    want = (info.get("sha256") or "").lower()
    if len(want) != 64:
        raise ValueError("в version.json нет sha256 - такое обновление не ставим")
    if progress:
        progress("Скачиваю обновление…")
    data = _get(info["zip_url"], MAX_ZIP, timeout=120)
    if hashlib.sha256(data).hexdigest() != want:
        raise ValueError("архив повреждён или подменён - обновление отменено")
    tmp = tempfile.mkdtemp(prefix="ostrovok-upd-")
    try:
        zpath = os.path.join(tmp, "upd.zip")
        with open(zpath, "wb") as f:
            f.write(data)
        if progress:
            progress("Распаковываю…")
        with zipfile.ZipFile(zpath) as z:
            names = z.namelist()
            # проверяем пути: ничего за пределы папки обновления
            for n in names:
                if n.startswith("/") or ".." in n.replace("\\", "/").split("/"):
                    raise ValueError("странный путь в архиве - обновление отменено")
            z.extractall(os.path.join(tmp, "x"))
        root = os.path.join(tmp, "x", "Ostrovok")
        if not os.path.isfile(os.path.join(root, "island.py")):
            raise ValueError("в архиве нет островка")
        # бэкап текущих файлов
        backup = os.path.join(HERE, "backup")
        os.makedirs(backup, exist_ok=True)
        for f in APP_FILES:
            src = os.path.join(HERE, f)
            if os.path.isfile(src):
                shutil.copy2(src, os.path.join(backup, f))
        if progress:
            progress("Ставлю новые файлы…")
        for f in APP_FILES:
            src = os.path.join(root, f)
            if os.path.isfile(src):
                tmp_dst = os.path.join(HERE, f + ".new")
                shutil.copy2(src, tmp_dst)
                os.replace(tmp_dst, os.path.join(HERE, f))
        # папку python не трогаем: запущенный Python нельзя заменить на ходу (при новой версии Python
        # нужно будет один раз заново запустить install.bat)
        return True
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def restart():
    """Запускает новый островок через пару секунд и даёт старому закрыться."""
    exe = sys.executable
    if exe.lower().endswith("python.exe") and os.path.exists(exe[:-10] + "pythonw.exe"):
        exe = exe[:-10] + "pythonw.exe"
    script = os.path.join(HERE, "island.py")
    cmd = f'ping -n 3 127.0.0.1 >nul & start "" "{exe}" "{script}"'
    subprocess.Popen(["cmd.exe", "/c", cmd], creationflags=0x08000000, cwd=HERE)


def make_version_json(zip_path, notes, base_name="Ostrovok.zip"):
    """Для site/build.py: описание текущей версии рядом с архивом."""
    h = hashlib.sha256(open(zip_path, "rb").read()).hexdigest()
    return {"version": VERSION, "zip": base_name, "sha256": h, "size": os.path.getsize(zip_path),
            "python": sys.version.split()[0], "date": time.strftime("%Y-%m-%d"), "notes": notes}
