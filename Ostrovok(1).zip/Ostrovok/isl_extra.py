"""Новые штуки островка (идеи взяты из Atoll, MIT License, (c) 2026 mykolaichechelnytskyi):
кто занимает микрофон и камеру, загрузки «вживую», список программ для командной строки,
инструменты для текста, «чистый рабочий стол» и поиск VPN-программы.
Всё работает только на этом компьютере, ничего никуда не отправляется."""
import ctypes
import ctypes.wintypes as wt
import os
import re
import subprocess
import time
import winreg

user32 = ctypes.WinDLL("user32", use_last_error=True)
shell32 = ctypes.WinDLL("shell32")

# ───────────────────────── микрофон и камера ─────────────────────────
_CAP = r"Software\Microsoft\Windows\CurrentVersion\CapabilityAccessManager\ConsentStore"


def _running_exes():
    """Имена запущенных .exe (в нижнем регистре) - через снимок процессов, без PowerShell."""
    names = set()
    TH32CS_SNAPPROCESS = 2

    class PE(ctypes.Structure):
        _fields_ = [("dwSize", wt.DWORD), ("cntUsage", wt.DWORD), ("th32ProcessID", wt.DWORD),
                    ("th32DefaultHeapID", ctypes.c_size_t), ("th32ModuleID", wt.DWORD), ("cntThreads", wt.DWORD),
                    ("th32ParentProcessID", wt.DWORD), ("pcPriClassBase", ctypes.c_long), ("dwFlags", wt.DWORD),
                    ("szExeFile", ctypes.c_wchar * 260)]
    k32 = ctypes.WinDLL("kernel32")
    k32.CreateToolhelp32Snapshot.restype = wt.HANDLE
    snap = k32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if not snap or snap == wt.HANDLE(-1).value:
        return names
    e = PE()
    e.dwSize = ctypes.sizeof(PE)
    ok = k32.Process32FirstW(snap, ctypes.byref(e))
    while ok:
        names.add(e.szExeFile.lower())
        ok = k32.Process32NextW(snap, ctypes.byref(e))
    k32.CloseHandle(snap)
    return names


def _in_use(capability, running):
    apps = []
    try:
        root = winreg.OpenKey(winreg.HKEY_CURRENT_USER, _CAP + "\\" + capability)
    except OSError:
        return apps

    def active(key):
        try:
            start = winreg.QueryValueEx(key, "LastUsedTimeStart")[0]
            stop = winreg.QueryValueEx(key, "LastUsedTimeStop")[0]
        except OSError:
            return False
        if start <= 0 or stop != 0:
            return False
        # старше суток - это «забытая» отметка, а не идущий разговор
        unix = start / 10_000_000 - 11644473600
        return time.time() - unix < 86400

    i = 0
    while True:
        try:
            name = winreg.EnumKey(root, i)
        except OSError:
            break
        i += 1
        try:
            if name == "NonPackaged":
                np_ = winreg.OpenKey(root, name)
                j = 0
                while True:
                    try:
                        exe = winreg.EnumKey(np_, j)
                    except OSError:
                        break
                    j += 1
                    if active(winreg.OpenKey(np_, exe)):
                        base = os.path.basename(exe.replace("#", "\\"))
                        if base.lower() in running and not base.lower().startswith("python"):
                            apps.append(os.path.splitext(base)[0])
            elif active(winreg.OpenKey(root, name)):
                n = name.split("_")[0]
                apps.append(n.rsplit(".", 1)[-1])
        except OSError:
            pass
    return sorted(set(apps))


def privacy_usage():
    """(кто занимает микрофон, кто занимает камеру) - как значок микрофона на панели задач."""
    running = _running_exes()
    return _in_use("microphone", running), _in_use("webcam", running)


# ───────────────────────── загрузки ─────────────────────────
TEMP_EXT = (".crdownload", ".part", ".download", ".partial", ".opdownload")


def downloads_folder():
    buf = ctypes.c_wchar_p()
    guid = (ctypes.c_byte * 16)(*bytes.fromhex("90e24d373f126545916439c4925e467b"))
    try:
        if shell32.SHGetKnownFolderPath(guid, 0, None, ctypes.byref(buf)) == 0:
            path = buf.value
            ctypes.windll.ole32.CoTaskMemFree(buf)
            return path
    except Exception:
        pass
    return os.path.join(os.path.expanduser("~"), "Downloads")


class DownloadWatcher:
    """Следит за папкой «Загрузки»: что качается сейчас (и с какой скоростью) и что докачалось."""

    def __init__(self):
        self.folder = downloads_folder()
        self.seen = {}          # путь временного файла -> (размер, время, скорость)
        self.current = None     # (имя, байт, байт/с, сколько файлов)
        self.last_active = 0

    def poll(self):
        """Возвращает список путей докачанных файлов."""
        done = []
        now = time.time()
        try:
            temps = []
            for e in os.scandir(self.folder):
                if e.is_file() and e.name.lower().endswith(TEMP_EXT):
                    st = e.stat()
                    if now - st.st_mtime < 120:
                        temps.append((e.path, e.name, st.st_size))
        except OSError:
            return done
        paths = {p for p, _, _ in temps}
        for p, _, size in temps:
            if p in self.seen:
                psize, pat, pspeed = self.seen[p]
                speed = max(0.0, (size - psize) / max(0.2, now - pat))
                self.seen[p] = (size, now, pspeed * 0.6 + speed * 0.4)
            else:
                self.seen[p] = (size, now, 0.0)
        for p in [p for p in self.seen if p not in paths]:
            del self.seen[p]
            fin = self._finished(p)
            if fin:
                done.append(fin)
        if temps:
            self.last_active = now
            p, name, size = max(temps, key=lambda t: self.seen[t[0]][2])
            pretty = os.path.splitext(name)[0]
            if pretty.lower().startswith(("unconfirmed", "неподтвержд")):
                pretty = "файл"
            self.current = (pretty, size, self.seen[p][2], len(temps))
        elif now - self.last_active > 2:
            self.current = None
        return done

    def _finished(self, temp):
        direct = os.path.splitext(temp)[0]
        if os.path.isfile(direct):
            return direct
        try:
            fresh = [e for e in os.scandir(self.folder)
                     if e.is_file() and not e.name.lower().endswith(TEMP_EXT) and time.time() - e.stat().st_mtime < 8]
            if fresh:
                return max(fresh, key=lambda e: e.stat().st_mtime).path
        except OSError:
            pass
        return None


def fmt_bytes(b):
    if b >= 1 << 30:
        return f"{b / (1 << 30):.1f} ГБ"
    if b >= 1 << 20:
        return f"{b / (1 << 20):.1f} МБ"
    return f"{max(1, b / 1024):.0f} КБ"


# ───────────────────────── программы для командной строки ─────────────────────────
class AppIndex:
    def __init__(self):
        self.apps = []
        self.loaded = False

    def load(self):
        found = {}
        roots = [os.path.join(os.environ.get("ProgramData", r"C:\ProgramData"), r"Microsoft\Windows\Start Menu"),
                 os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu"),
                 os.path.join(os.path.expanduser("~"), "Desktop")]
        try:
            from ctypes import wintypes  # noqa: F401
            desk = ctypes.create_unicode_buffer(260)
            if shell32.SHGetFolderPathW(None, 0x10, None, 0, desk) == 0:
                roots.append(desk.value)
        except Exception:
            pass
        for root in roots:
            for d, _, files in os.walk(root):
                for f in files:
                    if not f.lower().endswith((".lnk", ".url")):
                        continue
                    name = os.path.splitext(f)[0]
                    if re.search(r"uninstall|удал|деинстал", name, re.I):
                        continue
                    found.setdefault(name.lower(), (name, os.path.join(d, f)))
        self.apps = sorted(found.values(), key=lambda a: a[0].lower())
        self.loaded = True

    def search(self, q, limit=5):
        q = q.strip().lower()
        if not q:
            return []
        res = []
        for name, path in self.apps:
            n = name.lower()
            if n.startswith(q):
                score = 3
            elif any(w.startswith(q) for w in re.split(r"[\s\-_.]+", n)):
                score = 2
            elif q in n:
                score = 1
            else:
                continue
            res.append((score, -len(name), name, path))
        res.sort(reverse=True)
        return [(name, path) for _, _, name, path in res[:limit]]


# ───────────────────────── инструменты для текста ─────────────────────────
_EN = "`qwertyuiop[]asdfghjkl;'zxcvbnm,./~QWERTYUIOP{}ASDFGHJKL:\"ZXCVBNM<>?@#$^&"
_RU = "ёйцукенгшщзхъфывапролджэячсмитьбю.ЁЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮ,\"№;:?"
_TR = {"а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ё": "yo", "ж": "zh", "з": "z", "и": "i", "й": "y",
       "к": "k", "л": "l", "м": "m", "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u", "ф": "f",
       "х": "kh", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "shch", "ъ": "", "ы": "y", "ь": "", "э": "e", "ю": "yu",
       "я": "ya", "і": "i", "ї": "yi", "є": "ye", "ґ": "g"}


def swap_layout(s):
    """«ghbdtn» -> «привет» и обратно: текст, набранный не в той раскладке."""
    latin = sum(1 for ch in s if "a" <= ch.lower() <= "z")
    cyr = sum(1 for ch in s if "а" <= ch.lower() <= "я" or ch in "ёЁ")
    src, dst = (_EN, _RU) if latin >= cyr else (_RU, _EN)
    return "".join(dst[src.index(ch)] if ch in src else ch for ch in s)


def sentence_case(s):
    out, start = [], True
    for ch in s.lower():
        if ch.isalpha():
            out.append(ch.upper() if start else ch)
            start = False
        else:
            out.append(ch)
            if ch in ".!?\n":
                start = True
    return "".join(out)


def translit(s):
    out = []
    for ch in s:
        t = _TR.get(ch.lower())
        if t is None:
            out.append(ch)
        else:
            out.append(t[:1].upper() + t[1:] if ch.isupper() and t else t)
    return "".join(out)


TEXT_TOOLS = [("Раскладка", swap_layout), ("АБВ", str.upper), ("абв", str.lower),
              ("Абв.", sentence_case), ("Транслит", translit)]


# ───────────────────────── чистый рабочий стол ─────────────────────────
user32.FindWindowW.restype = wt.HWND
user32.FindWindowW.argtypes = [wt.LPCWSTR, wt.LPCWSTR]
user32.FindWindowExW.restype = wt.HWND
user32.FindWindowExW.argtypes = [wt.HWND, wt.HWND, wt.LPCWSTR, wt.LPCWSTR]
_ENUM = ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)


def _desktop_icons():
    view = user32.FindWindowExW(user32.FindWindowW("Progman", None), None, "SHELLDLL_DefView", None)
    if not view:
        found = []

        def cb(h, _):
            v = user32.FindWindowExW(h, None, "SHELLDLL_DefView", None)
            if v:
                found.append(v)
                return False
            return True
        user32.EnumWindows(_ENUM(cb), 0)
        view = found[0] if found else None
    return user32.FindWindowExW(view, None, "SysListView32", None) if view else None


def desktop_icons_visible():
    h = _desktop_icons()
    return not h or bool(user32.IsWindowVisible(h))


def set_desktop_icons(visible):
    h = _desktop_icons()
    if h:
        user32.ShowWindow(h, 5 if visible else 0)


# ───────────────────────── Wi-Fi и VPN ─────────────────────────
_VPN_WORDS = re.compile(r"wintun|tap-windows|wireguard|openvpn|amnezia|happ|hiddify|sing-?box|sing-tun|outline|"
                        r"proton|windscribe|mullvad|warp|nekoray|v2ray|clash|tun2socks|vpn", re.I)


def net_state():
    """(имя Wi-Fi или None, имя VPN-адаптера или None). Только читаем, ничего не меняем."""
    ssid = None
    try:
        out = subprocess.run(["netsh", "wlan", "show", "interfaces"], capture_output=True, timeout=8,
                             creationflags=0x08000000).stdout.decode("cp866", "replace")
        for line in out.splitlines():
            m = re.match(r"^\s*SSID\s*:\s*(.+)$", line)
            if m:
                ssid = m.group(1).strip() or None
                break
    except (OSError, subprocess.SubprocessError):
        pass
    vpn = None
    try:
        out = subprocess.run(["ipconfig", "/all"], capture_output=True, timeout=8,
                             creationflags=0x08000000).stdout.decode("cp866", "replace")
        for block in re.split(r"\r?\n(?=\S)", out):
            if _VPN_WORDS.search(block) and re.search(r"IPv4[^:]*:\s*\d+\.\d+\.\d+\.\d+", block):
                name = block.splitlines()[0].strip().rstrip(":")
                name = re.sub(r"^.*?(adapter|адаптер)\s+", "", name, flags=re.I)
                vpn = name or "VPN"
                break
    except (OSError, subprocess.SubprocessError):
        pass
    return ssid, vpn


# ───────────────────────── VPN ─────────────────────────
VPN_APPS = ["Happ", "Hiddify", "v2rayN", "AmneziaVPN", "Amnezia", "Outline", "WireGuard", "NekoRay", "Nekobox",
            "Throne", "Clash Verge", "Karing", "Streisand", "Proton VPN", "Windscribe", "Mullvad VPN",
            "Cloudflare WARP", "Planet VPN", "Psiphon"]


def find_vpn_app(index):
    for want in VPN_APPS:
        for name, path in index.apps:
            if name.lower().startswith(want.lower()):
                return name, path
    return None


def run_hidden(args):
    try:
        subprocess.Popen(args, creationflags=0x08000000)
    except OSError:
        pass
