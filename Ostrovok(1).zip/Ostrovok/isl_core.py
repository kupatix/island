# -*- coding: utf-8 -*-
"""Основа островка: Windows API, рисование (GDI+), музыка, тексты песен, погода."""
import base64
import ctypes
import ctypes.wintypes as wt
import hashlib
import json
import os
import re
import struct
import subprocess
import threading
import time
import traceback
import urllib.parse
import urllib.request

APP_DIR = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "DesktopIsland")
HERE = os.path.dirname(os.path.abspath(__file__))
USER_AGENT = "DesktopIsland/1.0"


def argb(a, r, g, b):
    return ((int(a) & 255) << 24) | ((int(r) & 255) << 16) | ((int(g) & 255) << 8) | (int(b) & 255)


def rgb(c, a=255):
    return argb(a, *c)


def with_alpha(color, k):
    return (color & 0x00FFFFFF) | (int(((color >> 24) & 255) * max(0.0, min(1.0, k))) << 24)


def hsv(h, s=0.75, v=1.0):
    i = int(h * 6) % 6
    f = h * 6 - int(h * 6)
    p, q, t = v * (1 - s), v * (1 - f * s), v * (1 - (1 - f) * s)
    r, g, b = [(v, t, p), (q, v, p), (p, v, t), (p, q, v), (t, p, v), (v, p, q)][i]
    return argb(255, r * 255, g * 255, b * 255)


# ───────────────────────── Windows API ─────────────────────────
user32 = ctypes.WinDLL("user32", use_last_error=True)
gdi32 = ctypes.WinDLL("gdi32")
kernel32 = ctypes.WinDLL("kernel32")
gdiplus = ctypes.WinDLL("gdiplus")

try:
    ctypes.WinDLL("shcore").SetProcessDpiAwareness(2)
except Exception:
    try:
        user32.SetProcessDPIAware()
    except Exception:
        pass
try:
    ctypes.WinDLL("winmm").timeBeginPeriod(1)
except Exception:
    pass

LRESULT = ctypes.c_ssize_t
H = wt.HANDLE
VP = ctypes.c_void_p
F = ctypes.c_float
I = ctypes.c_int
U32 = ctypes.c_uint32
WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)


class WNDCLASSEXW(ctypes.Structure):
    _fields_ = [("cbSize", wt.UINT), ("style", wt.UINT), ("lpfnWndProc", WNDPROC),
                ("cbClsExtra", I), ("cbWndExtra", I), ("hInstance", H), ("hIcon", H), ("hCursor", H),
                ("hbrBackground", H), ("lpszMenuName", wt.LPCWSTR), ("lpszClassName", wt.LPCWSTR), ("hIconSm", H)]


class BITMAPINFOHEADER(ctypes.Structure):
    _fields_ = [("biSize", wt.DWORD), ("biWidth", wt.LONG), ("biHeight", wt.LONG), ("biPlanes", wt.WORD),
                ("biBitCount", wt.WORD), ("biCompression", wt.DWORD), ("biSizeImage", wt.DWORD),
                ("biXPelsPerMeter", wt.LONG), ("biYPelsPerMeter", wt.LONG), ("biClrUsed", wt.DWORD),
                ("biClrImportant", wt.DWORD)]


class BLENDFUNCTION(ctypes.Structure):
    _fields_ = [("BlendOp", ctypes.c_byte), ("BlendFlags", ctypes.c_byte),
                ("SourceConstantAlpha", ctypes.c_ubyte), ("AlphaFormat", ctypes.c_byte)]


class MONITORINFO(ctypes.Structure):
    _fields_ = [("cbSize", wt.DWORD), ("rcMonitor", wt.RECT), ("rcWork", wt.RECT), ("dwFlags", wt.DWORD)]


class POWERSTATUS(ctypes.Structure):
    _fields_ = [("ACLineStatus", ctypes.c_ubyte), ("BatteryFlag", ctypes.c_ubyte),
                ("BatteryLifePercent", ctypes.c_ubyte), ("SystemStatusFlag", ctypes.c_ubyte),
                ("BatteryLifeTime", wt.DWORD), ("BatteryFullLifeTime", wt.DWORD)]


class MEMORYSTATUSEX(ctypes.Structure):
    _fields_ = [("dwLength", wt.DWORD), ("dwMemoryLoad", wt.DWORD)] + \
               [(n, ctypes.c_uint64) for n in ("total", "avail", "tpage", "apage", "tvirt", "avirt", "aext")]


class RectF(ctypes.Structure):
    _fields_ = [("X", F), ("Y", F), ("Width", F), ("Height", F)]


class PointF(ctypes.Structure):
    _fields_ = [("X", F), ("Y", F)]


class GdiplusStartupInput(ctypes.Structure):
    _fields_ = [("GdiplusVersion", U32), ("DebugEventCallback", VP),
                ("SuppressBackgroundThread", wt.BOOL), ("SuppressExternalCodecs", wt.BOOL)]


def sig(func, restype, *argtypes):
    func.restype = restype
    func.argtypes = list(argtypes)


sig(kernel32.GetModuleHandleW, H, wt.LPCWSTR)
sig(kernel32.GlobalLock, VP, H)
sig(kernel32.GlobalUnlock, wt.BOOL, H)
sig(kernel32.GetSystemPowerStatus, wt.BOOL, ctypes.POINTER(POWERSTATUS))
sig(kernel32.LCIDToLocaleName, I, wt.DWORD, wt.LPWSTR, I, wt.DWORD)
sig(kernel32.GetSystemTimes, wt.BOOL, ctypes.POINTER(wt.FILETIME), ctypes.POINTER(wt.FILETIME), ctypes.POINTER(wt.FILETIME))
sig(kernel32.GlobalMemoryStatusEx, wt.BOOL, ctypes.POINTER(MEMORYSTATUSEX))
sig(kernel32.GetDiskFreeSpaceExW, wt.BOOL, wt.LPCWSTR, ctypes.POINTER(ctypes.c_uint64),
    ctypes.POINTER(ctypes.c_uint64), ctypes.POINTER(ctypes.c_uint64))
sig(kernel32.GetTickCount64, ctypes.c_uint64)
sig(user32.RegisterClassExW, wt.ATOM, ctypes.POINTER(WNDCLASSEXW))
sig(user32.CreateWindowExW, wt.HWND, wt.DWORD, wt.LPCWSTR, wt.LPCWSTR, wt.DWORD, I, I, I, I, wt.HWND, H, H, VP)
sig(user32.DefWindowProcW, LRESULT, wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)
sig(user32.ShowWindow, wt.BOOL, wt.HWND, I)
sig(user32.DestroyWindow, wt.BOOL, wt.HWND)
sig(user32.PeekMessageW, wt.BOOL, ctypes.POINTER(wt.MSG), wt.HWND, wt.UINT, wt.UINT, wt.UINT)
sig(user32.TranslateMessage, wt.BOOL, ctypes.POINTER(wt.MSG))
sig(user32.DispatchMessageW, LRESULT, ctypes.POINTER(wt.MSG))
sig(user32.GetDC, H, wt.HWND)
sig(user32.ReleaseDC, I, wt.HWND, H)
sig(user32.UpdateLayeredWindow, wt.BOOL, wt.HWND, H, ctypes.POINTER(wt.POINT), ctypes.POINTER(wt.SIZE),
    H, ctypes.POINTER(wt.POINT), wt.DWORD, ctypes.POINTER(BLENDFUNCTION), wt.DWORD)
sig(user32.SetWindowPos, wt.BOOL, wt.HWND, wt.HWND, I, I, I, I, wt.UINT)
sig(user32.GetCursorPos, wt.BOOL, ctypes.POINTER(wt.POINT))
sig(user32.GetAsyncKeyState, ctypes.c_short, I)
sig(user32.MonitorFromPoint, H, wt.POINT, wt.DWORD)
sig(user32.GetMonitorInfoW, wt.BOOL, H, ctypes.POINTER(MONITORINFO))
sig(user32.GetForegroundWindow, wt.HWND)
sig(user32.GetWindowThreadProcessId, wt.DWORD, wt.HWND, VP)
sig(user32.GetKeyboardLayout, H, wt.DWORD)
sig(user32.GetWindowRect, wt.BOOL, wt.HWND, ctypes.POINTER(wt.RECT))
sig(user32.GetClassNameW, I, wt.HWND, wt.LPWSTR, I)
sig(user32.SetForegroundWindow, wt.BOOL, wt.HWND)
sig(user32.CreatePopupMenu, H)
sig(user32.AppendMenuW, wt.BOOL, H, wt.UINT, ctypes.c_size_t, wt.LPCWSTR)
sig(user32.TrackPopupMenu, I, H, wt.UINT, I, I, I, wt.HWND, VP)
sig(user32.DestroyMenu, wt.BOOL, H)
sig(user32.PostMessageW, wt.BOOL, wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)
sig(user32.OpenClipboard, wt.BOOL, wt.HWND)
sig(user32.CloseClipboard, wt.BOOL)
sig(user32.GetClipboardData, H, wt.UINT)
sig(user32.GetClipboardSequenceNumber, wt.DWORD)
sig(user32.RegisterClipboardFormatW, wt.UINT, wt.LPCWSTR)
sig(user32.IsClipboardFormatAvailable, wt.BOOL, wt.UINT)
sig(user32.LoadCursorW, H, H, VP)
sig(user32.keybd_event, None, ctypes.c_ubyte, ctypes.c_ubyte, wt.DWORD, ctypes.c_size_t)
try:
    sig(user32.GetDpiForSystem, wt.UINT)
except AttributeError:
    pass
sig(gdi32.CreateCompatibleDC, H, H)
sig(gdi32.CreateDIBSection, H, H, VP, wt.UINT, ctypes.POINTER(VP), H, wt.DWORD)
sig(gdi32.SelectObject, H, H, H)
sig(gdi32.DeleteObject, wt.BOOL, H)
sig(gdi32.DeleteDC, wt.BOOL, H)

# менеджеры паролей помечают скопированные пароли этим флагом - такое не показываем
CF_PRIVATE = user32.RegisterClipboardFormatW("ExcludeClipboardContentFromMonitorProcessing")

GP = ctypes.POINTER(VP)
for _name, _args in {
    "GdiplusStartup": [ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(GdiplusStartupInput), VP],
    "GdipCreateBitmapFromScan0": [I, I, I, I, VP, GP],
    "GdipGetImageGraphicsContext": [VP, GP],
    "GdipDeleteGraphics": [VP], "GdipDisposeImage": [VP],
    "GdipSetSmoothingMode": [VP, I], "GdipSetTextRenderingHint": [VP, I], "GdipSetPixelOffsetMode": [VP, I],
    "GdipGraphicsClear": [VP, U32],
    "GdipCreateSolidFill": [U32, GP], "GdipSetSolidFillColor": [VP, U32],
    "GdipCreatePen1": [U32, F, I, GP], "GdipSetPenColor": [VP, U32], "GdipSetPenWidth": [VP, F],
    "GdipSetPenStartCap": [VP, I], "GdipSetPenEndCap": [VP, I],
    "GdipCreatePath": [I, GP], "GdipResetPath": [VP], "GdipAddPathArc": [VP, F, F, F, F, F, F],
    "GdipClosePathFigure": [VP], "GdipFillPath": [VP, VP, VP], "GdipDrawPath": [VP, VP, VP],
    "GdipSetClipPath": [VP, VP, I], "GdipSetClipRect": [VP, F, F, F, F, I], "GdipResetClip": [VP],
    "GdipFillEllipse": [VP, VP, F, F, F, F], "GdipFillRectangle": [VP, VP, F, F, F, F],
    "GdipDrawLine": [VP, VP, F, F, F, F], "GdipDrawArc": [VP, VP, F, F, F, F, F, F],
    "GdipDrawEllipse": [VP, VP, F, F, F, F], "GdipFillPolygon": [VP, VP, ctypes.POINTER(PointF), I, I],
    "GdipCreateFontFamilyFromName": [wt.LPCWSTR, VP, GP], "GdipCreateFont": [VP, F, I, I, GP],
    "GdipCreateStringFormat": [I, I, GP], "GdipSetStringFormatAlign": [VP, I],
    "GdipSetStringFormatLineAlign": [VP, I], "GdipSetStringFormatTrimming": [VP, I],
    "GdipDrawString": [VP, wt.LPCWSTR, I, VP, ctypes.POINTER(RectF), VP, VP],
    "GdipMeasureString": [VP, wt.LPCWSTR, I, VP, ctypes.POINTER(RectF), VP, ctypes.POINTER(RectF),
                          ctypes.POINTER(I), ctypes.POINTER(I)],
    "GdipCreateBitmapFromFile": [wt.LPCWSTR, GP],
    "GdipGetImageWidth": [VP, ctypes.POINTER(wt.UINT)], "GdipGetImageHeight": [VP, ctypes.POINTER(wt.UINT)],
    "GdipDrawImageRect": [VP, VP, F, F, F, F],
    "GdipDrawImageRectRect": [VP, VP, F, F, F, F, F, F, F, F, I, VP, VP, VP],
    "GdipSetInterpolationMode": [VP, I],
    "GdipBitmapGetPixel": [VP, I, I, ctypes.POINTER(U32)],
    "GdipCreateLineBrushFromRect": [ctypes.POINTER(RectF), U32, U32, I, I, GP],
    "GdipDeleteBrush": [VP],
    "GdipCreatePen2": [VP, F, I, GP], "GdipDeletePen": [VP],
}.items():
    sig(getattr(gdiplus, _name), I, *_args)

_token = ctypes.c_size_t()
gdiplus.GdiplusStartup(ctypes.byref(_token), ctypes.byref(GdiplusStartupInput(1, None, False, False)), None)


def cursor_pos():
    p = wt.POINT()
    user32.GetCursorPos(ctypes.byref(p))
    return p.x, p.y


def press_key(vk):
    user32.keybd_event(vk, 0, 0, 0)
    user32.keybd_event(vk, 0, 2, 0)


sig(user32.EmptyClipboard, wt.BOOL)
sig(user32.SetClipboardData, H, wt.UINT, H)
sig(kernel32.GlobalAlloc, H, wt.UINT, ctypes.c_size_t)
sig(user32.LockWorkStation, wt.BOOL)


def set_clipboard_text(hwnd, text):
    """Кладёт текст в буфер обмена."""
    data = (text + "\0").encode("utf-16-le")
    if not user32.OpenClipboard(hwnd):
        return False
    try:
        user32.EmptyClipboard()
        h = kernel32.GlobalAlloc(0x0002, len(data))   # GMEM_MOVEABLE
        if not h:
            return False
        p = kernel32.GlobalLock(h)
        ctypes.memmove(p, data, len(data))
        kernel32.GlobalUnlock(h)
        return bool(user32.SetClipboardData(13, h))    # CF_UNICODETEXT
    finally:
        user32.CloseClipboard()


def load_json(path, default):
    try:
        with open(path, encoding="utf-8-sig") as f:
            return json.load(f)
    except Exception:
        return default


_save_lock = threading.Lock()


def save_json(path, data):
    with _save_lock:   # сохранять могут сразу несколько потоков
        try:
            os.makedirs(os.path.dirname(path), exist_ok=True)
            tmp = f"{path}.{threading.get_ident()}.tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=1)
            for _ in range(5):
                try:
                    os.replace(tmp, path)
                    break
                except PermissionError:   # файл занят (антивирус, облако) - чуть подождём
                    time.sleep(0.05)
        except Exception:
            traceback.print_exc()


def http_json(url, timeout=8):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


# ───────────────────────── рисование (GDI+) ─────────────────────────
class Canvas:
    """Холст с прозрачностью: сглаженные фигуры и текст."""

    def __init__(self, w, h, scale):
        self.w, self.h, self.s = w, h, scale
        screen = user32.GetDC(None)
        self.dc = gdi32.CreateCompatibleDC(screen)
        user32.ReleaseDC(None, screen)
        bmi = BITMAPINFOHEADER(ctypes.sizeof(BITMAPINFOHEADER), w, -h, 1, 32, 0, 0, 0, 0, 0, 0)
        self.bits = VP()
        self.hbmp = gdi32.CreateDIBSection(self.dc, ctypes.byref(bmi), 0, ctypes.byref(self.bits), None, 0)
        gdi32.SelectObject(self.dc, self.hbmp)
        self.bmp, self.g = VP(), VP()
        gdiplus.GdipCreateBitmapFromScan0(w, h, w * 4, 0x000E200B, self.bits, ctypes.byref(self.bmp))  # PARGB
        gdiplus.GdipGetImageGraphicsContext(self.bmp, ctypes.byref(self.g))
        gdiplus.GdipSetSmoothingMode(self.g, 4)
        gdiplus.GdipSetTextRenderingHint(self.g, 4)
        gdiplus.GdipSetPixelOffsetMode(self.g, 4)
        self.brush, self.pen, self.path = VP(), VP(), VP()
        gdiplus.GdipCreateSolidFill(0xFFFFFFFF, ctypes.byref(self.brush))
        gdiplus.GdipCreatePen1(0xFFFFFFFF, 1.0, 2, ctypes.byref(self.pen))
        gdiplus.GdipSetPenStartCap(self.pen, 2)
        gdiplus.GdipSetPenEndCap(self.pen, 2)
        gdiplus.GdipCreatePath(0, ctypes.byref(self.path))
        self.families, self.fonts, self.formats = {}, {}, {}

    def close(self):
        gdiplus.GdipDeleteGraphics(self.g)
        gdiplus.GdipDisposeImage(self.bmp)
        gdi32.DeleteDC(self.dc)
        gdi32.DeleteObject(self.hbmp)

    def font(self, size, bold=False, family="Segoe UI"):
        key = (size, bold, family)
        f = self.fonts.get(key)
        if f is None:
            fam = self.families.get(family)
            if fam is None:
                fam = VP()
                gdiplus.GdipCreateFontFamilyFromName(family, None, ctypes.byref(fam))
                self.families[family] = fam
            f = VP()
            gdiplus.GdipCreateFont(fam, F(size * self.s), 1 if bold else 0, 2, ctypes.byref(f))
            self.fonts[key] = f
        return f

    def fmt(self, align=0, valign=1, ellipsis=True):
        key = (align, valign, ellipsis)
        f = self.formats.get(key)
        if f is None:
            f = VP()
            gdiplus.GdipCreateStringFormat(0x1000, 0, ctypes.byref(f))   # одна строка
            gdiplus.GdipSetStringFormatAlign(f, align)
            gdiplus.GdipSetStringFormatLineAlign(f, valign)
            gdiplus.GdipSetStringFormatTrimming(f, 3 if ellipsis else 0)
            self.formats[key] = f
        return f

    def clear(self):
        gdiplus.GdipGraphicsClear(self.g, 0)

    def _rrect_path(self, x, y, w, h, r):
        r = max(0.5, min(r, w / 2, h / 2))
        p = self.path
        gdiplus.GdipResetPath(p)
        d = r * 2
        gdiplus.GdipAddPathArc(p, x, y, d, d, 180, 90)
        gdiplus.GdipAddPathArc(p, x + w - d, y, d, d, 270, 90)
        gdiplus.GdipAddPathArc(p, x + w - d, y + h - d, d, d, 0, 90)
        gdiplus.GdipAddPathArc(p, x, y + h - d, d, d, 90, 90)
        gdiplus.GdipClosePathFigure(p)
        return p

    def rrect(self, x, y, w, h, r, color):
        if w <= 0 or h <= 0:
            return
        gdiplus.GdipSetSolidFillColor(self.brush, color)
        gdiplus.GdipFillPath(self.g, self.brush, self._rrect_path(x, y, w, h, r))

    def rrect_outline(self, x, y, w, h, r, color, width):
        gdiplus.GdipSetPenColor(self.pen, color)
        gdiplus.GdipSetPenWidth(self.pen, width)
        gdiplus.GdipDrawPath(self.g, self.pen, self._rrect_path(x, y, w, h, r))

    def clip_rrect(self, x, y, w, h, r):
        gdiplus.GdipSetClipPath(self.g, self._rrect_path(x, y, w, h, r), 0)

    def clip_rrect_intersect(self, x, y, w, h, r):
        gdiplus.GdipSetClipPath(self.g, self._rrect_path(x, y, w, h, r), 1)

    def image(self, img, x, y, w, h):
        gdiplus.GdipSetInterpolationMode(self.g, 7)   # плавное масштабирование
        gdiplus.GdipDrawImageRect(self.g, img, x, y, w, h)

    def gradient_rrect(self, x, y, w, h, r, c1, c2, shift=0.0):
        """Скруглённый прямоугольник с плавным переходом цвета (shift двигает градиент)."""
        b = VP()
        rc = RectF(x + shift, y, max(1.0, w * 0.8), max(1.0, h))
        gdiplus.GdipCreateLineBrushFromRect(ctypes.byref(rc), c1, c2, 2, 3, ctypes.byref(b))   # диагональ, отражение
        gdiplus.GdipFillPath(self.g, b, self._rrect_path(x, y, w, h, r))
        gdiplus.GdipDeleteBrush(b)

    def gradient_rect(self, x, y, w, h, c1, c2, vertical=True):
        """Обычный прямоугольник с переходом цвета (для бликов и карточек)."""
        if w <= 0 or h <= 0:
            return
        b = VP()
        rc = RectF(x, y - 1, w, h + 2)
        gdiplus.GdipCreateLineBrushFromRect(ctypes.byref(rc), c1, c2, 1 if vertical else 0, 3, ctypes.byref(b))
        gdiplus.GdipFillRectangle(self.g, b, x, y, w, h)
        gdiplus.GdipDeleteBrush(b)

    def gradient_outline(self, x, y, w, h, r, c1, c2, width, shift=0.0):
        """Рамка с переливом цвета (RGB-рамка)."""
        b, pen = VP(), VP()
        rc = RectF(x + shift, y, max(1.0, w * 0.6), max(1.0, h))
        gdiplus.GdipCreateLineBrushFromRect(ctypes.byref(rc), c1, c2, 0, 3, ctypes.byref(b))
        gdiplus.GdipCreatePen2(b, width, 2, ctypes.byref(pen))
        gdiplus.GdipDrawPath(self.g, pen, self._rrect_path(x, y, w, h, r))
        gdiplus.GdipDeletePen(pen)
        gdiplus.GdipDeleteBrush(b)

    def clip_rect(self, x, y, w, h):
        gdiplus.GdipSetClipRect(self.g, x, y, max(0.0, w), max(0.0, h), 1)   # пересечение с текущим

    def reset_clip(self):
        gdiplus.GdipResetClip(self.g)

    def circle(self, cx, cy, r, color):
        gdiplus.GdipSetSolidFillColor(self.brush, color)
        gdiplus.GdipFillEllipse(self.g, self.brush, cx - r, cy - r, r * 2, r * 2)

    def ring(self, cx, cy, r, color, width):
        gdiplus.GdipSetPenColor(self.pen, color)
        gdiplus.GdipSetPenWidth(self.pen, width)
        gdiplus.GdipDrawEllipse(self.g, self.pen, cx - r, cy - r, r * 2, r * 2)

    def rect(self, x, y, w, h, color):
        gdiplus.GdipSetSolidFillColor(self.brush, color)
        gdiplus.GdipFillRectangle(self.g, self.brush, x, y, w, h)

    def line(self, x1, y1, x2, y2, color, width):
        gdiplus.GdipSetPenColor(self.pen, color)
        gdiplus.GdipSetPenWidth(self.pen, width)
        gdiplus.GdipDrawLine(self.g, self.pen, x1, y1, x2, y2)

    def arc(self, cx, cy, r, start, sweep, color, width):
        if abs(sweep) < 0.5:
            return
        gdiplus.GdipSetPenColor(self.pen, color)
        gdiplus.GdipSetPenWidth(self.pen, width)
        gdiplus.GdipDrawArc(self.g, self.pen, cx - r, cy - r, r * 2, r * 2, start, sweep)

    def polygon(self, pts, color):
        gdiplus.GdipSetSolidFillColor(self.brush, color)
        arr = (PointF * len(pts))(*[PointF(x, y) for x, y in pts])
        gdiplus.GdipFillPolygon(self.g, self.brush, arr, len(pts), 0)

    def text(self, s, x, y, w, h, font, color, align=0, valign=1):
        if not s or w <= 0:
            return
        gdiplus.GdipSetSolidFillColor(self.brush, color)
        rc = RectF(x, y, w, h)
        gdiplus.GdipDrawString(self.g, s, len(s), font, ctypes.byref(rc), self.fmt(align, valign), self.brush)

    def measure(self, s, font):
        if not s:
            return 0.0
        box = RectF()
        layout = RectF(0, 0, 10000, 1000)
        gdiplus.GdipMeasureString(self.g, s, len(s), font, ctypes.byref(layout), self.fmt(0, 0, False),
                                  ctypes.byref(box), None, None)
        return box.Width


class Cover:
    """Обложка песни: маленькая копия для показа, крошечная для размытого фона и два главных цвета."""

    def __init__(self, path):
        src = VP()
        if gdiplus.GdipCreateBitmapFromFile(path, ctypes.byref(src)) != 0 or not src:
            raise OSError("не удалось открыть обложку")
        try:
            w, h = wt.UINT(), wt.UINT()
            gdiplus.GdipGetImageWidth(src, ctypes.byref(w))
            gdiplus.GdipGetImageHeight(src, ctypes.byref(h))
            side = min(w.value, h.value)      # берём квадрат из середины (у видео обложка широкая)
            sx, sy = (w.value - side) / 2, (h.value - side) / 2
            self.thumb = self._scaled(src, 96, sx, sy, side)
            self.small = self._scaled(src, 6, sx, sy, side)
        finally:
            gdiplus.GdipDisposeImage(src)      # файл больше не занят
        px = U32()
        left, right = [0, 0, 0], [0, 0, 0]
        for yy in range(6):
            for xx in range(6):
                gdiplus.GdipBitmapGetPixel(self.small, xx, yy, ctypes.byref(px))
                v = px.value
                rgb_ = ((v >> 16) & 255, (v >> 8) & 255, v & 255)
                acc = left if xx < 3 else right
                for i in range(3):
                    acc[i] += rgb_[i]
        self.c1 = self._vivid([v / 18 for v in left])
        self.c2 = self._vivid([v / 18 for v in right])

    @staticmethod
    def _scaled(src, size, sx, sy, side):
        bmp, g = VP(), VP()
        gdiplus.GdipCreateBitmapFromScan0(size, size, 0, 0x26200A, None, ctypes.byref(bmp))   # 32bppARGB
        gdiplus.GdipGetImageGraphicsContext(bmp, ctypes.byref(g))
        gdiplus.GdipSetInterpolationMode(g, 7)
        gdiplus.GdipDrawImageRectRect(g, src, 0, 0, size, size, sx, sy, side, side, 2, None, None, None)
        gdiplus.GdipDeleteGraphics(g)
        return bmp

    @staticmethod
    def _vivid(c):
        """Делает цвет поярче, чтобы градиент не был серым."""
        r, g, b = c
        mx = max(r, g, b, 1)
        k = 210 / mx
        return argb(255, min(255, r * k), min(255, g * k), min(255, b * k))

    def close(self):
        gdiplus.GdipDisposeImage(self.thumb)
        gdiplus.GdipDisposeImage(self.small)


# ───────────────────────── музыка ─────────────────────────
class MediaWatcher:
    """Запускает невидимый PowerShell, который сообщает, что сейчас играет."""

    def __init__(self, app_dir):
        self.state = {"status": "None"}
        self.cmd_file = os.path.join(app_dir, "media_cmd.txt")
        self.app_dir = app_dir
        self.proc = None
        self.alive = True
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        script = open(os.path.join(HERE, "media.ps1"), encoding="utf-8-sig").read()
        covers = os.path.join(self.app_dir, "covers")
        cmd = "$ProgressPreference='SilentlyContinue'\n& {\n" + script + "\n} -CommandFile '" + \
              self.cmd_file.replace("'", "''") + f"' -ParentPid {os.getpid()} -CoverDir '" + \
              covers.replace("'", "''") + "'"
        enc = base64.b64encode(cmd.encode("utf-16-le")).decode("ascii")
        while self.alive:
            try:
                self.proc = subprocess.Popen(
                    ["powershell", "-NoProfile", "-NonInteractive", "-EncodedCommand", enc],
                    stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
                    creationflags=0x08000000)
                for raw in self.proc.stdout:
                    if not self.alive:
                        break
                    line = raw.decode("utf-8", "replace").strip()
                    if line.startswith("{"):
                        try:
                            self.state = json.loads(line)
                        except ValueError:
                            pass
            except Exception:
                traceback.print_exc()
            if self.alive:
                time.sleep(5)

    def position(self):
        s = self.state
        pos, dur = s.get("pos") or 0, s.get("dur") or 0
        if s.get("status") == "Playing" and s.get("upd"):
            pos += max(0.0, time.time() - s["upd"] / 1000)
        return min(pos, dur) if dur else pos

    def command(self, what):
        try:
            os.makedirs(self.app_dir, exist_ok=True)
            with open(self.cmd_file, "w") as f:
                f.write(what)
        except OSError:
            pass

    def stop(self):
        self.alive = False
        if self.proc:
            try:
                self.proc.kill()
            except Exception:
                pass


class NotifWatcher:
    """Запускает невидимый PowerShell (notif.ps1): уведомления Windows, звонки, микрофон."""

    def __init__(self, app_dir):
        import collections
        self.events = collections.deque(maxlen=200)
        self.cmd_file = os.path.join(app_dir, "notif_cmd.txt")
        self.app_dir = app_dir
        self.access = None
        self.proc = None
        self.alive = True
        threading.Thread(target=self._run, daemon=True).start()

    def _run(self):
        script = open(os.path.join(HERE, "notif.ps1"), encoding="utf-8-sig").read()
        cmd = "$ProgressPreference='SilentlyContinue'\n& {\n" + script + "\n} -CommandFile '" + \
              self.cmd_file.replace("'", "''") + f"' -ParentPid {os.getpid()}"
        enc = base64.b64encode(cmd.encode("utf-16-le")).decode("ascii")
        while self.alive:
            try:
                self.proc = subprocess.Popen(
                    ["powershell", "-NoProfile", "-NonInteractive", "-EncodedCommand", enc],
                    stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
                    creationflags=0x08000000)
                for raw in self.proc.stdout:
                    if not self.alive:
                        break
                    line = raw.decode("utf-8", "replace").strip()
                    if line.startswith("{"):
                        try:
                            ev = json.loads(line)
                        except ValueError:
                            continue
                        if ev.get("type") == "access":
                            self.access = ev.get("status")
                        else:
                            self.events.append(ev)
            except Exception:
                traceback.print_exc()
            if self.alive:
                time.sleep(5)

    def command(self, what):
        try:
            os.makedirs(self.app_dir, exist_ok=True)
            with open(self.cmd_file, "w", encoding="utf-8") as f:
                f.write(what)
        except OSError:
            pass

    def stop(self):
        self.alive = False
        if self.proc:
            try:
                self.proc.kill()
            except Exception:
                pass


JUNK = re.compile(r"\s*[\(\[][^\)\]]*(official|video|audio|lyric|клип|премьера|visualizer|mood|hd|4k|remaster)[^\)\]]*[\)\]]", re.I)


def clean(s):
    s = JUNK.sub("", s or "")
    s = re.sub(r"\s*(- Topic|VEVO)$", "", s, flags=re.I)
    return s.strip(" -–—|")


def parse_lrc(text):
    lines = []
    for row in (text or "").splitlines():
        stamps = re.findall(r"\[(\d+):(\d+(?:\.\d+)?)\]", row)
        words = re.sub(r"\[[^\]]*\]", "", row).strip()
        for m, s in stamps:
            lines.append((int(m) * 60 + float(s), words))
    return sorted(lines)


LYRICS_FOUND, LYRICS_NONE, LYRICS_ERROR = "found", "none", "error"


def fetch_lyrics(lyrics_dir, artist, title, duration):
    """Синхронизированный текст песни с lrclib.net.
    Возвращает (строчки, состояние): found - нашли, none - сервис ответил, но текста нет,
    error - сервис не ответил (нет интернета, или он не открывается без VPN). Ошибку не запоминаем."""
    os.makedirs(lyrics_dir, exist_ok=True)
    key = hashlib.md5(f"{artist}|{title}".lower().encode("utf-8")).hexdigest()
    cache = os.path.join(lyrics_dir, key + ".json")
    cached = load_json(cache, None)
    if cached:
        return [tuple(x) for x in cached], LYRICS_FOUND
    if cached == [] and time.time() - os.path.getmtime(cache) < 3 * 86400:
        return [], LYRICS_NONE      # «текста нет» помним 3 дня, потом проверим снова

    queries = []
    if " - " in title:               # YouTube: «Исполнитель - Песня» в названии
        a, t = title.split(" - ", 1)
        queries.append({"track_name": clean(t), "artist_name": clean(a)})
    queries.append({"track_name": clean(title), "artist_name": clean(artist)})
    queries.append({"q": f"{clean(artist)} {clean(title)}".strip()})   # поиск «как в строке поиска»
    answered = False
    for q in queries:
        q = {k: v for k, v in q.items() if v}
        if not q.get("track_name") and not q.get("q"):
            continue
        try:
            results = http_json("https://lrclib.net/api/search?" + urllib.parse.urlencode(q), timeout=10)
        except Exception:
            continue
        answered = True
        good = [r for r in results if r.get("syncedLyrics")]
        if duration:
            good = [r for r in good if abs((r.get("duration") or 0) - duration) < 15] or good
            good.sort(key=lambda r: abs((r.get("duration") or 0) - duration))
        if good:
            found = parse_lrc(good[0]["syncedLyrics"])
            save_json(cache, found)
            return found, LYRICS_FOUND
    if not answered:
        return [], LYRICS_ERROR
    save_json(cache, [])
    return [], LYRICS_NONE


# ───────────────────────── какая программа сейчас открыта ─────────────────────────
class LASTINPUTINFO(ctypes.Structure):
    _fields_ = [("cbSize", wt.UINT), ("dwTime", wt.DWORD)]


version = ctypes.WinDLL("version")
sig(kernel32.OpenProcess, H, wt.DWORD, wt.BOOL, wt.DWORD)
sig(kernel32.CloseHandle, wt.BOOL, H)
sig(kernel32.QueryFullProcessImageNameW, wt.BOOL, H, wt.DWORD, wt.LPWSTR, ctypes.POINTER(wt.DWORD))
sig(kernel32.GetTickCount, wt.DWORD)
sig(user32.GetLastInputInfo, wt.BOOL, ctypes.POINTER(LASTINPUTINFO))
sig(version.GetFileVersionInfoSizeW, wt.DWORD, wt.LPCWSTR, VP)
sig(version.GetFileVersionInfoW, wt.BOOL, wt.LPCWSTR, wt.DWORD, wt.DWORD, VP)
sig(version.VerQueryValueW, wt.BOOL, VP, wt.LPCWSTR, ctypes.POINTER(VP), ctypes.POINTER(wt.UINT))

KNOWN_APPS = {
    "code.exe": "Visual Studio Code", "chrome.exe": "Google Chrome", "msedge.exe": "Microsoft Edge",
    "firefox.exe": "Firefox", "browser.exe": "Яндекс Браузер", "opera.exe": "Opera", "discord.exe": "Discord",
    "telegram.exe": "Telegram", "robloxplayerbeta.exe": "Roblox", "steam.exe": "Steam", "explorer.exe": "Проводник",
    "spotify.exe": "Spotify", "minecraft.exe": "Minecraft", "javaw.exe": "Minecraft", "claude.exe": "Claude",
    "windowsterminal.exe": "Терминал", "powershell.exe": "PowerShell", "notepad.exe": "Блокнот",
    "winword.exe": "Word", "excel.exe": "Excel", "powerpnt.exe": "PowerPoint", "faceit.exe": "FACEIT",
    "epicgameslauncher.exe": "Epic Games", "yandexmusic.exe": "Яндекс Музыка", "chatgpt.exe": "ChatGPT",
}
_app_names = {}


def _file_description(path):
    try:
        size = version.GetFileVersionInfoSizeW(path, None)
        if not size:
            return None
        buf = ctypes.create_string_buffer(size)
        if not version.GetFileVersionInfoW(path, 0, size, buf):
            return None
        ptr, ln = VP(), wt.UINT()
        if not version.VerQueryValueW(buf, "\\VarFileInfo\\Translation", ctypes.byref(ptr), ctypes.byref(ln)) or ln.value < 4:
            return None
        lang, cp = ctypes.cast(ptr, ctypes.POINTER(ctypes.c_ushort * 2)).contents
        key = f"\\StringFileInfo\\{lang:04x}{cp:04x}\\FileDescription"
        if version.VerQueryValueW(buf, key, ctypes.byref(ptr), ctypes.byref(ln)) and ln.value > 1:
            return ctypes.wstring_at(ptr.value, ln.value - 1).strip() or None
    except Exception:
        pass
    return None


sig(user32.GetWindowTextW, I, wt.HWND, wt.LPWSTR, I)

GAME_EXES = {
    "robloxplayerbeta.exe": "Roblox", "minecraft.windows.exe": "Minecraft", "cs2.exe": "Counter-Strike 2",
    "dota2.exe": "Dota 2", "gta5.exe": "GTA V", "gta5_enhanced.exe": "GTA V", "valorant-win64-shipping.exe": "Valorant",
    "fortniteclient-win64-shipping.exe": "Fortnite", "r5apex.exe": "Apex Legends", "overwatch.exe": "Overwatch 2",
    "genshinimpact.exe": "Genshin Impact", "terraria.exe": "Terraria", "brawlhalla.exe": "Brawlhalla",
    "rocketleague.exe": "Rocket League", "among us.exe": "Among Us", "worldoftanks.exe": "World of Tanks",
    "rustclient.exe": "Rust", "tslgame.exe": "PUBG", "eldenring.exe": "Elden Ring", "hollow_knight.exe": "Hollow Knight",
    "stardew valley.exe": "Stardew Valley", "geometrydash.exe": "Geometry Dash", "osu!.exe": "osu!",
    "deadbydaylight-win64-shipping.exe": "Dead by Daylight", "rainbowsix.exe": "Rainbow Six Siege",
    "fallguys_client_game.exe": "Fall Guys", "warthunder.exe": "War Thunder", "aces.exe": "War Thunder",
}
LAUNCHERS = {"steam.exe", "steamwebhelper.exe", "epicgameslauncher.exe", "riotclientservices.exe",
             "riotclientux.exe", "robloxplayerlauncher.exe", "faceit.exe", "unitycrashhandler64.exe"}


def foreground_game():
    """Название игры на переднем плане или None."""
    hwnd = user32.GetForegroundWindow()
    info = _process_of(hwnd)
    if not info:
        return None
    name, exe, path = info
    if exe in GAME_EXES:
        return GAME_EXES[exe]
    if exe in ("javaw.exe", "java.exe"):
        buf = ctypes.create_unicode_buffer(256)
        user32.GetWindowTextW(hwnd, buf, 256)
        return "Minecraft" if "minecraft" in buf.value.lower() else None
    low = path.lower()
    if exe not in LAUNCHERS and ("\\steamapps\\common\\" in low or "\\epic games\\" in low or "\\riot games\\" in low):
        return name
    return None


def _process_of(hwnd):
    """(название, exe, путь) процесса окна или None."""
    if not hwnd:
        return None
    pid = wt.DWORD()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    if not pid.value or pid.value == os.getpid():
        return None
    h = kernel32.OpenProcess(0x1000, False, pid.value)
    if not h:
        return None
    try:
        buf = ctypes.create_unicode_buffer(1024)
        size = wt.DWORD(1024)
        if not kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
            return None
        path = buf.value
    finally:
        kernel32.CloseHandle(h)
    exe = os.path.basename(path).lower()
    if exe not in _app_names:
        _app_names[exe] = KNOWN_APPS.get(exe) or _file_description(path) or os.path.splitext(os.path.basename(path))[0]
    return _app_names[exe], exe, path


# ───────────────────────── пинг (для игр) ─────────────────────────
iphlpapi = ctypes.WinDLL("iphlpapi")
sig(iphlpapi.IcmpCreateFile, H)
sig(iphlpapi.IcmpSendEcho, wt.DWORD, H, ctypes.c_uint32, VP, wt.WORD, VP, VP, wt.DWORD, wt.DWORD)
sig(iphlpapi.IcmpCloseHandle, wt.BOOL, H)


def ping_ms(ip=0x01010101, timeout=1000):
    """Пинг до 1.1.1.1 в миллисекундах или None, если ответа нет."""
    h = iphlpapi.IcmpCreateFile()
    if not h or h == ctypes.c_void_p(-1).value:
        return None
    try:
        data = ctypes.create_string_buffer(b"island!", 8)
        reply = ctypes.create_string_buffer(128)
        if iphlpapi.IcmpSendEcho(h, ip, data, 8, None, reply, 128, timeout):
            status, rtt = struct.unpack_from("<II", reply.raw, 4)
            return rtt if status == 0 else None
        return None
    finally:
        iphlpapi.IcmpCloseHandle(h)


def foreground_app():
    """Название программы, которая сейчас на переднем плане (или None)."""
    info = _process_of(user32.GetForegroundWindow())
    return info[0] if info else None


def idle_seconds():
    """Сколько секунд не трогали мышь и клавиатуру."""
    li = LASTINPUTINFO(ctypes.sizeof(LASTINPUTINFO), 0)
    if not user32.GetLastInputInfo(ctypes.byref(li)):
        return 0.0
    return ((kernel32.GetTickCount() - li.dwTime) & 0xFFFFFFFF) / 1000.0


# ───────────────────────── звук Windows: уровень и громкость ─────────────────────────
class _GUID(ctypes.Structure):
    _fields_ = [("a", wt.DWORD), ("b", wt.WORD), ("c", wt.WORD), ("d", ctypes.c_ubyte * 8)]


ole32 = ctypes.WinDLL("ole32")
sig(ole32.CoInitializeEx, ctypes.c_long, VP, wt.DWORD)
sig(ole32.CLSIDFromString, ctypes.c_long, wt.LPCWSTR, ctypes.POINTER(_GUID))
sig(ole32.CoCreateInstance, ctypes.c_long, ctypes.POINTER(_GUID), VP, wt.DWORD, ctypes.POINTER(_GUID), ctypes.POINTER(VP))


def _guid(text):
    g = _GUID()
    ole32.CLSIDFromString(text, ctypes.byref(g))
    return g


def _com(ptr, index, *argtypes):
    """Функция номер `index` из COM-объекта (без дополнительных библиотек)."""
    vtbl = ctypes.cast(ptr, ctypes.POINTER(VP))[0]
    addr = ctypes.cast(vtbl, ctypes.POINTER(VP))[index]
    return ctypes.WINFUNCTYPE(ctypes.c_long, VP, *argtypes)(addr)


class Audio:
    """Слышит, насколько громко сейчас играет звук, и умеет менять громкость Windows."""

    def __init__(self):
        ole32.CoInitializeEx(None, 0x2)
        self.meter = self.vol = None
        self.made = 0.0
        self.connect()

    def connect(self):
        self.made = time.time()
        self.meter = self.vol = None
        self.mic = None
        self._connect_mic()
        enum, dev = VP(), VP()
        clsid = _guid("{BCDE0395-E52F-467C-8E3D-C4579291692E}")
        iid = _guid("{A95664D2-9614-4F35-A746-DE8DB63617E6}")
        if ole32.CoCreateInstance(ctypes.byref(clsid), None, 23, ctypes.byref(iid), ctypes.byref(enum)) != 0:
            return
        try:
            if _com(enum, 4, I, I, ctypes.POINTER(VP))(enum, 0, 1, ctypes.byref(dev)) != 0:   # колонки/наушники
                return
            activate = _com(dev, 3, ctypes.POINTER(_GUID), wt.DWORD, VP, ctypes.POINTER(VP))
            meter, vol = VP(), VP()
            if activate(dev, ctypes.byref(_guid("{C02216F6-8C67-4B5B-9D00-D008E73E0064}")), 23, None, ctypes.byref(meter)) == 0:
                self.meter = meter
                self._peak = _com(meter, 3, ctypes.POINTER(F))
            if activate(dev, ctypes.byref(_guid("{5CDF2C82-841E-4546-9722-0CF74078229A}")), 23, None, ctypes.byref(vol)) == 0:
                self.vol = vol
                self._get_vol = _com(vol, 9, ctypes.POINTER(F))
                self._set_vol = _com(vol, 7, F, VP)
                self._get_mute = _com(vol, 15, ctypes.POINTER(wt.BOOL))
                self._set_mute = _com(vol, 14, wt.BOOL, VP)
            _com(dev, 2)(dev)        # Release
        finally:
            _com(enum, 2)(enum)

    def _connect_mic(self):
        """Микрофон для звонков: можно выключить/включить его одной кнопкой."""
        enum, dev = VP(), VP()
        clsid = _guid("{BCDE0395-E52F-467C-8E3D-C4579291692E}")
        iid = _guid("{A95664D2-9614-4F35-A746-DE8DB63617E6}")
        if ole32.CoCreateInstance(ctypes.byref(clsid), None, 23, ctypes.byref(iid), ctypes.byref(enum)) != 0:
            return
        try:
            if _com(enum, 4, I, I, ctypes.POINTER(VP))(enum, 1, 2, ctypes.byref(dev)) != 0:   # запись, для звонков
                return
            mic = VP()
            activate = _com(dev, 3, ctypes.POINTER(_GUID), wt.DWORD, VP, ctypes.POINTER(VP))
            if activate(dev, ctypes.byref(_guid("{5CDF2C82-841E-4546-9722-0CF74078229A}")), 23, None, ctypes.byref(mic)) == 0:
                self.mic = mic
                self._mic_get_mute = _com(mic, 15, ctypes.POINTER(wt.BOOL))
                self._mic_set_mute = _com(mic, 14, wt.BOOL, VP)
            _com(dev, 2)(dev)
        finally:
            _com(enum, 2)(enum)

    def mic_muted(self):
        if not self.mic:
            return None
        m = wt.BOOL()
        return bool(m.value) if self._mic_get_mute(self.mic, ctypes.byref(m)) == 0 else None

    def set_mic_mute(self, on):
        if self.mic:
            self._mic_set_mute(self.mic, bool(on), None)

    def refresh(self):
        """Раз в 20 секунд подключаемся заново: вдруг включили наушники."""
        if time.time() - self.made > 20:
            old = (self.meter, self.vol, self.mic)
            self.connect()
            for o in old:
                if o:
                    try:
                        _com(o, 2)(o)
                    except Exception:
                        pass

    def peak(self):
        if not self.meter:
            return 0.0
        v = F()
        return v.value if self._peak(self.meter, ctypes.byref(v)) == 0 else 0.0

    def volume(self):
        if not self.vol:
            return None
        v = F()
        return v.value if self._get_vol(self.vol, ctypes.byref(v)) == 0 else None

    def set_volume(self, value):
        if self.vol:
            self._set_vol(self.vol, max(0.0, min(1.0, value)), None)

    def muted(self):
        if not self.vol:
            return False
        m = wt.BOOL()
        return bool(m.value) if self._get_mute(self.vol, ctypes.byref(m)) == 0 else False

    def set_mute(self, on):
        if self.vol:
            self._set_mute(self.vol, bool(on), None)


def weather_kind(code, is_day):
    if code == 0:
        return "sun" if is_day else "moon"
    if code in (1, 2):
        return "partly" if is_day else "cloud"
    if code == 3:
        return "cloud"
    if code in (45, 48):
        return "fog"
    if code in (71, 73, 75, 77, 85, 86):
        return "snow"
    if code >= 95:
        return "storm"
    return "rain"
