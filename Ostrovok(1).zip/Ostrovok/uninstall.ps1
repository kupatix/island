﻿# Удаление «Островка»: закрывает его, убирает ярлыки и автозапуск, удаляет файлы программы.
$dest = Join-Path $env:LOCALAPPDATA "Programs\Ostrovok"
Write-Host ""
Write-Host "  Удаление Островка" -ForegroundColor Cyan
Get-CimInstance Win32_Process -Filter "Name='pythonw.exe' OR Name='python.exe'" |
    Where-Object { $_.CommandLine -like "*Ostrovok*island.py*" } |
    ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
foreach ($dir in @([Environment]::GetFolderPath("Desktop"), [Environment]::GetFolderPath("Startup"))) {
    Remove-Item (Join-Path $dir "Островок.lnk") -ErrorAction SilentlyContinue
}
Start-Sleep -Milliseconds 500
Set-Location $env:TEMP
Remove-Item $dest -Recurse -Force -ErrorAction SilentlyContinue
Write-Host "  Островок удалён. Заметки и настройки остались в %APPDATA%\DesktopIsland" -ForegroundColor Green
Write-Host ""
Read-Host "  Нажми Enter, чтобы закрыть"
