"""Звонки без уведомлений Windows: смотрим на окна мессенджеров и умеем нажать кнопку звонка.

* windows_of(names)  - видимые окна программ (Telegram, Discord ...): заголовок и размер.
* press_call_button  - находит в окне круглую зелёную (принять) или красную (сбросить) кнопку
                       и нажимает её мышкой, потом возвращает курсор на место.
Ничего никуда не отправляется.
"""
import ctypes
import ctypes.wintypes as wt
import os
import struct
import time

user32 = ctypes.WinDLL("user32", use_last_error=True)
gdi32 = ctypes.WinDLL("gdi32")
kernel32 = ctypes.WinDLL("kernel32")

WNDENUMPROC = ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)
user32.EnumWindows.argtypes = [WNDENUMPROC, wt.LPARAM]
user32.IsWindowVisible.argtypes = [wt.HWND]
user32.IsIconic.argtypes = [wt.HWND]
user32.GetWindowTextLengthW.argtypes = [wt.HWND]
user32.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
user32.GetWindowRect.argtypes = [wt.HWND, ctypes.POINTER(wt.RECT)]
user32.GetWindowThreadProcessId.argtypes = [wt.HWND, ctypes.POINTER(wt.DWORD)]
user32.GetWindowLongW.argtypes = [wt.HWND, ctypes.c_int]
user32.GetWindow.restype = wt.HWND
user32.GetWindow.argtypes = [wt.HWND, wt.UINT]
user32.SetForegroundWindow.argtypes = [wt.HWND]
user32.ShowWindow.argtypes = [wt.HWND, ctypes.c_int]
user32.BringWindowToTop.argtypes = [wt.HWND]
user32.GetDC.restype = wt.HDC
user32.GetDC.argtypes = [wt.HWND]
user32.ReleaseDC.argtypes = [wt.HWND, wt.HDC]
user32.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
user32.GetCursorPos.argtypes = [ctypes.POINTER(wt.POINT)]
user32.mouse_event.argtypes = [wt.DWORD, wt.DWORD, wt.DWORD, wt.DWORD, ctypes.c_size_t]
user32.keybd_event.argtypes = [ctypes.c_ubyte, ctypes.c_ubyte, wt.DWORD, ctypes.c_size_t]
gdi32.CreateCompatibleDC.restype = wt.HDC
gdi32.CreateCompatibleDC.argtypes = [wt.HDC]
gdi32.CreateDIBSection.restype = wt.HBITMAP
gdi32.CreateDIBSection.argtypes = [wt.HDC, ctypes.c_void_p, wt.UINT, ctypes.POINTER(ctypes.c_void_p), wt.HANDLE, wt.DWORD]
gdi32.SelectObject.restype = wt.HGDIOBJ
gdi32.SelectObject.argtypes = [wt.HDC, wt.HGDIOBJ]
gdi32.BitBlt.argtypes = [wt.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wt.HDC, ctypes.c_int, ctypes.c_int, wt.DWORD]
gdi32.DeleteObject.argtypes = [wt.HGDIOBJ]
gdi32.DeleteDC.argtypes = [wt.HDC]
kernel32.OpenProcess.restype = wt.HANDLE
kernel32.QueryFullProcessImageNameW.argtypes = [wt.HANDLE, wt.DWORD, wt.LPWSTR, ctypes.POINTER(wt.DWORD)]
kernel32.CloseHandle.argtypes = [wt.HANDLE]

_exe_cache = {}


def _exe_of(pid):
    if pid in _exe_cache:
        return _exe_cache[pid]
    exe = ""
    h = kernel32.OpenProcess(0x1000, False, pid)
    if h:
        buf = ctypes.create_unicode_buffer(1024)
        size = wt.DWORD(1024)
        if kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
            exe = os.path.splitext(os.path.basename(buf.value))[0].lower()
        kernel32.CloseHandle(h)
    if len(_exe_cache) > 500:
        _exe_cache.clear()
    _exe_cache[pid] = exe
    return exe


def windows_of(names, hidden=False):
    """{имя процесса: [(hwnd, заголовок, (x, y, w, h), свёрнуто), ...]} для видимых окон
    (hidden=True - и для спрятанных, например Telegram, убранного в трей)."""
    names = {n.lower() for n in names}
    found = {}

    def cb(hwnd, _):
        if not hidden and not user32.IsWindowVisible(hwnd):
            return True
        pid = wt.DWORD()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        exe = _exe_of(pid.value)
        if exe not in names:
            return True
        n = user32.GetWindowTextLengthW(hwnd)
        buf = ctypes.create_unicode_buffer(n + 1)
        user32.GetWindowTextW(hwnd, buf, n + 1)
        r = wt.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(r))
        found.setdefault(exe, []).append((hwnd, buf.value, (r.left, r.top, r.right - r.left, r.bottom - r.top),
                                          bool(user32.IsIconic(hwnd))))
        return True

    user32.EnumWindows(WNDENUMPROC(cb), 0)
    return found


def bring_to_front(hwnd):
    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, 9)          # SW_RESTORE
    # Windows не даёт просто так вывести чужое окно вперёд - «нажатие» Alt снимает этот запрет
    user32.keybd_event(0x12, 0, 0, 0)
    user32.keybd_event(0x12, 0, 2, 0)
    user32.BringWindowToTop(hwnd)
    user32.SetForegroundWindow(hwnd)


def _grab(x, y, w, h):
    """Снимок участка экрана -> bytes BGRA (сверху вниз)."""
    class BMI(ctypes.Structure):
        _fields_ = [("biSize", wt.DWORD), ("biWidth", ctypes.c_long), ("biHeight", ctypes.c_long),
                    ("biPlanes", wt.WORD), ("biBitCount", wt.WORD), ("biCompression", wt.DWORD),
                    ("biSizeImage", wt.DWORD), ("biXPelsPerMeter", ctypes.c_long), ("biYPelsPerMeter", ctypes.c_long),
                    ("biClrUsed", wt.DWORD), ("biClrImportant", wt.DWORD), ("pad", wt.DWORD * 4)]
    bmi = BMI()
    bmi.biSize = 40
    bmi.biWidth, bmi.biHeight, bmi.biPlanes, bmi.biBitCount = w, -h, 1, 32
    screen = user32.GetDC(None)
    dc = gdi32.CreateCompatibleDC(screen)
    bits = ctypes.c_void_p()
    bmp = gdi32.CreateDIBSection(screen, ctypes.byref(bmi), 0, ctypes.byref(bits), None, 0)
    old = gdi32.SelectObject(dc, bmp)
    gdi32.BitBlt(dc, 0, 0, w, h, screen, x, y, 0x00CC0020 | 0x40000000)
    data = ctypes.string_at(bits, w * h * 4)
    gdi32.SelectObject(dc, old)
    gdi32.DeleteObject(bmp)
    gdi32.DeleteDC(dc)
    user32.ReleaseDC(None, screen)
    return data


user32.PrintWindow.argtypes = [wt.HWND, wt.HDC, wt.UINT]


def capture_window(hwnd):
    """Картинка окна, даже если оно закрыто другими окнами: (bytes BGRA, w, h) или None."""
    r = wt.RECT()
    if not user32.GetWindowRect(hwnd, ctypes.byref(r)):
        return None
    w, h = r.right - r.left, r.bottom - r.top
    if w <= 0 or h <= 0 or w * h > 4000 * 3000:
        return None

    class BMI(ctypes.Structure):
        _fields_ = [("biSize", wt.DWORD), ("biWidth", ctypes.c_long), ("biHeight", ctypes.c_long),
                    ("biPlanes", wt.WORD), ("biBitCount", wt.WORD), ("biCompression", wt.DWORD),
                    ("biSizeImage", wt.DWORD), ("biXPelsPerMeter", ctypes.c_long), ("biYPelsPerMeter", ctypes.c_long),
                    ("biClrUsed", wt.DWORD), ("biClrImportant", wt.DWORD), ("pad", wt.DWORD * 4)]
    bmi = BMI()
    bmi.biSize = 40
    bmi.biWidth, bmi.biHeight, bmi.biPlanes, bmi.biBitCount = w, -h, 1, 32
    screen = user32.GetDC(None)
    dc = gdi32.CreateCompatibleDC(screen)
    bits = ctypes.c_void_p()
    bmp = gdi32.CreateDIBSection(screen, ctypes.byref(bmi), 0, ctypes.byref(bits), None, 0)
    old = gdi32.SelectObject(dc, bmp)
    ok = user32.PrintWindow(hwnd, dc, 2)          # PW_RENDERFULLCONTENT - нужно для окон Telegram (Qt)
    data = ctypes.string_at(bits, w * h * 4) if ok else None
    gdi32.SelectObject(dc, old)
    gdi32.DeleteObject(bmp)
    gdi32.DeleteDC(dc)
    user32.ReleaseDC(None, screen)
    if not data:
        return None
    return data, w, h


def is_blank(data, w, h):
    """Окно не нарисовалось (всё одного цвета) - тогда по картинке судить нельзя."""
    first = data[0:3]
    for i in range(0, len(data), max(4, (len(data) // 4 // 400) * 4)):
        if abs(data[i] - first[0]) + abs(data[i + 1] - first[1]) + abs(data[i + 2] - first[2]) > 30:
            return False
    return True


def find_buttons(x, y, w, h, kind, step=3, data=None):
    """Ищет в прямоугольнике экрана (или в готовой картинке data) круглые зелёные ('accept')
    или красные ('decline') кнопки. Возвращает список (размер, x, y центра)."""
    w, h = max(1, int(w)), max(1, int(h))
    if data is None:
        data = _grab(int(x), int(y), w, h)
    gw, gh = w // step + 1, h // step + 1
    mask = bytearray(gw * gh)
    for gy in range(gh):
        py = gy * step
        if py >= h:
            break
        row = py * w * 4
        for gx in range(gw):
            px = gx * step
            if px >= w:
                break
            i = row + px * 4
            b, g, r = data[i], data[i + 1], data[i + 2]
            if kind == "accept":
                # «Принять»: зелёная (WhatsApp, старый Telegram) или синяя (новый Telegram)
                ok = (g > 130 and g > r + 45 and g > b + 25) or (b > 150 and b > r + 70 and g > r + 35 and b > g + 25)
            elif kind == "colored":     # любая яркая цветная (не красная) кнопка
                mx, mn = max(r, g, b), min(r, g, b)
                ok = mx > 120 and mx - mn > 55 and r < mx
            else:
                ok = r > 165 and r > g + 70 and r > b + 55
            if ok:
                mask[gy * gw + gx] = 1
    found = []
    seen = bytearray(gw * gh)
    for start in range(gw * gh):
        if not mask[start] or seen[start]:
            continue
        stack = [start]
        seen[start] = 1
        cells = []
        while stack:
            k = stack.pop()
            cells.append(k)
            cx, cy = k % gw, k // gw
            for nx, ny in ((cx + 1, cy), (cx - 1, cy), (cx, cy + 1), (cx, cy - 1)):
                if 0 <= nx < gw and 0 <= ny < gh:
                    j = ny * gw + nx
                    if mask[j] and not seen[j]:
                        seen[j] = 1
                        stack.append(j)
        xs = [k % gw for k in cells]
        ys = [k // gw for k in cells]
        bw, bh = (max(xs) - min(xs) + 1) * step, (max(ys) - min(ys) + 1) * step
        fill = len(cells) * step * step / max(1, bw * bh)
        # кнопка звонка: от 22 до 160 пикселей, почти круглая/квадратная, плотно закрашена
        if not (22 <= bw <= 220 and 22 <= bh <= 220 and 0.6 <= bw / bh <= 1.7 and fill > 0.5):
            continue
        found.append((len(cells), int(x + (min(xs) + max(xs)) / 2 * step), int(y + (min(ys) + max(ys)) / 2 * step)))
    return found


def find_round_button(x, y, w, h, kind, step=3, data=None):
    """Центр самой большой круглой кнопки нужного цвета или None."""
    found = find_buttons(x, y, w, h, kind, step, data)
    return max(found)[1:] if found else None


def find_call_buttons(x, y, w, h, data=None):
    """(зелёная «ответить», красная «сбросить») - у входящего звонка они стоят в одном ряду."""
    if data is None:
        data = _grab(int(x), int(y), max(1, int(w)), max(1, int(h)))
    greens = find_buttons(x, y, w, h, "accept", data=data)
    reds = find_buttons(x, y, w, h, "decline", data=data)
    red = max(reds)[1:] if reds else None
    if red:
        greens = [g for g in greens if abs(g[2] - red[1]) < max(40, h * 0.12)]
    green = max(greens)[1:] if greens else None
    if red and not green:
        # запасной вариант: ближайшая цветная круглая кнопка справа от красной в том же ряду
        others = [b for b in find_buttons(x, y, w, h, "colored", data=data)
                  if abs(b[2] - red[1]) < max(40, h * 0.12) and b[1] > red[0]]
        if others:
            green = min(others, key=lambda b: b[1] - red[0])[1:]
    return green, red


def save_strip(path, data, w, h, center, half_w=360, half_h=90):
    """Сохраняет полоску картинки окна вокруг точки center (в полном размере) в BMP."""
    cx, cy = center
    x0, x1 = max(0, cx - half_w), min(w, cx + half_w)
    y0, y1 = max(0, cy - half_h), min(h, cy + half_h)
    ow, oh = x1 - x0, y1 - y0
    pad = (4 - (ow * 3) % 4) % 4
    rows = bytearray()
    for y in range(y1 - 1, y0 - 1, -1):
        for x in range(x0, x1):
            i = (y * w + x) * 4
            rows += data[i:i + 3]
        rows += b"\0" * pad
    with open(path, "wb") as f:
        f.write(b"BM" + struct.pack("<IHHI", 54 + len(rows), 0, 0, 54))
        f.write(struct.pack("<IiiHHIIiiII", 40, ow, oh, 1, 24, 0, len(rows), 3780, 3780, 0, 0))
        f.write(rows)


def click_at(sx, sy):
    p = wt.POINT()
    user32.GetCursorPos(ctypes.byref(p))
    user32.SetCursorPos(sx, sy)
    time.sleep(0.04)
    user32.mouse_event(0x2, 0, 0, 0, 0)
    time.sleep(0.04)
    user32.mouse_event(0x4, 0, 0, 0, 0)
    time.sleep(0.05)
    user32.SetCursorPos(p.x, p.y)


def press_call_button(proc, kind, prefer=None):
    """Нажать «принять»/«сбросить» в окне звонка программы proc.
    prefer - hwnd окна звонка, если знаем его. Возвращает True, если кнопку нашли и нажали."""
    wins = windows_of([proc]).get(proc.lower(), [])
    wins = [wv for wv in wins if wv[2][2] > 80 and wv[2][3] > 80]
    # сначала окно звонка, потом маленькие окна, потом главное
    wins.sort(key=lambda wv: (wv[0] != prefer, wv[2][2] * wv[2][3]))
    for hwnd, _title, (x, y, w, h), iconic in wins[:4]:
        bring_to_front(hwnd)
        time.sleep(0.35)
        r = wt.RECT()
        user32.GetWindowRect(hwnd, ctypes.byref(r))
        x, y, w, h = r.left, r.top, r.right - r.left, r.bottom - r.top
        if w <= 0 or h <= 0:
            continue
        green, red = find_call_buttons(x, y, w, h)
        pt = green if kind == "accept" else red
        if pt:
            click_at(*pt)
            return True
    return False
