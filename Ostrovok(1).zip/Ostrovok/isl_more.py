"""Ещё идеи из Atoll (MIT License, (c) 2026 mykolaichechelnytskyi), переписанные на Python:
громкость каждой программы, «долгие задачи» (проценты в заголовках окон), действия с файлом,
который перетащили на островок, и календарь по секретной ICS-ссылке.
Всё работает на этом компьютере; в интернет ходит только календарь - по ссылке, которую ты сам вставил."""
import ctypes
import ctypes.wintypes as wt
import datetime as dt
import os
import re
import urllib.request
import zipfile

import isl_core as core
from isl_core import _com, _guid, VP, F

user32 = ctypes.WinDLL("user32")
kernel32 = ctypes.WinDLL("kernel32")


# ───────────────────────── громкость программ ─────────────────────────
class AppMixer:
    """Список программ, которые сейчас издают звук, и их громкость (как микшер Windows)."""

    def __init__(self):
        self.apps = []          # [(имя, громкость 0..1, без звука)]
        self.vols = {}          # имя -> [указатели ISimpleAudioVolume]

    def _release(self):
        for lst in self.vols.values():
            for p in lst:
                try:
                    _com(p, 2)(p)
                except Exception:
                    pass
        self.vols = {}

    def refresh(self):
        """Вызывать из главного потока (там уже включён COM)."""
        self._release()
        apps = {}
        enum, dev, mgr, senum = VP(), VP(), VP(), VP()
        clsid = _guid("{BCDE0395-E52F-467C-8E3D-C4579291692E}")
        iid = _guid("{A95664D2-9614-4F35-A746-DE8DB63617E6}")
        if core.ole32.CoCreateInstance(ctypes.byref(clsid), None, 23, ctypes.byref(iid), ctypes.byref(enum)) != 0:
            self.apps = []
            return self.apps
        try:
            if _com(enum, 4, ctypes.c_int, ctypes.c_int, ctypes.POINTER(VP))(enum, 0, 1, ctypes.byref(dev)) != 0:
                return self.apps
            activate = _com(dev, 3, ctypes.POINTER(core._GUID), wt.DWORD, VP, ctypes.POINTER(VP))
            if activate(dev, ctypes.byref(_guid("{77AA99A0-1BD6-484F-8BC7-2C654C9A9B6F}")), 23, None, ctypes.byref(mgr)) != 0:
                _com(dev, 2)(dev)
                return self.apps
            _com(dev, 2)(dev)
            if _com(mgr, 5, ctypes.POINTER(VP))(mgr, ctypes.byref(senum)) != 0:
                _com(mgr, 2)(mgr)
                return self.apps
            count = ctypes.c_int()
            _com(senum, 3, ctypes.POINTER(ctypes.c_int))(senum, ctypes.byref(count))
            iid_ctl2 = _guid("{bfb7ff88-7239-4fc9-8fa2-07c950be9c6d}")
            iid_vol = _guid("{87CE5498-68D6-44E5-9215-6DA47EF883D8}")
            for i in range(count.value):
                ctl, ctl2, vol = VP(), VP(), VP()
                if _com(senum, 4, ctypes.c_int, ctypes.POINTER(VP))(senum, i, ctypes.byref(ctl)) != 0:
                    continue
                try:
                    state = ctypes.c_int()
                    _com(ctl, 3, ctypes.POINTER(ctypes.c_int))(ctl, ctypes.byref(state))
                    if state.value != 1:          # 1 = программа сейчас играет звук
                        continue
                    qi = _com(ctl, 0, ctypes.POINTER(core._GUID), ctypes.POINTER(VP))
                    if qi(ctl, ctypes.byref(iid_ctl2), ctypes.byref(ctl2)) != 0:
                        continue
                    pid = wt.DWORD()
                    _com(ctl2, 14, ctypes.POINTER(wt.DWORD))(ctl2, ctypes.byref(pid))
                    is_sys = _com(ctl2, 15)(ctl2) == 0     # S_OK = системные звуки
                    _com(ctl2, 2)(ctl2)
                    if is_sys or not pid.value or pid.value == os.getpid():
                        continue
                    name = _proc_name(pid.value)
                    if not name or qi(ctl, ctypes.byref(iid_vol), ctypes.byref(vol)) != 0:
                        continue
                    lvl, mute = F(), wt.BOOL()
                    _com(vol, 4, ctypes.POINTER(F))(vol, ctypes.byref(lvl))
                    _com(vol, 6, ctypes.POINTER(wt.BOOL))(vol, ctypes.byref(mute))
                    self.vols.setdefault(name, []).append(vol)
                    if name not in apps:
                        apps[name] = (name, lvl.value, bool(mute.value))
                finally:
                    _com(ctl, 2)(ctl)
            _com(senum, 2)(senum)
            _com(mgr, 2)(mgr)
        finally:
            _com(enum, 2)(enum)
        self.apps = sorted(apps.values(), key=lambda a: a[0].lower())[:6]
        return self.apps

    def set_volume(self, name, value):
        for v in self.vols.get(name, []):
            _com(v, 3, F, VP)(v, max(0.0, min(1.0, value)), None)
            _com(v, 5, wt.BOOL, VP)(v, False, None)

    def toggle_mute(self, name):
        for (n, _, mute) in self.apps:
            if n == name:
                for v in self.vols.get(name, []):
                    _com(v, 5, wt.BOOL, VP)(v, not mute, None)


_names = {}


def _proc_name(pid):
    if pid in _names:
        return _names[pid]
    name = ""
    h = kernel32.OpenProcess(0x1000, False, pid)
    if h:
        buf = ctypes.create_unicode_buffer(1024)
        size = wt.DWORD(1024)
        if kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
            path = buf.value
            exe = os.path.basename(path).lower()
            name = core.KNOWN_APPS.get(exe) or core._file_description(path) or os.path.splitext(os.path.basename(path))[0]
        kernel32.CloseHandle(h)
    if len(_names) > 300:
        _names.clear()
    _names[pid] = name
    return name


# ───────────────────────── куда выводить звук ─────────────────────────
class _PROPVARIANT(ctypes.Structure):
    _fields_ = [("vt", wt.USHORT), ("r1", wt.WORD), ("r2", wt.WORD), ("r3", wt.WORD), ("ptr", ctypes.c_void_p),
                ("extra", ctypes.c_void_p)]


class _PROPERTYKEY(ctypes.Structure):
    _fields_ = [("fmtid", core._GUID), ("pid", wt.DWORD)]


def output_devices():
    """[(id, название, выбрано ли сейчас)] - колонки, наушники, Bluetooth (только включённые)."""
    res = []
    enum, coll, dflt = VP(), VP(), VP()
    clsid = _guid("{BCDE0395-E52F-467C-8E3D-C4579291692E}")
    iid = _guid("{A95664D2-9614-4F35-A746-DE8DB63617E6}")
    if core.ole32.CoCreateInstance(ctypes.byref(clsid), None, 23, ctypes.byref(iid), ctypes.byref(enum)) != 0:
        return res
    try:
        default_id = ""
        if _com(enum, 4, ctypes.c_int, ctypes.c_int, ctypes.POINTER(VP))(enum, 0, 0, ctypes.byref(dflt)) == 0:
            p = ctypes.c_wchar_p()
            _com(dflt, 5, ctypes.POINTER(ctypes.c_wchar_p))(dflt, ctypes.byref(p))
            default_id = p.value or ""
            ctypes.windll.ole32.CoTaskMemFree(p)
            _com(dflt, 2)(dflt)
        if _com(enum, 3, ctypes.c_int, wt.DWORD, ctypes.POINTER(VP))(enum, 0, 1, ctypes.byref(coll)) != 0:
            return res
        n = wt.UINT()
        _com(coll, 3, ctypes.POINTER(wt.UINT))(coll, ctypes.byref(n))
        key = _PROPERTYKEY(_guid("{a45c254e-df1c-4efd-8020-67d146a850e0}"), 14)      # PKEY_Device_FriendlyName
        for i in range(n.value):
            dev = VP()
            if _com(coll, 4, wt.UINT, ctypes.POINTER(VP))(coll, i, ctypes.byref(dev)) != 0:
                continue
            try:
                p = ctypes.c_wchar_p()
                _com(dev, 5, ctypes.POINTER(ctypes.c_wchar_p))(dev, ctypes.byref(p))
                dev_id = p.value or ""
                ctypes.windll.ole32.CoTaskMemFree(p)
                store = VP()
                name = dev_id
                if _com(dev, 4, wt.DWORD, ctypes.POINTER(VP))(dev, 0, ctypes.byref(store)) == 0:
                    pv = _PROPVARIANT()
                    if _com(store, 5, ctypes.POINTER(_PROPERTYKEY), ctypes.POINTER(_PROPVARIANT))(
                            store, ctypes.byref(key), ctypes.byref(pv)) == 0 and pv.vt == 31 and pv.ptr:
                        name = ctypes.wstring_at(pv.ptr)
                        ctypes.windll.ole32.PropVariantClear(ctypes.byref(pv))
                    _com(store, 2)(store)
                res.append((dev_id, name, dev_id == default_id))
            finally:
                _com(dev, 2)(dev)
        _com(coll, 2)(coll)
    finally:
        _com(enum, 2)(enum)
    return res


def set_output_device(dev_id):
    """Делает устройство звуком по умолчанию (как выбор в значке звука Windows)."""
    pc = VP()
    clsid = _guid("{870af99c-171d-4f9e-af0d-e63df40c2bc9}")       # PolicyConfigClient
    iid = _guid("{f8679f50-850a-41cf-9c72-430f290290c8}")         # IPolicyConfig
    if core.ole32.CoCreateInstance(ctypes.byref(clsid), None, 1, ctypes.byref(iid), ctypes.byref(pc)) != 0:
        return False
    try:
        set_default = _com(pc, 13, ctypes.c_wchar_p, ctypes.c_int)
        ok = all(set_default(pc, dev_id, role) == 0 for role in (0, 1, 2))
    finally:
        _com(pc, 2)(pc)
    return ok


# ───────────────────────── долгие задачи ─────────────────────────
_PCT = re.compile(r"^\s*\D{0,24}?(\d{1,3})(?:[.,]\d+)?\s?%|(\d{1,3})(?:[.,]\d+)?\s?%\s*$")
_SKIP = ("chrome", "msedge", "firefox", "opera", "brave", "browser", "vivaldi", "iexplore", "telegram", "discord",
         "python", "claude", "yandex")
_FRIENDLY = {"explorer": "Файлы", "7zg": "7-Zip", "7zfm": "7-Zip", "winrar": "WinRAR", "handbrake": "HandBrake",
             "steam": "Steam", "steamwebhelper": "Steam"}
_ENUM = ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)


class ProgressWatcher:
    """Копирование, распаковка, кодирование... - по процентам в заголовке окна (только читаем заголовки)."""

    def __init__(self):
        self.jobs = {}          # hwnd -> [программа, %, с какого времени, первый %]
        self.current = None     # (программа, %)

    def poll(self, now):
        found = {}

        def cb(h, _):
            if not user32.IsWindowVisible(h):
                return True
            n = user32.GetWindowTextLengthW(h)
            if n < 2 or n > 200:
                return True
            buf = ctypes.create_unicode_buffer(n + 1)
            user32.GetWindowTextW(h, buf, n + 1)
            t = buf.value
            if "%" not in t:
                return True
            m = _PCT.search(t)
            if not m:
                return True
            pct = int(m.group(1) or m.group(2))
            if pct > 100:
                return True
            pid = wt.DWORD()
            user32.GetWindowThreadProcessId(h, ctypes.byref(pid))
            if pid.value == os.getpid():
                return True
            exe = _exe(pid.value)
            if not exe or any(s in exe for s in _SKIP):
                return True
            found[h] = (exe, pct)
            return True

        user32.EnumWindows(_ENUM(cb), 0)
        finished = []
        for h in [h for h in self.jobs if h not in found]:
            app, pct, since, first = self.jobs.pop(h)
            if pct >= 90 and pct != first and now - since > 4:
                finished.append(_FRIENDLY.get(app, app.capitalize()))
        for h, (app, pct) in found.items():
            if h in self.jobs:
                self.jobs[h][1] = pct
            else:
                self.jobs[h] = [app, pct, now, pct]
        moving = [j for j in self.jobs.values() if j[1] != j[3]]   # число должно поменяться - иначе это не задача
        if moving:
            j = max(moving, key=lambda j: j[2])
            self.current = (_FRIENDLY.get(j[0], j[0].capitalize()), j[1])
        else:
            self.current = None
        return finished


_exes = {}


def _exe(pid):
    if pid in _exes:
        return _exes[pid]
    e = ""
    h = kernel32.OpenProcess(0x1000, False, pid)
    if h:
        buf = ctypes.create_unicode_buffer(1024)
        size = wt.DWORD(1024)
        if kernel32.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(size)):
            e = os.path.splitext(os.path.basename(buf.value))[0].lower()
        kernel32.CloseHandle(h)
    if len(_exes) > 300:
        _exes.clear()
    _exes[pid] = e
    return e


# ───────────────────────── файл, брошенный на островок ─────────────────────────
shell32 = ctypes.WinDLL("shell32")
shell32.DragQueryFileW.argtypes = [wt.HANDLE, wt.UINT, wt.LPWSTR, wt.UINT]
shell32.DragQueryFileW.restype = wt.UINT
shell32.DragFinish.argtypes = [wt.HANDLE]


def dropped_files(hdrop):
    n = shell32.DragQueryFileW(hdrop, 0xFFFFFFFF, None, 0)
    files = []
    for i in range(min(n, 200)):
        ln = shell32.DragQueryFileW(hdrop, i, None, 0)
        buf = ctypes.create_unicode_buffer(ln + 1)
        shell32.DragQueryFileW(hdrop, i, buf, ln + 1)
        files.append(buf.value)
    shell32.DragFinish(hdrop)
    return files


def make_zip(files):
    """Сжимает файлы и папки в ZIP рядом с первым файлом. Возвращает путь архива."""
    first = files[0]
    base = os.path.splitext(first)[0] if len(files) == 1 else os.path.join(os.path.dirname(first), "Архив")
    out = base + ".zip"
    k = 2
    while os.path.exists(out):
        out = f"{base} ({k}).zip"
        k += 1
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for f in files:
            if os.path.isdir(f):
                root = os.path.dirname(f)
                for d, _, names in os.walk(f):
                    for n in names:
                        p = os.path.join(d, n)
                        z.write(p, os.path.relpath(p, root))
            elif os.path.isfile(f):
                z.write(f, os.path.basename(f))
    return out


def copy_files_to_clipboard(hwnd, files):
    """Кладёт файлы в буфер (как Ctrl+C в проводнике) - вставь их в Telegram, чат или папку."""
    class DROPFILES(ctypes.Structure):
        _fields_ = [("pFiles", wt.DWORD), ("pt", wt.POINT), ("fNC", wt.BOOL), ("fWide", wt.BOOL)]
    data = ("\0".join(files) + "\0\0").encode("utf-16-le")
    size = ctypes.sizeof(DROPFILES) + len(data)
    kernel32.GlobalAlloc.restype = wt.HANDLE
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalLock.argtypes = [wt.HANDLE]
    kernel32.GlobalUnlock.argtypes = [wt.HANDLE]
    h = kernel32.GlobalAlloc(0x0042, size)
    p = kernel32.GlobalLock(h)
    df = DROPFILES.from_address(p)
    df.pFiles = ctypes.sizeof(DROPFILES)
    df.fWide = True
    ctypes.memmove(p + ctypes.sizeof(DROPFILES), data, len(data))
    kernel32.GlobalUnlock(h)
    user32.SetClipboardData.argtypes = [wt.UINT, wt.HANDLE]
    if user32.OpenClipboard(hwnd):
        user32.EmptyClipboard()
        user32.SetClipboardData(15, h)      # CF_HDROP
        user32.CloseClipboard()
        return True
    return False


def human_size(paths):
    total = 0
    for f in paths:
        try:
            if os.path.isdir(f):
                for d, _, names in os.walk(f):
                    for n in names:
                        total += os.path.getsize(os.path.join(d, n))
            else:
                total += os.path.getsize(f)
        except OSError:
            pass
    for unit, k in (("ГБ", 1 << 30), ("МБ", 1 << 20), ("КБ", 1 << 10)):
        if total >= k:
            return f"{total / k:.1f} {unit}"
    return f"{total} Б"


# ───────────────────────── календарь по ICS-ссылке ─────────────────────────
def _ics_time(val, params):
    val = val.strip()
    try:
        if "VALUE=DATE" in params and len(val) == 8:
            return dt.datetime.strptime(val, "%Y%m%d"), True
        if val.endswith("Z"):
            t = dt.datetime.strptime(val, "%Y%m%dT%H%M%SZ").replace(tzinfo=dt.timezone.utc)
            return t.astimezone().replace(tzinfo=None), False
        return dt.datetime.strptime(val[:15], "%Y%m%dT%H%M%S"), False
    except ValueError:
        return None, False


def parse_ics(text, days=14):
    """События на ближайшие дни: [(начало, название, весь день)]. Повторы (RRULE) - только еженедельные/ежедневные."""
    text = re.sub(r"\r?\n[ \t]", "", text)        # склеиваем перенесённые строки
    now = dt.datetime.now()
    until = now + dt.timedelta(days=days)
    events = []
    for block in text.split("BEGIN:VEVENT")[1:]:
        block = block.split("END:VEVENT")[0]
        start, allday, title, rule = None, False, "Событие", ""
        for line in block.splitlines():
            if ":" not in line:
                continue
            key, val = line.split(":", 1)
            name = key.split(";")[0].upper()
            if name == "DTSTART":
                start, allday = _ics_time(val, key)
            elif name == "SUMMARY":
                title = val.replace("\\,", ",").replace("\\n", " ").strip() or title
            elif name == "RRULE":
                rule = val.upper()
        if not start:
            continue
        step = None
        if "FREQ=DAILY" in rule:
            step = dt.timedelta(days=1)
        elif "FREQ=WEEKLY" in rule:
            step = dt.timedelta(weeks=1)
        t, n = start, 0
        if step and t < now - step:          # повтор с давних времён - сразу перескакиваем к сегодняшнему дню
            t += step * ((now - t) // step)
        while t < until and n < 400:
            end_of_day = t + dt.timedelta(days=1) if allday else t + dt.timedelta(hours=1)
            if end_of_day >= now:
                events.append((t, title, allday))
            if not step:
                break
            t += step
            n += 1
    events.sort(key=lambda e: e[0])
    return events[:30]


def fetch_ics(url):
    if url.lower().startswith("webcal://"):
        url = "https://" + url[9:]
    if not url.lower().startswith(("https://", "http://")):
        raise ValueError("нужна ссылка https://")
    req = urllib.request.Request(url, headers={"User-Agent": "Ostrovok-Island"})
    with urllib.request.urlopen(req, timeout=15) as r:
        data = r.read(3_000_000)
    return parse_ics(data.decode("utf-8", "replace"))
