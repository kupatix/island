"""FPS игры и нагрузка видеокарты (идея и способ - из Atoll, MIT License, (c) 2026 mykolaichechelnytskyi).

FPS: каждый кадр игра вызывает Present, а Windows пишет об этом событие (DXGI - DirectX 10/11/12, D3D9 -
старые игры). Мы считаем такие события у процесса игры за последнюю секунду - так же делает PresentMon.
Читать эти события можно админу или участнику группы «Пользователи журналов производительности».
Кнопка «Включить FPS» один раз спрашивает Windows (окно UAC) и запускает помощника с правами, который
добавляет тебя в эту группу (для следующего входа в Windows) и сразу считает FPS сам, складывая цифры в файл.

GPU: счётчики Windows «GPU Engine ... 3D», права не нужны.
Запуск помощника: pythonw isl_fps.py --helper <pid островка>
"""
import ctypes
import ctypes.wintypes as wt
import json
import os
import sys
import threading
import time

advapi = ctypes.WinDLL("advapi32")
kernel32 = ctypes.WinDLL("kernel32")
pdh = ctypes.WinDLL("pdh")

HELPER_FILE = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "Ostrovok", "fps-helper.json")


class GUID(ctypes.Structure):
    _fields_ = [("Data1", wt.DWORD), ("Data2", wt.WORD), ("Data3", wt.WORD), ("Data4", ctypes.c_ubyte * 8)]

    @classmethod
    def parse(cls, s):
        s = s.strip("{}")
        a, b, c_, d, e = s.split("-")
        g = cls(int(a, 16), int(b, 16), int(c_, 16))
        raw = bytes.fromhex(d + e)
        for i in range(8):
            g.Data4[i] = raw[i]
        return g

    def key(self):
        return bytes(self)


DXGI = GUID.parse("CA11C036-0102-4A2D-A6AD-F03CFED5D3C9")
D3D9 = GUID.parse("783ACA0A-790E-4D7F-8451-AA850511C6B9")
PRESENT_IDS = {DXGI.key(): (42, 55), D3D9.key(): (1,)}


class WNODE_HEADER(ctypes.Structure):
    _fields_ = [("BufferSize", wt.ULONG), ("ProviderId", wt.ULONG), ("HistoricalContext", ctypes.c_uint64),
                ("TimeStamp", ctypes.c_int64), ("Guid", GUID), ("ClientContext", wt.ULONG), ("Flags", wt.ULONG)]


class EVENT_TRACE_PROPERTIES(ctypes.Structure):
    _fields_ = [("Wnode", WNODE_HEADER), ("BufferSize", wt.ULONG), ("MinimumBuffers", wt.ULONG),
                ("MaximumBuffers", wt.ULONG), ("MaximumFileSize", wt.ULONG), ("LogFileMode", wt.ULONG),
                ("FlushTimer", wt.ULONG), ("EnableFlags", wt.ULONG), ("AgeLimit", ctypes.c_long),
                ("NumberOfBuffers", wt.ULONG), ("FreeBuffers", wt.ULONG), ("EventsLost", wt.ULONG),
                ("BuffersWritten", wt.ULONG), ("LogBuffersLost", wt.ULONG), ("RealTimeBuffersLost", wt.ULONG),
                ("LoggerThreadId", wt.HANDLE), ("LogFileNameOffset", wt.ULONG), ("LoggerNameOffset", wt.ULONG)]


class EVENT_TRACE_HEADER(ctypes.Structure):
    _fields_ = [("Size", wt.USHORT), ("FieldTypeFlags", wt.USHORT), ("Version", wt.ULONG), ("ThreadId", wt.ULONG),
                ("ProcessId", wt.ULONG), ("TimeStamp", ctypes.c_int64), ("Guid", GUID), ("KernelTime", wt.ULONG),
                ("UserTime", wt.ULONG)]


class EVENT_TRACE(ctypes.Structure):
    _fields_ = [("Header", EVENT_TRACE_HEADER), ("InstanceId", wt.ULONG), ("ParentInstanceId", wt.ULONG),
                ("ParentGuid", GUID), ("MofData", ctypes.c_void_p), ("MofLength", wt.ULONG), ("ClientContext", wt.ULONG)]


class SYSTEMTIME(ctypes.Structure):
    _fields_ = [(n, wt.WORD) for n in ("wYear", "wMonth", "wDayOfWeek", "wDay", "wHour", "wMinute", "wSecond", "wMs")]


class TIME_ZONE_INFORMATION(ctypes.Structure):
    _fields_ = [("Bias", ctypes.c_long), ("StandardName", ctypes.c_wchar * 32), ("StandardDate", SYSTEMTIME),
                ("StandardBias", ctypes.c_long), ("DaylightName", ctypes.c_wchar * 32), ("DaylightDate", SYSTEMTIME),
                ("DaylightBias", ctypes.c_long)]


class TRACE_LOGFILE_HEADER(ctypes.Structure):
    _fields_ = [("BufferSize", wt.ULONG), ("Version", wt.ULONG), ("ProviderVersion", wt.ULONG),
                ("NumberOfProcessors", wt.ULONG), ("EndTime", ctypes.c_int64), ("TimerResolution", wt.ULONG),
                ("MaximumFileSize", wt.ULONG), ("LogFileMode", wt.ULONG), ("BuffersWritten", wt.ULONG),
                ("LogInstanceGuid", GUID), ("LoggerName", ctypes.c_void_p), ("LogFileName", ctypes.c_void_p),
                ("TimeZone", TIME_ZONE_INFORMATION), ("BootTime", ctypes.c_int64), ("PerfFreq", ctypes.c_int64),
                ("StartTime", ctypes.c_int64), ("ReservedFlags", wt.ULONG), ("BuffersLost", wt.ULONG)]


EVENT_RECORD_CALLBACK = ctypes.WINFUNCTYPE(None, ctypes.c_void_p)


class EVENT_TRACE_LOGFILEW(ctypes.Structure):
    _fields_ = [("LogFileName", ctypes.c_wchar_p), ("LoggerName", ctypes.c_wchar_p), ("CurrentTime", ctypes.c_int64),
                ("BuffersRead", wt.ULONG), ("ProcessTraceMode", wt.ULONG), ("CurrentEvent", EVENT_TRACE),
                ("LogfileHeader", TRACE_LOGFILE_HEADER), ("BufferCallback", ctypes.c_void_p),
                ("BufferSize", wt.ULONG), ("Filled", wt.ULONG), ("EventsLost", wt.ULONG),
                ("EventRecordCallback", EVENT_RECORD_CALLBACK), ("IsKernelTrace", wt.ULONG), ("Context", ctypes.c_void_p)]


advapi.StartTraceW.argtypes = [ctypes.POINTER(ctypes.c_uint64), wt.LPCWSTR, ctypes.c_void_p]
advapi.StartTraceW.restype = wt.ULONG
advapi.ControlTraceW.argtypes = [ctypes.c_uint64, wt.LPCWSTR, ctypes.c_void_p, wt.ULONG]
advapi.ControlTraceW.restype = wt.ULONG
advapi.EnableTraceEx2.argtypes = [ctypes.c_uint64, ctypes.POINTER(GUID), wt.ULONG, ctypes.c_ubyte, ctypes.c_uint64,
                                  ctypes.c_uint64, wt.ULONG, ctypes.c_void_p]
advapi.EnableTraceEx2.restype = wt.ULONG
advapi.OpenTraceW.argtypes = [ctypes.POINTER(EVENT_TRACE_LOGFILEW)]
advapi.OpenTraceW.restype = ctypes.c_uint64
advapi.ProcessTrace.argtypes = [ctypes.POINTER(ctypes.c_uint64), wt.ULONG, ctypes.c_void_p, ctypes.c_void_p]
advapi.ProcessTrace.restype = wt.ULONG
advapi.CloseTrace.argtypes = [ctypes.c_uint64]

INVALID_TRACE = 0xFFFFFFFFFFFFFFFF


def _props(name):
    size = ctypes.sizeof(EVENT_TRACE_PROPERTIES) + (len(name) + 1) * 2 + 16
    buf = ctypes.create_string_buffer(size)
    p = EVENT_TRACE_PROPERTIES.from_buffer(buf)
    p.Wnode.BufferSize = size
    p.Wnode.Flags = 0x00020000          # WNODE_FLAG_TRACED_GUID
    p.Wnode.ClientContext = 1           # время событий - QueryPerformanceCounter
    p.LogFileMode = 0x00000100          # EVENT_TRACE_REAL_TIME_MODE
    p.FlushTimer = 1
    p.BufferSize = 64
    p.LoggerNameOffset = ctypes.sizeof(EVENT_TRACE_PROPERTIES)
    return buf


class FpsMeter:
    """Считает кадры (события Present) каждого процесса. start() -> True, если Windows разрешила."""

    def __init__(self, name="OstrovokFps"):
        self.name = name
        self.handle = None
        self.denied = False
        self.error = 0
        self.frames = {}                # pid -> список времён кадров (в секундах QPC)
        self.lock = threading.Lock()
        freq = ctypes.c_int64()
        kernel32.QueryPerformanceFrequency(ctypes.byref(freq))
        self.freq = float(freq.value or 1)
        self._cb = EVENT_RECORD_CALLBACK(self._on_event)

    def start(self):
        if self.handle:
            return True
        h = ctypes.c_uint64()
        props = _props(self.name)
        err = advapi.StartTraceW(ctypes.byref(h), self.name, props)
        if err == 183:                  # такая сессия осталась от прошлого запуска - останавливаем и заново
            advapi.ControlTraceW(0, self.name, _props(self.name), 1)
            props = _props(self.name)
            err = advapi.StartTraceW(ctypes.byref(h), self.name, props)
        self.error = err
        if err != 0:
            self.denied = err == 5
            return False
        for g in (DXGI, D3D9):
            advapi.EnableTraceEx2(h.value, ctypes.byref(g), 1, 4, 0, 0, 0, None)
        self.handle = h.value
        self._props_buf = props
        logfile = EVENT_TRACE_LOGFILEW()
        logfile.LoggerName = self.name
        logfile.ProcessTraceMode = 0x00000100 | 0x10000000     # REAL_TIME | EVENT_RECORD
        logfile.EventRecordCallback = self._cb
        self._logfile = logfile
        th = advapi.OpenTraceW(ctypes.byref(logfile))
        if th == INVALID_TRACE:
            self.stop()
            return False
        self.trace = ctypes.c_uint64(th)
        threading.Thread(target=lambda: advapi.ProcessTrace(ctypes.byref(self.trace), 1, None, None), daemon=True).start()
        return True

    def _on_event(self, rec):
        try:
            prov = ctypes.string_at(rec + 24, 16)
            ids = PRESENT_IDS.get(prov)
            if not ids:
                return
            eid = ctypes.c_uint16.from_address(rec + 40).value
            if eid not in ids:
                return
            pid = ctypes.c_uint32.from_address(rec + 12).value
            t = ctypes.c_int64.from_address(rec + 16).value / self.freq
            with self.lock:
                q = self.frames.setdefault(pid, [])
                q.append(t)
                if len(q) > 600:
                    del q[:-400]
        except Exception:
            pass

    def fps_of(self, pid):
        now = time.perf_counter()
        with self.lock:
            q = self.frames.get(pid)
            if not q or now - q[-1] > 3:      # события приходят пачками раз в секунду
                return None
            newest = q[-1]
            return sum(1 for t in q if newest - t <= 1.0)

    def all(self):
        with self.lock:
            pids = list(self.frames)
        out = {}
        for pid in pids:
            f = self.fps_of(pid)
            if f is not None:
                out[str(pid)] = f
        return out

    def stop(self):
        if self.handle:
            advapi.ControlTraceW(self.handle, None, _props(self.name), 1)
            self.handle = None


def fps_from_helper(pid):
    try:
        if time.time() - os.path.getmtime(HELPER_FILE) > 3:
            return None
        with open(HELPER_FILE, encoding="utf-8") as f:
            return json.load(f).get(str(pid))
    except (OSError, ValueError):
        return None


def helper_alive():
    try:
        return time.time() - os.path.getmtime(HELPER_FILE) <= 3
    except OSError:
        return False


def start_helper():
    """Одно окно Windows «Разрешить изменения?»: помощник с правами. False - если отказались."""
    exe = sys.executable.replace("python.exe", "pythonw.exe")
    script = os.path.abspath(__file__)
    params = f'"{script}" --helper {os.getpid()}'
    r = ctypes.windll.shell32.ShellExecuteW(None, "runas", exe, params, os.path.dirname(script), 0)
    return r > 32


def _is_link(path):
    try:
        return os.path.lexists(path) and bool(os.lstat(path).st_file_attributes & 0x400)
    except OSError:
        return True


def run_helper(parent_pid):
    """Работает с правами админа, пока жив островок: добавляет пользователя в группу (для следующего входа)
    и пишет FPS всех процессов в файл два раза в секунду."""
    ps = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
    user = os.environ.get("USERDOMAIN", "") + "\\" + os.environ.get("USERNAME", "")
    cmd = "Add-LocalGroupMember -SID 'S-1-5-32-559' -Member '" + user.replace("'", "''") + "' -ErrorAction SilentlyContinue"
    try:
        import subprocess
        subprocess.run([ps, "-NoProfile", "-NonInteractive", "-Command", cmd], creationflags=0x08000000, timeout=60)
    except Exception:
        pass
    meter = FpsMeter("OstrovokFpsHelper")
    if not meter.start():
        return
    folder = os.path.dirname(HELPER_FILE)
    os.makedirs(folder, exist_ok=True)
    PROCESS_QUERY_LIMITED = 0x1000
    while True:
        h = kernel32.OpenProcess(0x00100000 | PROCESS_QUERY_LIMITED, False, parent_pid)   # SYNCHRONIZE
        if not h:
            break
        alive = kernel32.WaitForSingleObject(h, 0) == 0x102     # WAIT_TIMEOUT = ещё работает
        kernel32.CloseHandle(h)
        if not alive:
            break
        tmp = HELPER_FILE + ".tmp"
        if _is_link(tmp) or _is_link(HELPER_FILE) or _is_link(folder):
            break
        try:
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(meter.all(), f)
            os.replace(tmp, HELPER_FILE)
        except OSError:
            pass
        time.sleep(0.5)
    meter.stop()
    try:
        os.remove(HELPER_FILE)
    except OSError:
        pass


# ───────────────────────── нагрузка видеокарты ─────────────────────────
class PDH_VALUE(ctypes.Structure):
    _fields_ = [("CStatus", wt.DWORD), ("doubleValue", ctypes.c_double)]


class PDH_ITEM(ctypes.Structure):
    _fields_ = [("szName", ctypes.c_wchar_p), ("FmtValue", PDH_VALUE)]


pdh.PdhOpenQueryW.argtypes = [wt.LPCWSTR, ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
pdh.PdhAddEnglishCounterW.argtypes = [ctypes.c_void_p, wt.LPCWSTR, ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)]
pdh.PdhCollectQueryData.argtypes = [ctypes.c_void_p]
pdh.PdhGetFormattedCounterArrayW.argtypes = [ctypes.c_void_p, wt.DWORD, ctypes.POINTER(wt.DWORD),
                                             ctypes.POINTER(wt.DWORD), ctypes.c_void_p]
pdh.PdhGetFormattedCounterArrayW.restype = ctypes.c_long


class GpuLoad:
    """Нагрузка видеокарты в % (сумма 3D-движков всех программ), без прав администратора."""

    def __init__(self):
        self.query = ctypes.c_void_p()
        self.counter = ctypes.c_void_p()
        self.ok = (pdh.PdhOpenQueryW(None, None, ctypes.byref(self.query)) == 0 and
                   pdh.PdhAddEnglishCounterW(self.query, r"\GPU Engine(*engtype_3D)\Utilization Percentage", None,
                                             ctypes.byref(self.counter)) == 0)
        if self.ok:
            pdh.PdhCollectQueryData(self.query)
        self.value = None

    def sample(self):
        if not self.ok or pdh.PdhCollectQueryData(self.query) != 0:
            return None
        size, count = wt.DWORD(0), wt.DWORD(0)
        fmt = 0x200 | 0x8000        # PDH_FMT_DOUBLE | PDH_FMT_NOCAP100
        r = pdh.PdhGetFormattedCounterArrayW(self.counter, fmt, ctypes.byref(size), ctypes.byref(count), None)
        if size.value == 0:
            self.value = 0.0
            return self.value
        buf = ctypes.create_string_buffer(size.value)
        if pdh.PdhGetFormattedCounterArrayW(self.counter, fmt, ctypes.byref(size), ctypes.byref(count), buf) != 0:
            return self.value
        items = ctypes.cast(buf, ctypes.POINTER(PDH_ITEM))
        total = sum(items[i].FmtValue.doubleValue for i in range(count.value) if items[i].FmtValue.CStatus == 0)
        self.value = max(0.0, min(100.0, total))
        return self.value


class NetSpeed:
    """Скорость интернета (байт/с вниз и вверх) по счётчикам Windows, без прав администратора."""

    def __init__(self):
        self.query = ctypes.c_void_p()
        self.rx, self.tx = ctypes.c_void_p(), ctypes.c_void_p()
        self.ok = (pdh.PdhOpenQueryW(None, None, ctypes.byref(self.query)) == 0 and
                   pdh.PdhAddEnglishCounterW(self.query, r"\Network Interface(*)\Bytes Received/sec", None, ctypes.byref(self.rx)) == 0 and
                   pdh.PdhAddEnglishCounterW(self.query, r"\Network Interface(*)\Bytes Sent/sec", None, ctypes.byref(self.tx)) == 0)
        if self.ok:
            pdh.PdhCollectQueryData(self.query)
        self.down = self.up = None

    def _sum(self, counter):
        size, count = wt.DWORD(0), wt.DWORD(0)
        fmt = 0x200 | 0x8000
        pdh.PdhGetFormattedCounterArrayW(counter, fmt, ctypes.byref(size), ctypes.byref(count), None)
        if not size.value:
            return 0.0
        buf = ctypes.create_string_buffer(size.value)
        if pdh.PdhGetFormattedCounterArrayW(counter, fmt, ctypes.byref(size), ctypes.byref(count), buf) != 0:
            return 0.0
        items = ctypes.cast(buf, ctypes.POINTER(PDH_ITEM))
        return sum(items[i].FmtValue.doubleValue for i in range(count.value) if items[i].FmtValue.CStatus == 0)

    def sample(self):
        if not self.ok or pdh.PdhCollectQueryData(self.query) != 0:
            return None
        self.down, self.up = self._sum(self.rx), self._sum(self.tx)
        return self.down, self.up


def gpu_name():
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                           r"SYSTEM\CurrentControlSet\Control\Class\{4d36e968-e325-11ce-bfc1-08002be10318}\0000")
        return winreg.QueryValueEx(k, "DriverDesc")[0]
    except OSError:
        return ""


if __name__ == "__main__" and len(sys.argv) >= 3 and sys.argv[1] == "--helper":
    run_helper(int(sys.argv[2]))
