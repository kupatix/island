"""Заряд наушников, мышек, клавиатур и геймпадов (идея из Atoll, MIT License, (c) 2026 mykolaichechelnytskyi).

Откуда берём:
* Bluetooth (наушники, мыши, клавиатуры) - Windows хранит заряд у устройства в свойстве
  DEVPKEY_Bluetooth_Battery, то же число видно в «Параметры → Bluetooth». Читаем через SetupAPI - быстро.
* Геймпады Xbox (и совместимые) - XInputGetBatteryInformation.
Некоторые устройства (например, часть игровых гарнитур с USB-приёмником) заряд компьютеру не сообщают вообще -
его тогда не видит и Windows.
"""
import ctypes
import ctypes.wintypes as wt

setupapi = ctypes.WinDLL("setupapi")


class GUID(ctypes.Structure):
    _fields_ = [("Data1", wt.DWORD), ("Data2", wt.WORD), ("Data3", wt.WORD), ("Data4", ctypes.c_ubyte * 8)]


def _guid(a, b, c, d):
    g = GUID(a, b, c)
    for i, x in enumerate(d):
        g.Data4[i] = x
    return g


class DEVPROPKEY(ctypes.Structure):
    _fields_ = [("fmtid", GUID), ("pid", wt.ULONG)]


class SP_DEVINFO_DATA(ctypes.Structure):
    _fields_ = [("cbSize", wt.DWORD), ("ClassGuid", GUID), ("DevInst", wt.DWORD), ("Reserved", ctypes.c_void_p)]


BT_BATTERY = DEVPROPKEY(_guid(0x104EA319, 0x6EE2, 0x4701, (0xBD, 0x47, 0x8D, 0xDB, 0xF4, 0x25, 0xBB, 0xE5)), 2)
FRIENDLY = DEVPROPKEY(_guid(0xa45c254e, 0xdf1c, 0x4efd, (0x80, 0x20, 0x67, 0xd1, 0x46, 0xa8, 0x50, 0xe0)), 14)
DEVDESC = DEVPROPKEY(_guid(0xa45c254e, 0xdf1c, 0x4efd, (0x80, 0x20, 0x67, 0xd1, 0x46, 0xa8, 0x50, 0xe0)), 2)

setupapi.SetupDiGetClassDevsW.restype = ctypes.c_void_p
setupapi.SetupDiGetClassDevsW.argtypes = [ctypes.c_void_p, wt.LPCWSTR, wt.HWND, wt.DWORD]
setupapi.SetupDiEnumDeviceInfo.argtypes = [ctypes.c_void_p, wt.DWORD, ctypes.POINTER(SP_DEVINFO_DATA)]
setupapi.SetupDiGetDevicePropertyW.argtypes = [ctypes.c_void_p, ctypes.POINTER(SP_DEVINFO_DATA), ctypes.POINTER(DEVPROPKEY),
                                               ctypes.POINTER(wt.ULONG), ctypes.c_void_p, wt.DWORD,
                                               ctypes.POINTER(wt.DWORD), wt.DWORD]
setupapi.SetupDiDestroyDeviceInfoList.argtypes = [ctypes.c_void_p]


def _prop(hset, info, key, size=512):
    t = wt.ULONG()
    buf = ctypes.create_string_buffer(size)
    need = wt.DWORD()
    if not setupapi.SetupDiGetDevicePropertyW(hset, ctypes.byref(info), ctypes.byref(key), ctypes.byref(t), buf, size,
                                              ctypes.byref(need), 0):
        return None
    if t.value == 0x03:                    # DEVPROP_TYPE_BYTE
        return buf.raw[0]
    if t.value == 0x12:                    # DEVPROP_TYPE_STRING
        return ctypes.wstring_at(buf)
    return None


def bluetooth_batteries():
    """[(название, процент)] у подключённых устройств, которые сообщают заряд."""
    out = {}
    hset = setupapi.SetupDiGetClassDevsW(None, None, None, 0x4 | 0x2)     # ALLCLASSES | PRESENT
    if not hset or hset == ctypes.c_void_p(-1).value:
        return []
    try:
        i = 0
        while True:
            info = SP_DEVINFO_DATA()
            info.cbSize = ctypes.sizeof(SP_DEVINFO_DATA)
            if not setupapi.SetupDiEnumDeviceInfo(hset, i, ctypes.byref(info)):
                break
            i += 1
            pct = _prop(hset, info, BT_BATTERY, 8)
            if pct is None or not 0 <= pct <= 100:
                continue
            name = _prop(hset, info, FRIENDLY) or _prop(hset, info, DEVDESC) or "Устройство"
            # одно устройство Windows показывает несколькими узлами - оставляем по одному на имя
            out[name] = pct
    finally:
        setupapi.SetupDiDestroyDeviceInfoList(hset)
    return sorted(out.items())


# ───────────────────────── геймпады ─────────────────────────
class _XBATT(ctypes.Structure):
    _fields_ = [("BatteryType", ctypes.c_ubyte), ("BatteryLevel", ctypes.c_ubyte)]


_xinput = None
for _n in ("xinput1_4", "xinput9_1_0", "xinput1_3"):
    try:
        _xinput = ctypes.WinDLL(_n)
        break
    except OSError:
        pass


def gamepad_batteries():
    """[(«Геймпад N», процент)]: XInput сообщает уровень 0..3 (пусто/мало/средне/полный)."""
    res = []
    if not _xinput or not hasattr(_xinput, "XInputGetBatteryInformation"):
        return res
    for i in range(4):
        b = _XBATT()
        if _xinput.XInputGetBatteryInformation(i, 0, ctypes.byref(b)) != 0:
            continue
        if b.BatteryType in (0, 1):            # не подключён / проводной
            continue
        res.append((f"Геймпад {i + 1}", {0: 5, 1: 25, 2: 60, 3: 100}.get(b.BatteryLevel, 50)))
    return res


def all_batteries():
    try:
        bt = bluetooth_batteries()
    except Exception:
        bt = []
    try:
        pads = gamepad_batteries()
    except Exception:
        pads = []
    return bt + pads


def kind_of(name):
    n = name.lower()
    if any(k in n for k in ("buds", "airpods", "head", "наушн", "гарнит", "wh-", "wf-", "jbl", "audio", "hands-free", "earbud")):
        return "headphones"
    if any(k in n for k in ("mouse", "мыш", "mx ", "g305", "g502", "pro x superlight")):
        return "mouse"
    if any(k in n for k in ("keyboard", "клавиат", "keys")):
        return "keyboard"
    if "геймпад" in n or "controller" in n or "gamepad" in n:
        return "gamepad"
    return "device"
