# Узнаёт, какая музыка сейчас играет в Windows (Spotify, Яндекс Музыка, YouTube в браузере и т.д.)
# и раз в полсекунды печатает это строчкой JSON. Ещё умеет пауза/следующая/предыдущая через файл команд.
param([string]$CommandFile = "", [int]$Once = 0, [int]$ParentPid = 0, [string]$CoverDir = "")
$ErrorActionPreference = "SilentlyContinue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
    $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($op, [Type]$type) {
    $task = $asTaskGeneric.MakeGenericMethod($type).Invoke($null, @($op))
    $task.Wait(3000) | Out-Null
    $task.Result
}
$null = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType = WindowsRuntime]
$mgrType = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager]
$propsType = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties]
$mgr = Await ($mgrType::RequestAsync()) $mgrType
$null = [Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType = WindowsRuntime]
$streamType = [Windows.Storage.Streams.IRandomAccessStreamWithContentType]
# PowerShell не видит методы у потока картинки, поэтому вызываем через рефлексию
$asStreamForRead = [System.IO.WindowsRuntimeStreamExtensions].GetMethod("AsStreamForRead", [type[]]@([Windows.Storage.Streams.IInputStream]))
$lastKey = ""
$coverPath = ""

# сохраняет обложку песни в файл (только когда песня сменилась)
function Save-Cover($props, $key) {
    if (-not $CoverDir -or -not $props.Thumbnail) { return "" }
    try {
        New-Item -ItemType Directory -Force $CoverDir | Out-Null
        $file = Join-Path $CoverDir ("cover_" + [Math]::Abs($key.GetHashCode()) + ".img")
        if (-not (Test-Path $file)) {
            $s = Await ($props.Thumbnail.OpenReadAsync()) $streamType
            $ns = $asStreamForRead.Invoke($null, @($s))
            $ms = New-Object System.IO.MemoryStream
            $ns.CopyTo($ms)
            $ns.Close()
            if ($ms.Length -gt 0) { [System.IO.File]::WriteAllBytes($file, $ms.ToArray()) } else { return "" }
        }
        Get-ChildItem $CoverDir -Filter "cover_*.img" | Sort-Object LastWriteTime -Descending |
            Select-Object -Skip 15 | Remove-Item -Force -ErrorAction SilentlyContinue
        return $file
    } catch { return "" }
}

while ($true) {
    # островок закрылся - закрываемся и мы
    if ($ParentPid -and -not (Get-Process -Id $ParentPid -ErrorAction SilentlyContinue)) { break }
    $o = @{ status = "None" }
    try {
        $s = $mgr.GetCurrentSession()
        if ($s) {
            if ($CommandFile -and (Test-Path $CommandFile)) {
                $cmd = (Get-Content $CommandFile -Raw).Trim()
                Remove-Item $CommandFile -Force
                if ($cmd -like "seek:*") {
                    # перемотка: seek:<секунды>
                    $sec = [double]::Parse($cmd.Substring(5), [System.Globalization.CultureInfo]::InvariantCulture)
                    $null = Await ($s.TryChangePlaybackPositionAsync([int64]($sec * 10000000))) ([bool])
                }
                switch ($cmd) {
                    "toggle" { $null = Await ($s.TryTogglePlayPauseAsync()) ([bool]) }
                    "next"   { $null = Await ($s.TrySkipNextAsync()) ([bool]) }
                    "prev"   { $null = Await ($s.TrySkipPreviousAsync()) ([bool]) }
                }
            }
            $p = Await ($s.TryGetMediaPropertiesAsync()) $propsType
            $t = $s.GetTimelineProperties()
            $pb = $s.GetPlaybackInfo()
            $key = "$($p.Artist)|$($p.Title)"
            if ($key -ne $lastKey -or (-not $coverPath -and $p.Thumbnail)) {
                $lastKey = $key
                $coverPath = Save-Cover $p $key
            }
            $o = @{
                cover  = $coverPath
                title  = [string]$p.Title
                artist = [string]$p.Artist
                status = [string]$pb.PlaybackStatus
                pos    = $t.Position.TotalSeconds
                dur    = $t.EndTime.TotalSeconds
                upd    = $t.LastUpdatedTime.ToUnixTimeMilliseconds()
                app    = [string]$s.SourceAppUserModelId
            }
        }
    } catch { $o = @{ status = "None"; error = "$_" } }
    [Console]::Out.WriteLine(($o | ConvertTo-Json -Compress))
    [Console]::Out.Flush()
    if ($Once) { break }
    Start-Sleep -Milliseconds 500
}
