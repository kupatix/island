"""Маленький генератор QR-кодов (байтовый режим, уровень коррекции L, версии 1-10, до 271 байта).
Сделан по описанию стандарта и по открытому алгоритму Nayuki (MIT). Возвращает квадрат из True/False."""

_RAW = [0, 26, 44, 70, 100, 134, 172, 196, 242, 292, 346]
_ECC = [0, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18]
_BLOCKS = [0, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4]
_ALIGN = [[], [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50]]


def _mul(x, y):
    z = 0
    for i in range(7, -1, -1):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z


def _divisor(degree):
    res = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(len(res)):
            res[j] = _mul(res[j], root)
            if j + 1 < len(res):
                res[j] ^= res[j + 1]
        root = _mul(root, 0x02)
    return res


def _remainder(data, div):
    res = [0] * len(div)
    for b in data:
        factor = b ^ res.pop(0)
        res.append(0)
        for i, coef in enumerate(div):
            res[i] ^= _mul(coef, factor)
    return res


def encode(text):
    data = text.encode("utf-8")
    for ver in range(1, 11):
        cap = _RAW[ver] - _ECC[ver] * _BLOCKS[ver]
        cc_bits = 8 if ver < 10 else 16
        if 4 + cc_bits + len(data) * 8 <= cap * 8:
            break
    else:
        raise ValueError("слишком длинный текст для QR")
    # биты данных
    bits = []

    def put(val, n):
        for i in range(n - 1, -1, -1):
            bits.append((val >> i) & 1)
    put(0b0100, 4)
    put(len(data), cc_bits)
    for b in data:
        put(b, 8)
    put(0, min(4, cap * 8 - len(bits)))
    put(0, (-len(bits)) % 8)
    pad = 0xEC
    while len(bits) < cap * 8:
        put(pad, 8)
        pad ^= 0xEC ^ 0x11
    cw = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    # коды коррекции и перемешивание блоков
    nb, ecl, raw = _BLOCKS[ver], _ECC[ver], _RAW[ver]
    short = nb - raw % nb
    short_len = raw // nb
    div = _divisor(ecl)
    blocks, k = [], 0
    for i in range(nb):
        n = short_len - ecl + (0 if i < short else 1)
        dat = cw[k:k + n]
        k += n
        ecc = _remainder(dat, div)
        if i < short:
            dat = dat + [0]
        blocks.append(dat + ecc)
    final = []
    for i in range(len(blocks[0])):
        for j, blk in enumerate(blocks):
            if i != short_len - ecl or j >= short:
                final.append(blk[i])
    # матрица
    size = ver * 4 + 17
    mod = [[False] * size for _ in range(size)]
    fn = [[False] * size for _ in range(size)]

    def setf(x, y, dark):
        mod[y][x] = dark
        fn[y][x] = True
    for i in range(size):
        setf(6, i, i % 2 == 0)
        setf(i, 6, i % 2 == 0)
    for cx, cy in ((3, 3), (size - 4, 3), (3, size - 4)):
        for dy in range(-4, 5):
            for dx in range(-4, 5):
                xx, yy = cx + dx, cy + dy
                if 0 <= xx < size and 0 <= yy < size:
                    d = max(abs(dx), abs(dy))
                    setf(xx, yy, d not in (2, 4))
    al = _ALIGN[ver]
    for i, ax in enumerate(al):
        for j, ay in enumerate(al):
            if (i == 0 and j == 0) or (i == 0 and j == len(al) - 1) or (i == len(al) - 1 and j == 0):
                continue
            for dy in range(-2, 3):
                for dx in range(-2, 3):
                    setf(ax + dx, ay + dy, max(abs(dx), abs(dy)) != 1)

    def format_bits(mask):
        d = (1 << 3) | mask          # уровень L = 01
        rem = d
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        b = ((d << 10) | rem) ^ 0x5412
        for i in range(6):
            setf(8, i, (b >> i) & 1)
        setf(8, 7, (b >> 6) & 1)
        setf(8, 8, (b >> 7) & 1)
        setf(7, 8, (b >> 8) & 1)
        for i in range(9, 15):
            setf(14 - i, 8, (b >> i) & 1)
        for i in range(8):
            setf(size - 1 - i, 8, (b >> i) & 1)
        for i in range(8, 15):
            setf(8, size - 15 + i, (b >> i) & 1)
        setf(8, size - 8, True)
    format_bits(0)
    if ver >= 7:
        rem = ver
        for _ in range(12):
            rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
        vb = (ver << 12) | rem
        for i in range(18):
            bit = (vb >> i) & 1
            a, b = size - 11 + i % 3, i // 3
            setf(a, b, bit)
            setf(b, a, bit)
    # раскладываем данные змейкой
    i = 0
    total = len(final) * 8
    right = size - 1
    while right >= 1:
        if right == 6:
            right = 5
        for vert in range(size):
            for j in range(2):
                x = right - j
                upward = ((right + 1) & 2) == 0
                y = size - 1 - vert if upward else vert
                if not fn[y][x] and i < total:
                    mod[y][x] = bool((final[i >> 3] >> (7 - (i & 7))) & 1)
                    i += 1
        right -= 2
    # маска 0: (x + y) чётное - инвертируем
    for y in range(size):
        for x in range(size):
            if not fn[y][x] and (x + y) % 2 == 0:
                mod[y][x] = not mod[y][x]
    format_bits(0)
    return mod
